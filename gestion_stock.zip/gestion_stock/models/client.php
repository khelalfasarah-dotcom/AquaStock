<?php
class Client {
    public static function all($conn) {
        return $conn->query("SELECT * FROM client ORDER BY idClient DESC");
    }
    public static function create($conn, $nom, $adresse, $telephone, $dateNaissance = null, $sexe = null, $email = null, $willaya = null) {
        $stmt = $conn->prepare("INSERT INTO client (nom, adresse, telephone, dateNaissance, sexe, email, willaya) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $nom, $adresse, $telephone, $dateNaissance, $sexe, $email, $willaya);
        return $stmt->execute();
    }
    public static function delete($conn, $id) {
        $stmt = $conn->prepare("DELETE FROM client WHERE idClient=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>