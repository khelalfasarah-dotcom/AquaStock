<?php
class Produit {
    public static function all($conn) {
        return $conn->query("SELECT * FROM produit ORDER BY idProduit DESC");
    }
    public static function create($conn, $nom, $volume, $prix, $quantite) {
        $stmt = $conn->prepare("INSERT INTO produit (nomProduit, volume, prixUnitaire, quantiteStock) VALUES (?,?,?,?)");
        $stmt->bind_param("ssdi", $nom, $volume, $prix, $quantite);
        return $stmt->execute();
    }
    public static function delete($conn, $id) {
        $stmt = $conn->prepare("DELETE FROM produit WHERE idProduit=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
