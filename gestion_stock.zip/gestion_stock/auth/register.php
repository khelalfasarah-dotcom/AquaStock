<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
ob_start();
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || !in_array($_SESSION['role'], ['admin','responsable_clients'])){
    ob_end_clean();
    header("Location: ../auth/login.php"); exit();
}
require_once "../config/db.php";
require_once "../controllers/ClientController.php";
require_once "../controllers/CommandeController.php";

$ctrl    = new ClientController($conn);
$ctrlCmd = new CommandeController($conn);
$msg     = '';
$isAdmin = ($_SESSION['role'] === 'admin');

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])){
    if($_POST['action']==='add'){
        $nom   = trim($_POST['nom'] ?? '');
        $adr   = trim($_POST['adresse'] ?? '');
        $tel   = trim($_POST['telephone'] ?? '');
        $login = trim($_POST['login'] ?? '');
        $pass  = trim($_POST['motdepasse'] ?? '');
        $dateNaissance = !empty($_POST['dateNaissance']) ? trim($_POST['dateNaissance']) : null;
        $sexe          = !empty($_POST['sexe'])          ? trim($_POST['sexe'])          : null;
        $email         = !empty($_POST['email'])         ? trim($_POST['email'])         : null;
        $willaya       = !empty($_POST['willaya'])        ? trim($_POST['willaya'])       : null;

        if($nom && $tel){
            // Insert client
            if($login && $pass){
                $hashed = password_hash($pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO client (nom,adresse,telephone,login,motdepasse,dateNaissance,sexe,email,willaya) VALUES (?,?,?,?,?,?,?,?,?)");
                $stmt->bind_param("sssssssss",$nom,$adr,$tel,$login,$hashed,$dateNaissance,$sexe,$email,$willaya);
                $stmt->execute();
            } else {
                $ctrl->store($nom,$adr,$tel,$dateNaissance,$sexe,$email,$willaya);
            }
            $idClient = $conn->insert_id;

            // Always create commande + facture
            $date         = !empty($_POST['order_date']) ? $_POST['order_date'] : date('Y-m-d');
            $modePaiement = trim($_POST['modePaiement'] ?? 'especes');
            $ctrlCmd->store($idClient, $date);
            $idCmd   = $conn->insert_id;
            $totalHT = 0;

            if(!empty($_POST['prod_id'])){
                foreach($_POST['prod_id'] as $k => $idProd){
                    $idProd      = (int)$idProd;
                    $qtyFardeaux = (int)($_POST['prod_qty'][$k] ?? 0);
                    if($idProd && $qtyFardeaux > 0){
                        $resP         = $conn->query("SELECT prixFardeau, btParFardeau FROM produit WHERE idProduit=$idProd");
                        $row          = $resP->fetch_assoc();
                        $prixFardeau  = (float)($row['prixFardeau']  ?? 0);
                        $btParFardeau = (int)($row['btParFardeau']   ?? 1);
                        $qtyBouteilles = $qtyFardeaux * $btParFardeau;
                        $sub           = $qtyFardeaux * $prixFardeau;
                        $totalHT      += $sub;
                        $l = $conn->prepare("INSERT INTO ligne_produit (quantite,sousTotal,idCommande,idProduit) VALUES (?,?,?,?)");
                        $l->bind_param("idii",$qtyBouteilles,$sub,$idCmd,$idProd);
                        $l->execute();
                        $conn->query("UPDATE produit SET quantiteStock=quantiteStock-$qtyBouteilles WHERE idProduit=$idProd");
                    }
                }
            }

            $conn->query("UPDATE commande SET etatCommande='validee' WHERE idCommande=$idCmd");
            $tva    = round($totalHT * 0.19, 2);
            $timbre = 25.00;
            $ttc    = round($totalHT + $tva + $timbre, 2);
            $now    = date('Y-m-d');
            $f = $conn->prepare("INSERT INTO facture (dateFacture,montantTotal,tva,timbre,montantTC,idCommande,modePaiement) VALUES (?,?,?,?,?,?,?)");
            if($f){ $f->bind_param("sddddis",$now,$totalHT,$tva,$timbre,$ttc,$idCmd,$modePaiement); $f->execute(); }

            $msg = 'success:Client, commande et facture ajoutés avec succès !';
        } else {
            $msg = 'error:Nom et téléphone sont obligatoires.';
        }

    } elseif($_POST['action']==='reset_password'){
        $id      = (int)$_POST['id'];
        $newpass = trim($_POST['new_password'] ?? '');
        $confirm = trim($_POST['confirm_password'] ?? '');
        if(strlen($newpass) < 6){ $msg = 'error:Le mot de passe doit contenir au moins 6 caractères.'; }
        elseif($newpass !== $confirm){ $msg = 'error:Les mots de passe ne correspondent pas.'; }
        else {
            $hashed = password_hash($newpass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE client SET motdepasse=? WHERE idClient=?");
            $stmt->bind_param("si", $hashed, $id);
            $stmt->execute();
            $msg = 'success:Mot de passe mis à jour avec succès !';
        }

    } elseif($_POST['action']==='delete'){
        $id = (int)$_POST['id'];
        $cmds = $conn->query("SELECT idCommande FROM commande WHERE idClient=$id");
        while($c = $cmds->fetch_assoc()){
            $cid = (int)$c['idCommande'];
            $conn->query("SET FOREIGN_KEY_CHECKS=0");
            $conn->query("DELETE FROM facture WHERE idCommande=$cid");
            $conn->query("DELETE FROM ligne_produit WHERE idCommande=$cid");
            $conn->query("SET FOREIGN_KEY_CHECKS=1");
        }
        $conn->query("DELETE FROM commande WHERE idClient=$id");
        $ctrl->destroy($id);
        $msg = 'success:Client et toutes ses données supprimés.';
    }
}

$clients  = $ctrl->index();
$produits = $conn->query("SELECT * FROM produit WHERE quantiteStock>0 ORDER BY nomProduit");
$pageTitle = "Clients";
ob_end_clean();
include_once "../components/header.php";
?>
<?php if($msg): list($type,$text) = explode(':', $msg, 2); ?>
<div class="alert alert-<?= $type==='success'?'success':'danger' ?>">
    <?= $type==='success'?'✅':'❌' ?> <?= htmlspecialchars($text) ?>
</div>
<?php endif; ?>

<!-- ══════════════ ADD CLIENT FORM ══════════════ -->
<div class="card" style="margin-bottom:24px;">
    <div class="section-title">➕ Ajouter un Client</div>
    <form method="POST" action="clients.php" id="addClientForm">
        <input type="hidden" name="action" value="add">

        <!-- ── Infos client ── -->
        <div style="font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;color:var(--accent);margin-bottom:12px;">👤 Informations du client</div>
        <div class="form-row">
            <div class="form-group">
                <label>Nom complet *</label>
                <input type="text" name="nom" placeholder="Nom du client" required>
            </div>
            <div class="form-group">
                <label>Adresse</label>
                <input type="text" name="adresse" placeholder="Ville / Adresse">
            </div>
            <div class="form-group">
                <label>Téléphone *</label>
                <input type="text" name="telephone" placeholder="0550 000 000" required>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Identifiant portail (optionnel)</label>
                <input type="text" name="login" placeholder="Nom d'utilisateur">
            </div>
            <div class="form-group">
                <label>Mot de passe portail (optionnel)</label>
                <input type="password" name="motdepasse" placeholder="Mot de passe">
            </div>
            <div class="form-group">
                <label>Email (optionnel)</label>
                <input type="email" name="email" placeholder="client@exemple.com">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Date de naissance (optionnel)</label>
                <input type="date" name="dateNaissance">
            </div>
            <div class="form-group">
                <label>Sexe (optionnel)</label>
                <select name="sexe">
                    <option value="">— Sélectionner —</option>
                    <option value="homme">👨 Homme</option>
                    <option value="femme">👩 Femme</option>
                </select>
            </div>
            <div class="form-group">
                <label>Wilaya (optionnel)</label>
                <select name="willaya">
                    <option value="">— Sélectionner —</option>
                    <option value="01 - Adrar">01 - Adrar</option>
                    <option value="02 - Chlef">02 - Chlef</option>
                    <option value="03 - Laghouat">03 - Laghouat</option>
                    <option value="04 - Oum El Bouaghi">04 - Oum El Bouaghi</option>
                    <option value="05 - Batna">05 - Batna</option>
                    <option value="06 - Béjaïa">06 - Béjaïa</option>
                    <option value="07 - Biskra">07 - Biskra</option>
                    <option value="08 - Béchar">08 - Béchar</option>
                    <option value="09 - Blida">09 - Blida</option>
                    <option value="10 - Bouira">10 - Bouira</option>
                    <option value="11 - Tamanrasset">11 - Tamanrasset</option>
                    <option value="12 - Tébessa">12 - Tébessa</option>
                    <option value="13 - Tlemcen">13 - Tlemcen</option>
                    <option value="14 - Tiaret">14 - Tiaret</option>
                    <option value="15 - Tizi Ouzou">15 - Tizi Ouzou</option>
                    <option value="16 - Alger">16 - Alger</option>
                    <option value="17 - Djelfa">17 - Djelfa</option>
                    <option value="18 - Jijel">18 - Jijel</option>
                    <option value="19 - Sétif">19 - Sétif</option>
                    <option value="20 - Saïda">20 - Saïda</option>
                    <option value="21 - Skikda">21 - Skikda</option>
                    <option value="22 - Sidi Bel Abbès">22 - Sidi Bel Abbès</option>
                    <option value="23 - Annaba">23 - Annaba</option>
                    <option value="24 - Guelma">24 - Guelma</option>
                    <option value="25 - Constantine">25 - Constantine</option>
                    <option value="26 - Médéa">26 - Médéa</option>
                    <option value="27 - Mostaganem">27 - Mostaganem</option>
                    <option value="28 - M'Sila">28 - M'Sila</option>
                    <option value="29 - Mascara">29 - Mascara</option>
                    <option value="30 - Ouargla">30 - Ouargla</option>
                    <option value="31 - Oran">31 - Oran</option>
                    <option value="32 - El Bayadh">32 - El Bayadh</option>
                    <option value="33 - Illizi">33 - Illizi</option>
                    <option value="34 - Bordj Bou Arréridj">34 - Bordj Bou Arréridj</option>
                    <option value="35 - Boumerdès">35 - Boumerdès</option>
                    <option value="36 - El Tarf">36 - El Tarf</option>
                    <option value="37 - Tindouf">37 - Tindouf</option>
                    <option value="38 - Tissemsilt">38 - Tissemsilt</option>
                    <option value="39 - El Oued">39 - El Oued</option>
                    <option value="40 - Khenchela">40 - Khenchela</option>
                    <option value="41 - Souk Ahras">41 - Souk Ahras</option>
                    <option value="42 - Tipaza">42 - Tipaza</option>
                    <option value="43 - Mila">43 - Mila</option>
                    <option value="44 - Aïn Defla">44 - Aïn Defla</option>
                    <option value="45 - Naâma">45 - Naâma</option>
                    <option value="46 - Aïn Témouchent">46 - Aïn Témouchent</option>
                    <option value="47 - Ghardaïa">47 - Ghardaïa</option>
                    <option value="48 - Relizane">48 - Relizane</option>
                    <option value="49 - Timimoun">49 - Timimoun</option>
                    <option value="50 - Bordj Badji Mokhtar">50 - Bordj Badji Mokhtar</option>
                    <option value="51 - Ouled Djellal">51 - Ouled Djellal</option>
                    <option value="52 - Béni Abbès">52 - Béni Abbès</option>
                    <option value="53 - In Salah">53 - In Salah</option>
                    <option value="54 - In Guezzam">54 - In Guezzam</option>
                    <option value="55 - Touggourt">55 - Touggourt</option>
                    <option value="56 - Djanet">56 - Djanet</option>
                    <option value="57 - El M'Ghair">57 - El M'Ghair</option>
                    <option value="58 - El Meniaa">58 - El Meniaa</option>
                </select>
            </div>
        </div>

        <!-- ── Commande + Facture (always visible) ── -->
        <div style="border-top:1px solid var(--border);margin:20px 0 16px;"></div>
        <div style="font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;color:var(--accent);margin-bottom:12px;">📦 Commande + Facture</div>

        <div class="form-row" style="margin-bottom:12px;">
            <div class="form-group" style="max-width:200px;">
                <label>Date commande</label>
                <input type="date" name="order_date" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="form-group" style="max-width:220px;">
                <label>Mode de paiement</label>
                <select name="modePaiement">
                    <option value="especes">💵 Espèces</option>
                    <option value="cheque">📝 Chèque</option>
                    <option value="virement">🏦 Virement</option>
                    <option value="ccp">📮 CCP / Baridimob</option>
                    <option value="carte">💳 Carte bancaire</option>
                </select>
            </div>
        </div>

        <div id="orderLines">
            <div class="order-line form-row" style="align-items:flex-end;margin-bottom:8px;">
                <div class="form-group">
                    <label>Produit</label>
                    <select name="prod_id[]" onchange="updateQtyMax(this)">
                        <option value="">— Sélectionner un produit —</option>
                        <?php $produits->data_seek(0); while($p=$produits->fetch_assoc()): ?>
                        <option value="<?= $p['idProduit'] ?>"
                            data-prix="<?= $p['prixFardeau'] ?>"
                            data-bt="<?= $p['btParFardeau'] ?>"
                            data-stock="<?= floor($p['quantiteStock'] / $p['btParFardeau']) ?>">
                            <?= htmlspecialchars($p['nomProduit']) ?> (<?= $p['volume'] ?>)
                            — <?= number_format($p['prixFardeau'],2) ?> DZD/fardeau
                            (<?= $p['btParFardeau'] ?> bt) — Stock: <?= floor($p['quantiteStock'] / $p['btParFardeau']) ?> fard.
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group" style="max-width:130px;">
                    <label>Nb fardeaux</label>
                    <input type="number" name="prod_qty[]" min="1" value="1" oninput="recalcTotal()">
                </div>
                <div class="form-group" style="max-width:130px;">
                    <label>Sous-total</label>
                    <input type="text" class="line-sub" readonly
                        style="background:rgba(0,180,216,0.07);color:var(--accent);font-weight:600;" value="0.00 DZD">
                </div>
                <div class="form-group" style="flex:0;min-width:auto;">
                    <label>&nbsp;</label>
                    <button type="button" class="btn btn-danger btn-sm"
                        onclick="this.closest('.order-line').remove(); recalcTotal()">✕</button>
                </div>
            </div>
        </div>
        <button type="button" class="btn btn-ghost btn-sm" onclick="addLine()" style="margin-top:4px;">
            + Ajouter un produit
        </button>

        <!-- Totals summary -->
        <div style="margin-top:16px;background:rgba(0,180,216,0.06);border:1px solid rgba(0,180,216,0.2);border-radius:10px;padding:14px 18px;display:flex;gap:32px;flex-wrap:wrap;font-size:14px;">
            <div>Total HT : <strong id="dispHT" style="color:var(--accent);">0.00 DZD</strong></div>
            <div>TVA 19% : <strong id="dispTVA" style="color:#f59e0b;">0.00 DZD</strong></div>
            <div>Timbre : <strong style="color:#94a3b8;">25.00 DZD</strong></div>
            <div>Total TTC : <strong id="dispTTC" style="color:#22c55e;font-size:16px;">25.00 DZD</strong></div>
        </div>

        <div style="margin-top:20px;">
            <button class="btn btn-primary" type="submit">✅ Ajouter Client + Commande + Facture</button>
        </div>
    </form>
</div>

<!-- ══════════════ CLIENT LIST ══════════════ -->
<div class="card">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <span>👥 Liste des Clients</span>
        <div style="display:flex;align-items:center;gap:8px;">
            <input type="text" id="searchClient" placeholder="🔍 Rechercher par nom ou téléphone…"
                oninput="filterClients()"
                style="background:rgba(0,0,0,0.35);border:1px solid rgba(0,180,216,0.25);border-radius:9px;padding:8px 14px;color:#e2e8f0;font-size:13px;font-family:'Outfit',sans-serif;outline:none;width:280px;transition:.2s;"
                onfocus="this.style.borderColor='rgba(0,180,216,0.7)'"
                onblur="this.style.borderColor='rgba(0,180,216,0.25)'">
            <span id="clientCount" style="font-size:12px;color:var(--muted);white-space:nowrap;"></span>
        </div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>ID</th><th>Nom</th><th>Adresse</th><th>Wilaya</th>
                <th>Téléphone</th><th>Email</th><th>Date naissance</th>
                <th>Sexe</th><th>Identifiant</th><th>Mot de passe</th><th>Actions</th>
            </tr>
        </thead>
        <tbody id="clientTableBody">
        <?php if($clients->num_rows === 0): ?>
        <tr><td colspan="11" class="empty-state">Aucun client enregistré.</td></tr>
        <?php else: while($r = $clients->fetch_assoc()): ?>
        <tr data-search="<?= strtolower(htmlspecialchars($r['nom'])) ?> <?= htmlspecialchars($r['telephone']) ?>">
            <td><span class="badge badge-blue">#<?= $r['idClient'] ?></span></td>
            <td><?= htmlspecialchars($r['nom']) ?></td>
            <td><?= htmlspecialchars($r['adresse'] ?: '—') ?></td>
            <td><?= htmlspecialchars($r['willaya'] ?? '—') ?></td>
            <td><?= htmlspecialchars($r['telephone']) ?></td>
            <td><?= htmlspecialchars($r['email'] ?? '—') ?></td>
            <td><?= $r['dateNaissance'] ? htmlspecialchars(date('d/m/Y', strtotime($r['dateNaissance']))) : '—' ?></td>
            <td><?php
                $sexeIcons = ['homme'=>'👨 Homme','femme'=>'👩 Femme','autre'=>'🧑 Autre'];
                echo !empty($r['sexe']) ? ($sexeIcons[$r['sexe']] ?? htmlspecialchars($r['sexe'])) : '—';
            ?></td>
            <td><?= htmlspecialchars($r['login'] ?? '—') ?></td>
            <td>
                <?php if(!empty($r['motdepasse'])): ?>
                <span style="color:#22d3a0;font-size:12px;">✅ Défini</span>
                <?php else: ?>
                <span style="color:#f43f5e;font-size:12px;">❌ Non défini</span>
                <?php endif; ?>
                <button class="btn btn-ghost btn-sm" style="margin-left:6px;font-size:11px;"
                    onclick="openResetModal(<?= $r['idClient'] ?>, '<?= htmlspecialchars(addslashes($r['nom'])) ?>')">
                    🔑 Changer
                </button>
            </td>
            <td style="display:flex;gap:6px;flex-wrap:wrap;">
                <form method="POST" action="clients.php" style="display:inline;"
                    onsubmit="return confirm('Supprimer ce client et toutes ses commandes/factures ?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $r['idClient'] ?>">
                    <button class="btn btn-danger btn-sm" type="submit">🗑 Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══════════════ RESET PASSWORD MODAL ══════════════ -->
<div id="resetModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:1000;align-items:center;justify-content:center;">
    <div style="background:#0a1628;border:1px solid rgba(0,180,216,0.3);border-radius:16px;padding:32px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(0,0,0,0.5);">
        <h3 style="color:#00b4d8;margin-bottom:6px;font-size:18px;">🔑 Changer le mot de passe</h3>
        <p style="color:#64748b;font-size:13px;margin-bottom:20px;">Client : <strong id="resetClientName" style="color:#e2e8f0;"></strong></p>
        <form method="POST" action="clients.php">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="id" id="resetClientId">
            <div style="margin-bottom:12px;">
                <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.6px;color:#64748b;display:block;margin-bottom:6px;">Nouveau mot de passe (min. 6 caractères)</label>
                <div style="position:relative;">
                    <input type="password" name="new_password" id="resetPassword" placeholder="Nouveau mot de passe"
                        style="width:100%;background:rgba(0,0,0,0.4);border:1px solid rgba(0,180,216,0.2);border-radius:8px;padding:10px 40px 10px 14px;color:#e2e8f0;font-size:14px;outline:none;font-family:inherit;"
                        required minlength="6">
                    <span onclick="togglePw('resetPassword')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:15px;color:#64748b;user-select:none;">👁</span>
                </div>
            </div>
            <div style="margin-bottom:20px;">
                <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.6px;color:#64748b;display:block;margin-bottom:6px;">Confirmer le mot de passe</label>
                <div style="position:relative;">
                    <input type="password" name="confirm_password" id="resetConfirm" placeholder="Répéter le mot de passe"
                        style="width:100%;background:rgba(0,0,0,0.4);border:1px solid rgba(0,180,216,0.2);border-radius:8px;padding:10px 40px 10px 14px;color:#e2e8f0;font-size:14px;outline:none;font-family:inherit;"
                        required minlength="6">
                    <span onclick="togglePw('resetConfirm')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:15px;color:#64748b;user-select:none;">👁</span>
                </div>
                <div id="pwMatchMsg" style="font-size:12px;margin-top:5px;"></div>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="btn btn-primary" style="flex:1;">✅ Enregistrer</button>
                <button type="button" class="btn btn-ghost" onclick="closeResetModal()" style="flex:1;">Annuler</button>
            </div>
        </form>
    </div>
</div>

<script>
/* ── Search ── */
function filterClients(){
    const q = document.getElementById('searchClient').value.toLowerCase().trim();
    const rows = document.querySelectorAll('#clientTableBody tr[data-search]');
    let visible = 0;
    rows.forEach(r => {
        const match = !q || r.dataset.search.includes(q);
        r.style.display = match ? '' : 'none';
        if(match) visible++;
    });
    const total = rows.length;
    document.getElementById('clientCount').textContent = q ? `${visible} / ${total} résultats` : `${total} client(s)`;
}
window.addEventListener('DOMContentLoaded', filterClients);

/* ── Order lines ── */
const firstLine = document.querySelector('.order-line').cloneNode(true);
function addLine(){
    const clone = firstLine.cloneNode(true);
    clone.querySelector('select').value = '';
    clone.querySelector('input[type=number]').value = 1;
    clone.querySelector('.line-sub').value = '0.00 DZD';
    clone.querySelector('select').addEventListener('change', function(){ updateLineSub(clone); recalcTotal(); });
    clone.querySelector('input[type=number]').addEventListener('input', function(){ updateLineSub(clone); recalcTotal(); });
    clone.querySelector('button').onclick = function(){ clone.remove(); recalcTotal(); };
    document.getElementById('orderLines').appendChild(clone);
}

function updateLineSub(line){
    const sel = line.querySelector('select');
    const opt = sel.options[sel.selectedIndex];
    const qty = parseFloat(line.querySelector('input[type=number]').value) || 0;
    const prix = parseFloat(opt.dataset.prix) || 0;
    const sub = qty * prix;
    line.querySelector('.line-sub').value = sub.toFixed(2) + ' DZD';
}

function recalcTotal(){
    let ht = 0;
    document.querySelectorAll('.order-line').forEach(line => {
        updateLineSub(line);
        const sel = line.querySelector('select');
        const opt = sel.options[sel.selectedIndex];
        const qty = parseFloat(line.querySelector('input[type=number]').value) || 0;
        const prix = parseFloat(opt.dataset.prix) || 0;
        ht += qty * prix;
    });
    const tva = ht * 0.19;
    const timbre = 25;
    const ttc = ht + tva + timbre;
    document.getElementById('dispHT').textContent  = ht.toFixed(2)  + ' DZD';
    document.getElementById('dispTVA').textContent = tva.toFixed(2) + ' DZD';
    document.getElementById('dispTTC').textContent = ttc.toFixed(2) + ' DZD';
}

// Wire up the first line
document.querySelector('.order-line select').addEventListener('change', function(){
    updateLineSub(this.closest('.order-line')); recalcTotal();
});
document.querySelector('.order-line input[type=number]').addEventListener('input', function(){
    updateLineSub(this.closest('.order-line')); recalcTotal();
});

/* ── Reset password modal ── */
function openResetModal(id, name){
    document.getElementById('resetClientId').value = id;
    document.getElementById('resetClientName').textContent = name;
    document.getElementById('resetPassword').value = '';
    document.getElementById('resetConfirm').value = '';
    document.getElementById('pwMatchMsg').textContent = '';
    document.getElementById('resetModal').style.display = 'flex';
}
function closeResetModal(){ document.getElementById('resetModal').style.display = 'none'; }
function togglePw(id){ const f=document.getElementById(id); f.type=f.type==='password'?'text':'password'; }
document.getElementById('resetConfirm').addEventListener('input', function(){
    const p1 = document.getElementById('resetPassword').value;
    const msg = document.getElementById('pwMatchMsg');
    if(!this.value){ msg.textContent=''; return; }
    if(this.value===p1){ msg.textContent='✅ Les mots de passe correspondent'; msg.style.color='#22c55e'; }
    else { msg.textContent='❌ Les mots de passe ne correspondent pas'; msg.style.color='#f87171'; }
});
document.getElementById('resetModal').querySelector('form').addEventListener('submit',function(e){
    const p1=document.getElementById('resetPassword').value;
    const p2=document.getElementById('resetConfirm').value;
    if(p1!==p2){ e.preventDefault(); document.getElementById('pwMatchMsg').textContent='❌ Les mots de passe ne correspondent pas'; document.getElementById('pwMatchMsg').style.color='#f87171'; }
});
</script>

<?php include_once "../components/footer.php"; ?>