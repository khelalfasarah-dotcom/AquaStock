<?php
require_once __DIR__ . '/../config/session.php';
include __DIR__ . "/../config/db.php";

$error = "";

if (isset($_POST['btn_login'])) {
    $identifier = trim($_POST['login']);
    $password   = trim($_POST['password']);
    $found      = false;

    // ─── 1. Chercher dans table responsable (admin + responsable_clients) ───
    $like = '%' . $identifier . '%';
    $stmt = $conn->prepare("SELECT * FROM responsable WHERE login=? OR email=? OR ville=? OR localisation LIKE ? LIMIT 1");
    $stmt->bind_param("ssss", $identifier, $identifier, $identifier, $like);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows === 1) {
        $user = $res->fetch_assoc();
        $hash = $user['motdepasse'];
        $ok   = password_verify($password, $hash) || ($password === $hash && !str_starts_with($hash, '$'));
        if ($ok) {
            if (!str_starts_with($hash, '$')) {
                $nh = password_hash($password, PASSWORD_DEFAULT);
                $u  = $conn->prepare("UPDATE responsable SET motdepasse=? WHERE idResponsable=?");
                $uid = $user['idResponsable'];
                $u->bind_param("si", $nh, $uid); $u->execute();
            }
            $role = $user['role'] ?? 'admin';
            $_SESSION['user'] = $user['nom'];
            $_SESSION['role'] = $role;
            header("Location: " . ($role === 'admin' ? "../views/dashboard.php" : "../views/clients.php"));
            exit();
        } else {
            $error = "Identifiant ou mot de passe incorrect.";
        }
        $found = true;
    }
    $stmt->close();

    // ─── 2. Chercher dans table client (login ou adresse) ───
    if (!$found && $error === "") {
        $like2 = '%' . $identifier . '%';
        $s2 = $conn->prepare("SELECT * FROM client WHERE login=? OR email=? OR adresse LIKE ? LIMIT 1");
        $s2->bind_param("sss", $identifier, $identifier, $like2);
        $s2->execute();
        $r2 = $s2->get_result();
        if ($r2 && $r2->num_rows === 1) {
            $u2 = $r2->fetch_assoc();
            $h2 = $u2['motdepasse'];
            $ok2 = password_verify($password, $h2) || ($password === $h2 && !str_starts_with($h2, '$'));
            if ($ok2) {
                if (!str_starts_with($h2, '$')) {
                    $nh2 = password_hash($password, PASSWORD_DEFAULT);
                    $upd = $conn->prepare("UPDATE client SET motdepasse=? WHERE idClient=?");
                    $upd->bind_param("si", $nh2, $u2['idClient']); $upd->execute();
                }
                $_SESSION['client_id']   = $u2['idClient'];
                $_SESSION['client_name'] = $u2['nom'];
                $_SESSION['role']        = 'client';
                    header("Location: ../client/home.php");
                exit();
            } else {
                $error = "Identifiant, adresse ou mot de passe incorrect.";
            }
            $found = true;
        }
        $s2->close();
    }

    if (!$found && $error === "") $error = "Aucun compte trouvé avec cet identifiant.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Connexion — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh;
  overflow-x:hidden;
  overflow-y:auto;
}

/* ─── SCROLL PROGRESS LINE ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0;
  transition:width 0.1s linear;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background: rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background: linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius: 10px; box-shadow: 0 0 8px rgba(0,212,245,0.5);
}
* { scrollbar-width: thin; scrollbar-color: var(--accent) rgba(0,212,245,0.04); }

/* ─── AMBIENT ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 90% 70% at 20% 50%, rgba(0,119,168,0.25) 0%, transparent 60%),
    radial-gradient(ellipse 60% 60% at 85% 15%, rgba(0,212,245,0.08) 0%, transparent 55%),
    radial-gradient(ellipse 40% 40% at 10% 90%, rgba(0,255,204,0.05) 0%, transparent 50%);
}

/* ─── GRID ─── */
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}

/* ─── NOISE ─── */
body::before {
  content:''; position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.35;
}

/* ─── PARTICLES ─── */
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background:radial-gradient(circle at 30% 30%, var(--accent), rgba(0,119,168,0.3));
  animation:rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
@keyframes rise {
  0%   { transform:translateY(100vh) scale(0.2); opacity:0; }
  10%  { opacity:0.5; }
  90%  { opacity:0.1; }
  100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
}

/* ─── LAYOUT ─── */
.split {
  position:relative; z-index:10;
  display:flex; width:100%; min-height:100vh;
  align-items:stretch;
}

/* ═══ LEFT PANEL ═══ */
.left {
  flex:1;
  display:flex; flex-direction:column; justify-content:center; padding:70px 64px;
  border-right:1px solid var(--border);
  position:relative; overflow:hidden;
  animation:slideL .8s cubic-bezier(.22,1,.36,1) both;
}
@keyframes slideL { from{opacity:0;transform:translateX(-32px)} to{opacity:1;transform:translateX(0)} }
.left::after {
  content:''; position:absolute; right:0; top:15%; bottom:15%;
  width:1px;
  background:linear-gradient(to bottom, transparent, var(--accent), transparent);
  opacity:0.3;
}

.brand { display:flex; align-items:center; gap:14px; margin-bottom:56px; }
.brand-icon {
  width:52px; height:52px; border-radius:14px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center;
  font-size:24px; box-shadow:0 0 36px rgba(0,212,245,0.4);
  animation:float 4s ease-in-out infinite;
}
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
.brand-name { font-family:'Bebas Neue',sans-serif; font-size:28px; letter-spacing:3px; }
.brand-name span { color:var(--accent); }

.left-headline {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(44px,5vw,68px);
  line-height:0.95; letter-spacing:1px; margin-bottom:24px;
}
.left-headline .hl  { color:transparent; -webkit-text-stroke:1.5px var(--accent); display:block; }
.left-headline .hl2 { color:var(--accent); display:block; }

.left-desc { font-size:14px; color:var(--muted2); line-height:1.8; max-width:380px; margin-bottom:48px; font-weight:300; }

.feat-list { display:flex; flex-direction:column; gap:10px; max-width:380px; }
.feat {
  display:flex; align-items:center; gap:14px;
  padding:13px 16px; border-radius:12px;
  background:var(--surface); border:1px solid var(--border); transition:all .3s;
}
.feat:hover { border-color:var(--border2); background:var(--surface2); transform:translateX(6px); box-shadow:-3px 0 0 var(--accent); }
.feat-icon { width:34px; height:34px; border-radius:9px; background:rgba(0,212,245,0.1); display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0; }
.feat-text strong { display:block; font-size:12px; font-weight:600; color:var(--text); margin-bottom:1px; }
.feat-text span   { font-size:11px; color:var(--muted); }

.status-badge {
  display:inline-flex; align-items:center; gap:9px;
  margin-top:36px; padding:8px 16px;
  border:1px solid rgba(0,255,204,0.2); border-radius:100px;
  font-size:11px; color:var(--accent3); background:rgba(0,255,204,0.05);
}
.status-dot { width:7px; height:7px; border-radius:50%; background:var(--accent3); position:relative; }
.status-dot::after {
  content:''; position:absolute; inset:-3px; border-radius:50%;
  border:1px solid var(--accent3); animation:ripple 2s ease-in-out infinite;
}
@keyframes ripple { 0%,100%{transform:scale(1);opacity:.8} 50%{transform:scale(2);opacity:0} }

/* ═══ RIGHT PANEL ═══ */
.right {
  width:460px; flex-shrink:0;
  display:flex; flex-direction:column; justify-content:center;
  padding:60px 52px; position:relative;
  animation:slideR .8s cubic-bezier(.22,1,.36,1) both .1s;
}
@keyframes slideR { from{opacity:0;transform:translateX(32px)} to{opacity:1;transform:translateX(0)} }

.back-btn {
  position:absolute; top:28px; left:28px;
  display:flex; align-items:center; gap:7px;
  padding:8px 15px; border:1px solid var(--border); border-radius:9px;
  text-decoration:none; color:var(--muted); font-size:12px; font-weight:500;
  background:rgba(2,11,20,0.7); backdrop-filter:blur(10px); transition:all .25s;
}
.back-btn:hover { color:var(--accent); border-color:var(--border2); background:rgba(0,212,245,0.05); }

.portal-tag {
  display:inline-flex; align-items:center; gap:8px;
  padding:6px 14px; border:1px solid var(--border2); border-radius:100px;
  font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase;
  color:var(--accent); background:rgba(0,212,245,0.05);
  margin-bottom:24px; width:fit-content;
}
.portal-dot { width:6px; height:6px; border-radius:50%; background:var(--accent); box-shadow:0 0 8px var(--accent); animation:blink 2s ease-in-out infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.2} }

.form-title { font-family:'Bebas Neue',sans-serif; font-size:42px; letter-spacing:1px; line-height:1; margin-bottom:6px; }
.form-sub   { font-size:13px; color:var(--muted); margin-bottom:36px; line-height:1.6; font-weight:300; }

/* ─── ALERT ─── */
.alert {
  display:flex; align-items:center; gap:10px;
  padding:13px 16px; border-radius:11px; margin-bottom:24px;
  font-size:13px; font-weight:500;
  background:rgba(244,63,94,0.08); border:1px solid rgba(244,63,94,0.25); color:#fca5a5;
  animation:shake .4s ease;
}
@keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }

/* ─── FORM ─── */
.form-group { margin-bottom:20px; }
.form-group label { display:block; font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:var(--muted); margin-bottom:9px; }
.form-group input {
  width:100%; padding:14px 16px; border-radius:11px;
  border:1.5px solid var(--border);
  background:rgba(0,0,0,0.35); color:var(--text);
  font-size:14px; font-family:'Outfit',sans-serif;
  outline:none; transition:all .25s;
}
.form-group input:focus {
  border-color:var(--accent); background:rgba(0,212,245,0.04);
  box-shadow:0 0 0 4px rgba(0,212,245,0.08), 0 0 20px rgba(0,212,245,0.1);
}
.form-group input::placeholder { color:rgba(90,128,152,0.5); }

.pw-wrap { position:relative; }
.pw-wrap input { padding-right:48px; }
.pw-eye { position:absolute; right:15px; top:50%; transform:translateY(-50%); cursor:pointer; font-size:15px; color:var(--muted); transition:color .2s; user-select:none; }
.pw-eye:hover { color:var(--accent); }

/* ─── SUBMIT BTN ─── */
.btn-submit {
  width:100%; padding:15px; border:none; border-radius:11px; margin-top:6px;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; font-family:'Bebas Neue',sans-serif;
  font-size:20px; letter-spacing:2px;
  cursor:pointer; transition:all .25s;
  position:relative; overflow:hidden;
  box-shadow:0 0 24px rgba(0,212,245,0.2);
}
.btn-submit::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
  opacity:0; transition:opacity .25s;
}
.btn-submit:hover { transform:translateY(-2px); box-shadow:0 0 40px rgba(0,212,245,0.4); }
.btn-submit:hover::before { opacity:1; }
.btn-submit:active { transform:translateY(0); }

/* ─── CLIENT TOGGLE ─── */
.client-toggle {
  width:100%; margin-top:12px; padding:12px 16px;
  border:1.5px dashed var(--border2); border-radius:11px;
  background:transparent; color:var(--muted2);
  font-family:'Outfit',sans-serif; font-size:13px; font-weight:500;
  cursor:pointer; transition:all .25s;
  display:flex; align-items:center; justify-content:center; gap:8px;
}
.client-toggle:hover { border-color:var(--accent); color:var(--accent); background:rgba(0,212,245,0.04); }
.client-toggle.active { border-color:var(--accent3); color:var(--accent3); background:rgba(0,255,204,0.04); }

/* ─── DIVIDER ─── */
.or-divider {
  display:flex; align-items:center; gap:12px;
  color:var(--muted); font-size:11px; letter-spacing:1px; margin:26px 0;
}
.or-divider::before,.or-divider::after { content:''; flex:1; height:1px; background:var(--border); }

/* ─── EXTRA LINKS ─── */
.extra-links { display:flex; flex-direction:column; gap:10px; }
.extra-link {
  display:flex; align-items:center; gap:12px;
  padding:13px 16px; border:1px solid var(--border); border-radius:11px;
  text-decoration:none; color:var(--muted2); font-size:13px; font-weight:500;
  background:var(--surface); transition:all .25s;
}
.extra-link:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,0,0,0.3); }
.extra-link .el-arrow { margin-left:auto; font-size:14px; color:var(--muted); transition:all .25s; }
.extra-link:hover .el-arrow { color:var(--accent); transform:translateX(4px); }
.el-icon { width:32px; height:32px; border-radius:8px; background:rgba(0,212,245,0.08); border:1px solid var(--border); display:flex; align-items:center; justify-content:center; font-size:14px; flex-shrink:0; }

/* ─── MOBILE ─── */
@media(max-width:860px){
  .left { display:none; }
  .right { width:100%; padding:40px 28px; }
  .back-btn { top:20px; left:20px; }
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="particles" id="particles"></div>

<div class="split">

  <!-- ═══ LEFT ═══ -->
  <div class="left">
    <div class="brand">
      <div class="brand-icon">💧</div>
      <div class="brand-name"><span>Aqua</span>Stock</div>
    </div>

    <h1 class="left-headline">
      Portail<br>
      <span class="hl">Connexion</span>
      <span class="hl2">Sécurisée</span>
    </h1>

    <p class="left-desc">
      Connectez-vous avec votre <strong style="color:var(--accent)">identifiant</strong> ou votre <strong style="color:var(--accent)">adresse</strong> — le système détecte votre rôle et vous redirige automatiquement.
    </p>

    <div class="feat-list">
      <div class="feat">
        <div class="feat-icon">🛡️</div>
        <div class="feat-text">
          <strong>Administrateur</strong>
          <span>Tableau de bord, stocks, commandes, factures, équipe</span>
        </div>
      </div>
      <div class="feat">
        <div class="feat-icon">📋</div>
        <div class="feat-text">
          <strong>Responsable</strong>
          <span>Gestion des clients et factures</span>
        </div>
      </div>
      <div class="feat">
        <div class="feat-icon">🛒</div>
        <div class="feat-text">
          <strong>Client</strong>
          <span>Catalogue, commandes et paiements</span>
        </div>
      </div>
    </div>

    <div class="status-badge">
      <div class="status-dot"></div>
      Tous les services opérationnels
    </div>
  </div>

  <!-- ═══ RIGHT ═══ -->
  <div class="right">
    <a href="index.php" class="back-btn">← Accueil</a>

    <div class="portal-tag">
      <span class="portal-dot"></span>
      Accès Unifié
    </div>

    <div class="form-title">Connexion</div>
    <p class="form-sub">Identifiant ou adresse — votre espace s'ouvre automatiquement.</p>

    <?php if ($error): ?>
    <div class="alert">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off" id="loginForm">
      <div class="form-group">
        <label>Login ou Adresse</label>
        <input type="text" name="login" placeholder="votre identifiant ou adresse"
          value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label>Mot de passe</label>
        <div class="pw-wrap">
          <input type="password" name="password" id="pw" placeholder="••••••••" required>
          <span class="pw-eye" onclick="togglePw()" title="Afficher/Masquer">👁</span>
        </div>
      </div>
      <button type="submit" name="btn_login" class="btn-submit">Se Connecter →</button>
    </form>

    <div class="or-divider">autres options</div>

    <div class="extra-links">
      <a href="forgot_password.php" class="extra-link">
        <div class="el-icon">🔑</div>
        Mot de passe oublié
        <span class="el-arrow">→</span>
      </a>
      <a href="register.php" class="extra-link">
        <div class="el-icon">✨</div>
        Créer un compte client
        <span class="el-arrow">→</span>
      </a>
    </div>
  </div>
</div>

<script>
// Scroll progress line
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

// Particles
const c = document.getElementById('particles');
for(let i=0;i<35;i++){
  const d=document.createElement('div'); d.className='drop';
  const s=1.5+Math.random()*4;
  d.style.cssText=`left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*15}s;`;
  c.appendChild(d);
}

// Password toggle
function togglePw(){
  const pw=document.getElementById('pw');
  const eye=document.querySelector('.pw-eye');
  pw.type = pw.type==='password' ? 'text' : 'password';
  eye.textContent = pw.type==='password' ? '👁' : '🙈';
}

// Input glow on type
document.querySelectorAll('input').forEach(inp=>{
  inp.addEventListener('input',()=>{
    inp.style.borderColor = inp.value ? 'rgba(0,212,245,0.5)' : '';
  });
});
</script>
</body>
</html>