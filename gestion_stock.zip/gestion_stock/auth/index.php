<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AquaStock — Gestion Usine d'Eau</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent: #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg: #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2: rgba(0,212,245,0.08);
  --border: rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text: #e4f4ff;
  --muted: #5a8098;
  --muted2: #8ab0c8;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family: 'Outfit', sans-serif;
  background: var(--bg);
  color: var(--text);
  overflow-x: hidden;
}

/* ─── CUSTOM BLUE SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background: rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background: linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius: 10px;
  box-shadow: 0 0 8px rgba(0,212,245,0.5);
}
::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(to bottom, var(--accent), var(--accent3));
  box-shadow: 0 0 14px rgba(0,212,245,0.8);
}
* { scrollbar-width: thin; scrollbar-color: var(--accent) rgba(0,212,245,0.04); }

/* ─── NOISE OVERLAY ─── */
body::before {
  content:'';
  position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.4;
}

/* ─── AMBIENT BG ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 100% 70% at 50% -10%, rgba(0,119,168,0.3) 0%, transparent 60%),
    radial-gradient(ellipse 50% 50% at 90% 80%, rgba(0,212,245,0.07) 0%, transparent 50%),
    radial-gradient(ellipse 40% 40% at 10% 90%, rgba(0,255,204,0.05) 0%, transparent 50%);
}

/* ─── GRID ─── */
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size: 60px 60px;
}

/* ─── SCROLLING BLUE LINE (horizontal) ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background: linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow: 0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  transition: width 0.1s linear;
  border-radius:0 2px 2px 0;
}

/* ─── PARTICLES ─── */
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background: radial-gradient(circle at 30% 30%, var(--accent), rgba(0,119,168,0.3));
  animation: rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
.drop.glow { box-shadow:0 0 6px var(--accent); }
@keyframes rise {
  0%   { transform:translateY(100vh) scale(0.2); opacity:0; }
  10%  { opacity:0.6; }
  90%  { opacity:0.1; }
  100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
}

/* ─── NAV ─── */
nav {
  position:fixed; top:0; left:0; right:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px;
  height:70px;
  background: rgba(2,11,20,0.7);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border);
  transition: background 0.3s;
}
.nav-logo {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text);
}
.nav-logo-icon {
  width:38px; height:38px; border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center;
  font-size:18px;
  box-shadow:0 0 20px rgba(0,212,245,0.4);
}
.nav-links { display:flex; align-items:center; gap:28px; }
.nav-links a {
  font-size:13px; font-weight:500; color:var(--muted2);
  text-decoration:none; transition:color 0.2s;
  letter-spacing:0.3px;
}
.nav-links a:hover { color:var(--accent); }
.nav-cta {
  padding:8px 20px; border-radius:8px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  color:#020b14 !important; font-weight:700 !important;
  font-size:12px !important;
  box-shadow:0 0 20px rgba(0,212,245,0.25);
  transition:box-shadow 0.3s, transform 0.2s !important;
}
.nav-cta:hover { box-shadow:0 0 30px rgba(0,212,245,0.45) !important; transform:translateY(-1px) !important; }

/* ─── HERO ─── */
.hero {
  position:relative; z-index:10;
  min-height:100vh;
  display:grid;
  grid-template-columns:1fr 1fr;
  padding-top:70px;
}

/* ─── HERO LEFT ─── */
.hero-left {
  padding:80px 60px 100px;
  border-right:1px solid var(--border);
  display:flex; flex-direction:column; justify-content:center;
  position:relative;
}
.hero-left::after {
  content:'';
  position:absolute; right:0; top:20%; bottom:20%;
  width:1px;
  background:linear-gradient(to bottom, transparent, var(--accent), transparent);
  opacity:0.4;
}

.eyebrow {
  display:inline-flex; align-items:center; gap:8px;
  padding:6px 14px;
  border:1px solid var(--border2);
  border-radius:100px;
  font-size:11px; font-weight:600; letter-spacing:1.5px;
  text-transform:uppercase; color:var(--accent);
  margin-bottom:36px;
  background:rgba(0,212,245,0.05);
  animation: fadeUp 0.8s ease both 0.1s;
}
.eyebrow-dot { width:5px; height:5px; background:var(--accent3); border-radius:50%; animation:blink 2s ease-in-out infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }

.headline {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(52px,6vw,82px);
  line-height:0.95;
  letter-spacing:1px;
  margin-bottom:28px;
  animation:fadeUp 0.8s ease both 0.2s;
}
.headline .hl {
  color:transparent;
  -webkit-text-stroke:1.5px var(--accent);
  display:block;
}
.headline .hl2 { color:var(--accent); display:block; }

.tagline {
  font-size:15px; color:var(--muted2); line-height:1.8;
  max-width:440px; margin-bottom:44px;
  font-weight:300;
  animation:fadeUp 0.8s ease both 0.35s;
}

.features { display:flex; flex-direction:column; gap:10px; margin-bottom:44px; animation:fadeUp 0.8s ease both 0.45s; }
.feature {
  display:flex; align-items:center; gap:14px;
  padding:14px 18px;
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  transition:all 0.3s;
  cursor:default;
}
.feature:hover {
  border-color:var(--border2);
  background:var(--surface2);
  transform:translateX(6px);
  box-shadow: -4px 0 0 var(--accent), 0 8px 30px rgba(0,0,0,0.3);
}
.feature-icon {
  width:38px; height:38px; border-radius:9px;
  background:rgba(0,212,245,0.1);
  display:flex; align-items:center; justify-content:center;
  font-size:17px; flex-shrink:0;
  transition:background 0.3s;
}
.feature:hover .feature-icon { background:rgba(0,212,245,0.18); }
.feature-text strong { display:block; font-size:13px; font-weight:600; color:var(--text); margin-bottom:2px; }
.feature-text span { font-size:11px; color:var(--muted); }

.hero-badge {
  display:inline-flex; align-items:center; gap:10px;
  font-size:12px; color:var(--muted);
  animation:fadeUp 0.8s ease both 0.55s;
}
.badge-pulse {
  width:8px; height:8px; border-radius:50%; background:var(--accent3);
  position:relative;
}
.badge-pulse::after {
  content:''; position:absolute; inset:-3px; border-radius:50%;
  border:1px solid var(--accent3); animation:pulse 2s ease-in-out infinite;
}
@keyframes pulse { 0%,100%{transform:scale(1);opacity:0.8} 50%{transform:scale(1.8);opacity:0} }

/* ─── HERO RIGHT ─── */
.hero-right {
  padding:80px 60px 100px;
  display:flex; flex-direction:column; justify-content:center; align-items:center;
}
.hero-right-inner { width:100%; max-width:400px; }

.panel-title {
  font-family:'Bebas Neue',sans-serif; font-size:32px; letter-spacing:1px;
  margin-bottom:6px;
  animation:fadeR 0.8s ease both 0.3s;
}
.panel-sub {
  font-size:13px; color:var(--muted); margin-bottom:36px; line-height:1.6;
  animation:fadeR 0.8s ease both 0.4s;
}

.access-cards { display:flex; flex-direction:column; gap:14px; animation:fadeR 0.8s ease both 0.5s; }

.access-card {
  display:flex; align-items:center; gap:16px;
  padding:20px 22px; border-radius:14px;
  text-decoration:none;
  border:1px solid var(--border);
  background:var(--surface);
  color:var(--text);
  transition:all 0.3s;
  position:relative; overflow:hidden;
}
.access-card::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, transparent 60%, rgba(0,212,245,0.04));
  opacity:0; transition:opacity 0.3s;
}
.access-card:hover::before { opacity:1; }
.access-card:hover { transform:translateY(-3px); box-shadow:0 20px 50px rgba(0,0,0,0.4); border-color:var(--border2); }

.access-card.client-card {
  background: linear-gradient(135deg, rgba(0,212,245,0.14), rgba(0,255,204,0.07));
  border-color: rgba(0,212,245,0.4);
  box-shadow: 0 0 30px rgba(0,212,245,0.08);
}
.access-card.client-card:hover {
  box-shadow: 0 20px 50px rgba(0,212,245,0.18);
  border-color: rgba(0,212,245,0.6);
}
.client-icon {
  background: linear-gradient(135deg, rgba(0,212,245,0.25), rgba(0,255,204,0.15)) !important;
  border-color: rgba(0,212,245,0.4) !important;
}
.access-card.client-card .card-body strong { color: var(--accent); }
.access-card.client-card .card-arrow { color: var(--accent); }

.access-card.resp-card {
  background: rgba(255,255,255,0.02);
  border-color: rgba(255,255,255,0.07);
  opacity: 0.75;
  transition: all 0.3s;
}
.access-card.resp-card:hover {
  opacity: 1;
  border-color: rgba(120,160,180,0.25);
  background: rgba(255,255,255,0.04);
  box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}
.resp-icon {
  background: rgba(255,255,255,0.05) !important;
  border-color: rgba(255,255,255,0.1) !important;
}
.access-card.resp-card .card-body strong { color: var(--muted2); font-weight:500; }
.access-card.resp-card .card-arrow { color: var(--muted); }

.card-icon {
  width:46px; height:46px; border-radius:12px; flex-shrink:0;
  display:flex; align-items:center; justify-content:center; font-size:20px;
  background:rgba(255,255,255,0.06);
  border:1px solid var(--border);
}
.access-card.admin .card-icon {
  background:rgba(0,212,245,0.15);
  border-color:rgba(0,212,245,0.3);
}

.card-body { flex:1; }
.card-body strong { display:block; font-size:14px; font-weight:600; margin-bottom:3px; }
.card-body small { font-size:11px; color:var(--muted); }

.card-arrow {
  font-size:18px; color:var(--muted); transition:all 0.3s;
  flex-shrink:0;
}
.access-card:hover .card-arrow { color:var(--accent); transform:translateX(4px); }

.or-divider {
  display:flex; align-items:center; gap:12px;
  color:var(--muted); font-size:11px; letter-spacing:1px;
}
.or-divider::before,.or-divider::after { content:''; flex:1; height:1px; background:var(--border); }

/* Stats */
.stats-strip {
  display:flex; margin-top:32px;
  border:1px solid var(--border); border-radius:14px; overflow:hidden;
  animation:fadeR 0.8s ease both 0.7s;
}
.stat { flex:1; padding:18px 12px; text-align:center; border-right:1px solid var(--border); }
.stat:last-child { border:none; }
.stat-num {
  font-family:'Bebas Neue',sans-serif; font-size:24px; letter-spacing:1px;
  color:var(--accent);
}
.stat-label { font-size:10px; color:var(--muted); margin-top:2px; text-transform:uppercase; letter-spacing:0.8px; }

/* ─── WAVE BOTTOM ─── */
.wave-wrap { position:absolute; bottom:0; left:0; right:0; height:100px; overflow:hidden; pointer-events:none; }
.wave {
  position:absolute; bottom:0; left:0;
  width:200%; height:100%;
  background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 100'%3E%3Cpath fill='rgba(0,212,245,0.06)' d='M0,50 C360,95 720,8 1080,50 C1260,72 1360,35 1440,50 L1440,100 L0,100 Z'/%3E%3C/svg%3E") repeat-x bottom;
  animation:wave 10s linear infinite;
}
.wave2 {
  position:absolute; bottom:0; left:0;
  width:200%; height:70px;
  background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 70'%3E%3Cpath fill='rgba(0,119,168,0.07)' d='M0,35 C300,62 600,8 900,35 C1100,52 1300,18 1440,35 L1440,70 L0,70 Z'/%3E%3C/svg%3E") repeat-x bottom;
  animation:wave 16s linear infinite reverse;
}
@keyframes wave { from{transform:translateX(0)} to{transform:translateX(-50%)} }

/* ─── SECTIONS COMMUNES ─── */
section.content-section {
  position:relative; z-index:10;
  padding:110px 80px;
  border-top:1px solid var(--border);
}
.section-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:14px;
  display:flex; align-items:center; gap:8px;
}
.section-label::before { content:''; width:24px; height:1px; background:var(--accent); }
.section-title {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(34px,4vw,54px); letter-spacing:1px; line-height:1;
  margin-bottom:20px;
}
.section-title span { color:var(--accent); }
.section-desc {
  font-size:15px; color:var(--muted2); line-height:1.85;
  max-width:640px; margin-bottom:64px; font-weight:300;
}

/* ─── MODULES GRID ─── */
.modules-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(270px,1fr)); gap:18px; }
.module-card {
  padding:28px 26px;
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  transition:all 0.35s;
  position:relative; overflow:hidden;
}
.module-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:2px;
  background:linear-gradient(90deg,var(--accent),var(--accent3));
  transform:scaleX(0); transform-origin:left; transition:transform 0.4s;
}
.module-card:hover::before { transform:scaleX(1); }
.module-card:hover {
  border-color:var(--border2);
  background:var(--surface2);
  transform:translateY(-5px);
  box-shadow:0 24px 50px rgba(0,0,0,0.35);
}
.module-icon { font-size:30px; margin-bottom:16px; display:block; }
.module-title { font-family:'Bebas Neue',sans-serif; font-size:20px; letter-spacing:0.5px; margin-bottom:10px; }
.module-desc { font-size:13px; color:var(--muted2); line-height:1.7; font-weight:300; }

/* ─── HOW IT WORKS ─── */
.steps-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:0; margin-top:52px; position:relative; }
.steps-grid::before {
  content:''; position:absolute; top:28px; left:10%; right:10%; height:1px;
  background:linear-gradient(90deg, transparent, var(--accent), transparent);
  opacity:0.2;
}
.step { padding:0 24px 32px; position:relative; text-align:center; }
.step-num {
  width:56px; height:56px; border-radius:50%;
  border:1px solid var(--border2);
  background:rgba(0,212,245,0.06);
  display:flex; align-items:center; justify-content:center;
  margin:0 auto 18px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; color:var(--accent);
  position:relative; z-index:1;
  transition:all 0.3s;
}
.step:hover .step-num {
  background:rgba(0,212,245,0.15);
  box-shadow:0 0 30px rgba(0,212,245,0.3);
}
.step-title { font-family:'Bebas Neue',sans-serif; font-size:16px; letter-spacing:0.5px; margin-bottom:8px; }
.step-desc { font-size:12px; color:var(--muted); line-height:1.65; font-weight:300; }

/* ─── PRODUITS ─── */
.products-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(310px,1fr)); gap:20px; }
.product-card {
  padding:28px 26px;
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px;
  transition:all 0.35s;
  position:relative;
}
.product-card:hover {
  border-color:var(--border2);
  background:var(--surface2);
  transform:translateY(-5px);
  box-shadow:0 24px 50px rgba(0,0,0,0.35);
}
.product-icon { font-size:32px; margin-bottom:14px; }
.product-title { font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:0.5px; margin-bottom:6px; }
.product-origin { font-size:11px; color:var(--accent); text-transform:uppercase; letter-spacing:1px; margin-bottom:12px; }
.product-desc { font-size:13px; color:var(--muted2); line-height:1.7; margin-bottom:16px; font-weight:300; }
.product-tags { display:flex; gap:6px; flex-wrap:wrap; }
.tag {
  padding:4px 12px; border-radius:100px; font-size:11px;
  border:1px solid rgba(0,212,245,0.2);
  background:rgba(0,212,245,0.07);
  color:var(--accent);
}
.tag.green {
  border-color:rgba(0,255,204,0.2);
  background:rgba(0,255,204,0.06);
  color:var(--accent3);
}

.product-cta-card {
  padding:32px 26px;
  background:rgba(0,212,245,0.04);
  border:1px solid rgba(0,212,245,0.2);
  border-radius:16px;
  display:flex; flex-direction:column; justify-content:center;
}
.product-cta-card h3 { font-family:'Bebas Neue',sans-serif; font-size:26px; letter-spacing:0.5px; margin-bottom:10px; }
.product-cta-card p { font-size:13px; color:var(--muted); margin-bottom:24px; line-height:1.65; font-weight:300; }
.btn-primary {
  display:block; padding:13px 20px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  color:#020b14; border-radius:10px; text-decoration:none;
  font-weight:700; font-size:13px; text-align:center;
  transition:all 0.3s;
  box-shadow:0 0 20px rgba(0,212,245,0.2);
  margin-bottom:10px;
}
.btn-primary:hover { box-shadow:0 0 35px rgba(0,212,245,0.4); transform:translateY(-2px); }
.btn-secondary {
  display:block; padding:13px 20px;
  background:rgba(0,212,245,0.08);
  border:1px solid rgba(0,212,245,0.25);
  color:var(--accent); border-radius:10px; text-decoration:none;
  font-weight:600; font-size:13px; text-align:center;
  transition:all 0.3s;
}
.btn-secondary:hover { background:rgba(0,212,245,0.14); transform:translateY(-2px); }

/* ─── FOOTER ─── */
footer {
  position:relative; z-index:10;
  padding:32px 80px;
  border-top:1px solid var(--border);
  display:flex; justify-content:space-between; align-items:center;
  font-size:12px; color:var(--muted);
}
.footer-logo { font-family:'Bebas Neue',sans-serif; font-size:18px; color:var(--text); letter-spacing:2px; }
.footer-links { display:flex; gap:24px; }
.footer-links a { color:var(--muted); text-decoration:none; transition:color 0.2s; }
.footer-links a:hover { color:var(--accent); }

/* ─── ANIMATIONS ─── */
@keyframes fadeUp { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
@keyframes fadeR  { from{opacity:0;transform:translateX(24px)} to{opacity:1;transform:translateX(0)} }

.reveal {
  opacity:0; transform:translateY(28px);
  transition:opacity 0.7s ease, transform 0.7s ease;
}
.reveal.visible { opacity:1; transform:translateY(0); }
.reveal-delay-1 { transition-delay:0.1s; }
.reveal-delay-2 { transition-delay:0.2s; }
.reveal-delay-3 { transition-delay:0.3s; }

/* ─── MOBILE ─── */
@media(max-width:900px){
  nav { padding:0 24px; }
  .nav-links { display:none; }
  .hero { grid-template-columns:1fr; }
  .hero-left { border-right:none; border-bottom:1px solid var(--border); padding:60px 24px 80px; }
  .hero-right { padding:60px 24px; }
  section.content-section { padding:70px 24px; }
  footer { flex-direction:column; gap:16px; text-align:center; padding:32px 24px; }
  .footer-links { flex-wrap:wrap; justify-content:center; }
}
</style>
</head>
<body>

<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="scroll-line" id="scrollLine"></div>
<div class="particles" id="particles"></div>

<!-- ─── NAV ─── -->
<nav>
  <div class="nav-logo">
    <div class="nav-logo-icon">💧</div>
    AquaStock
  </div>
  <div class="nav-links">
    <a href="#apropos">Système</a>
    <a href="#how">Workflow</a>
    <a href="#marques">Produits</a>
    <a href="login.php" class="nav-cta">Connexion</a>
  </div>
</nav>

<!-- ─── HERO ─── -->
<section class="hero">

  <div class="hero-left">
    <div class="eyebrow">
      <span class="eyebrow-dot"></span>
      Système Opérationnel & Actif
    </div>

    <h1 class="headline">
      Stock &<br>
      <span class="hl">Facturation</span>
      <span class="hl2">Intelligente</span>
    </h1>

    <p class="tagline">
      Plateforme numérique complète pour usines d'eau minérale — stocks en temps réel, facturation automatisée avec TVA, gestion clients et suivi des commandes depuis un seul tableau de bord.
    </p>

    <div class="features">
      <div class="feature">
        <div class="feature-icon">📦</div>
        <div class="feature-text">
          <strong>Contrôle des Stocks en Temps Réel</strong>
          <span>Déduction automatique à chaque commande confirmée — zéro latence</span>
        </div>
      </div>
      <div class="feature">
        <div class="feature-icon">🧾</div>
        <div class="feature-text">
          <strong>Facturation Automatisée</strong>
          <span>TVA 19%, timbre fiscal, calcul TTC — généré instantanément</span>
        </div>
      </div>
      <div class="feature">
        <div class="feature-icon">📊</div>
        <div class="feature-text">
          <strong>Gestion Clients & Commandes</strong>
          <span>Profils complets, historique, suivi des paiements et reçus</span>
        </div>
      </div>
    </div>

    <div class="hero-badge">
      <div class="badge-pulse"></div>
      Tous les services actifs — synchronisation live
    </div>
  </div>

  <div class="hero-right">
    <div class="hero-right-inner">
      <div class="panel-title">Accès Plateforme</div>
      <p class="panel-sub">Sélectionnez votre type d'accès pour entrer dans le système.</p>

      <div class="access-cards">

        <!-- CLIENT LOGIN — PRIMARY -->
        <a href="login.php" class="access-card client-card">
          <div class="card-icon client-icon">🔑</div>
          <div class="card-body">
            <strong>Connexion</strong>
            <small>Accédez à votre espace</small>
          </div>
          <span class="card-arrow">→</span>
        </a>

      </div>

      <div class="stats-strip">
        <div class="stat">
          <div class="stat-num">100%</div>
          <div class="stat-label">Automatisé</div>
        </div>
        <div class="stat">
          <div class="stat-num">TVA</div>
          <div class="stat-label">Conforme</div>
        </div>
        <div class="stat">
          <div class="stat-num">Live</div>
          <div class="stat-label">Sync Stock</div>
        </div>
      </div>
    </div>
  </div>

  <div class="wave-wrap"><div class="wave"></div><div class="wave2"></div></div>
</section>

<!-- ─── À PROPOS ─── -->
<section id="apropos" class="content-section">
  <div class="section-label reveal">À Propos</div>
  <h2 class="section-title reveal reveal-delay-1">Tout pour gérer une <span>usine d'eau</span></h2>
  <p class="section-desc reveal reveal-delay-2">
    AquaStock est conçu spécifiquement pour les unités de production d'eau minérale algériennes — du passage d'une commande à l'émission de la facture et la mise à jour du stock, en quelques secondes.
  </p>

  <div class="modules-grid">
    <div class="module-card reveal">
      <span class="module-icon">📦</span>
      <div class="module-title">Gestion des Stocks</div>
      <div class="module-desc">Inventaire en temps réel avec déduction automatique à chaque commande. Alertes avant rupture, historique complet des mouvements.</div>
    </div>
    <div class="module-card reveal reveal-delay-1">
      <span class="module-icon">🧾</span>
      <div class="module-title">Facturation & Factures</div>
      <div class="module-desc">Factures générées instantanément — sous-total HT, TVA 19%, timbre fiscal et total TTC calculés automatiquement.</div>
    </div>
    <div class="module-card reveal reveal-delay-2">
      <span class="module-icon">👥</span>
      <div class="module-title">Gestion des Clients</div>
      <div class="module-desc">Profils clients complets avec coordonnées, historique de commandes et suivi des paiements centralisé.</div>
    </div>
    <div class="module-card reveal reveal-delay-3">
      <span class="module-icon">🛒</span>
      <div class="module-title">Portail Client</div>
      <div class="module-desc">Espace dédié pour parcourir les produits, passer des commandes, choisir le mode de paiement et téléverser les justificatifs.</div>
    </div>
    <div class="module-card reveal">
      <span class="module-icon">💳</span>
      <div class="module-title">Suivi des Paiements</div>
      <div class="module-desc">Espèces, virement ou chèque — chaque paiement est tracé. Les reçus sont téléversés directement par le client.</div>
    </div>
    <div class="module-card reveal reveal-delay-1">
      <span class="module-icon">🔒</span>
      <div class="module-title">Accès par Rôles</div>
      <div class="module-desc">Portails distincts et sessions sécurisées pour admins et clients. Toutes les requêtes protégées contre les injections SQL.</div>
    </div>
  </div>
</section>

<!-- ─── COMMENT ÇA MARCHE ─── -->
<section id="how" class="content-section">
  <div class="section-label reveal">Workflow</div>
  <h2 class="section-title reveal reveal-delay-1">De la commande à la <span>facture</span></h2>
  <p class="section-desc reveal reveal-delay-2">Un processus fluide, entièrement automatisé, de la connexion client à la validation administrative.</p>

  <div class="steps-grid">
    <div class="step reveal">
      <div class="step-num">01</div>
      <div class="step-title">Connexion Client</div>
      <div class="step-desc">Le client se connecte à son espace avec ses identifiants sécurisés.</div>
    </div>
    <div class="step reveal reveal-delay-1">
      <div class="step-num">02</div>
      <div class="step-title">Parcourir & Panier</div>
      <div class="step-desc">Sélection des produits et quantités désirées depuis le catalogue.</div>
    </div>
    <div class="step reveal reveal-delay-2">
      <div class="step-num">03</div>
      <div class="step-title">Confirmation</div>
      <div class="step-desc">Stock vérifié et déduit automatiquement à la validation.</div>
    </div>
    <div class="step reveal reveal-delay-3">
      <div class="step-num">04</div>
      <div class="step-title">Facture Générée</div>
      <div class="step-desc">Facture complète avec détail fiscal créée et liée à la commande.</div>
    </div>
    <div class="step reveal">
      <div class="step-num">05</div>
      <div class="step-title">Paiement & Livraison</div>
      <div class="step-desc">Le client téléverse son reçu. L'admin valide et lance la livraison.</div>
    </div>
  </div>
</section>

<!-- ─── PRODUITS ─── -->
<section id="marques" class="content-section">
  <div class="section-label reveal">Notre Marque</div>
  <h2 class="section-title reveal reveal-delay-1">NAQAA — <span>نقاء</span></h2>

  <!-- ─── BLOC INTRODUCTION PROFESSIONNELLE NAQAA ─── -->
  <div class="naqaa-intro reveal reveal-delay-1">
    <div class="naqaa-intro-logo">
      <svg width="72" height="72" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="dropGrad" cx="40%" cy="30%" r="65%">
            <stop offset="0%" stop-color="#29aedb"/>
            <stop offset="100%" stop-color="#004f80"/>
          </radialGradient>
        </defs>
        <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="url(#dropGrad)"/>
        <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
        <text x="60" y="90" text-anchor="middle" font-family="Georgia,serif" font-size="52" font-weight="700" fill="white">N</text>
      </svg>
    </div>
    <div class="naqaa-intro-body">
      <div class="naqaa-intro-name">NAQAA <span class="naqaa-arabic">نقاء</span> <span class="naqaa-badge">Eau Minérale Naturelle</span></div>
      <p class="naqaa-intro-text">
        Née des profondeurs du sous-sol algérien, <strong>NAQAA</strong> est une eau minérale naturelle d'exception, embouteillée à la source dans le respect des normes les plus strictes. Son nom, qui signifie <em>« pureté »</em> en arabe, reflète notre engagement fondamental : vous offrir une eau authentique, intacte et vivante — telle que la nature l'a conçue.
      </p>
      <p class="naqaa-intro-text" style="margin-top:10px;">
        Riche en minéraux essentiels, NAQAA accompagne chaque instant de votre journée. De la table familiale aux environnements professionnels, du format individuel à la bonbonne rechargeable, notre gamme complète répond à tous les besoins — avec la même exigence de qualité qui nous définit depuis notre création.
      </p>
      <div class="naqaa-certifs">
        <span class="certif-badge">🏅 Conforme normes algériennes</span>
        <span class="certif-badge">♻️ Emballage éco-responsable</span>
        <span class="certif-badge">🔬 Analyses régulières certifiées</span>
        <span class="certif-badge">💧 Source protégée & contrôlée</span>
      </div>
    </div>
  </div>

  <p class="section-desc reveal reveal-delay-2" style="margin-top:0;">
    Disponible en 4 formats adaptés à chaque usage — du quotidien au professionnel.
  </p>

  <style>
  /* ─── INTRO NAQAA ─── */
  .naqaa-intro {
    display:flex; align-items:flex-start; gap:32px;
    background: linear-gradient(135deg, rgba(0,119,168,0.10), rgba(0,212,245,0.05));
    border: 1px solid rgba(0,212,245,0.22);
    border-radius:20px; padding:36px 40px;
    margin-bottom:40px;
    position:relative; overflow:hidden;
  }
  .naqaa-intro::before {
    content:''; position:absolute; top:0; left:0; right:0; height:3px;
    background: linear-gradient(90deg, #004f80, #00d4f5, #00ffcc, #00d4f5, #004f80);
    background-size:200% 100%; animation:shimmer 4s linear infinite;
  }
  @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
  .naqaa-intro-logo { flex-shrink:0; filter: drop-shadow(0 0 18px rgba(0,212,245,0.45)); }
  .naqaa-intro-body { flex:1; }
  .naqaa-intro-name {
    display:flex; align-items:center; gap:14px; flex-wrap:wrap;
    font-family:'Bebas Neue',sans-serif; font-size:2rem; letter-spacing:4px;
    color:var(--accent); margin-bottom:16px;
  }
  .naqaa-arabic { font-size:1.4rem; opacity:0.75; letter-spacing:2px; }
  .naqaa-badge {
    font-family:'Outfit',sans-serif; font-size:11px; font-weight:600;
    letter-spacing:1.5px; text-transform:uppercase;
    padding:4px 14px; border-radius:100px;
    background:rgba(0,212,245,0.1); border:1px solid rgba(0,212,245,0.3);
    color:var(--accent); line-height:1;
  }
  .naqaa-intro-text {
    font-size:14px; color:var(--muted2); line-height:1.85; font-weight:300;
  }
  .naqaa-intro-text strong { color:var(--text); font-weight:600; }
  .naqaa-intro-text em { color:var(--accent3); font-style:normal; font-weight:500; }
  .naqaa-certifs {
    display:flex; flex-wrap:wrap; gap:8px; margin-top:20px;
  }
  .certif-badge {
    padding:6px 14px; border-radius:100px; font-size:11px; font-weight:500;
    background:rgba(0,212,245,0.06); border:1px solid rgba(0,212,245,0.15);
    color:var(--muted2); white-space:nowrap;
  }

  /* ─── FARDEAUX GRID ─── */
  .fardeau-grid {
    display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:20px;
    margin-top:16px;
  }
  .fardeau-card {
    background: var(--surface); border:1px solid var(--border);
    border-radius:16px; padding:24px; transition:border-color .3s, transform .3s;
    position:relative; overflow:hidden;
  }
  .fardeau-card:hover { border-color:var(--border2); transform:translateY(-4px); box-shadow:0 24px 50px rgba(0,0,0,0.35); }
  .fardeau-card::before {
    content:''; position:absolute; top:0; left:0; right:0; height:3px;
    background: linear-gradient(90deg, #1a7bbf, #00d4f5);
    border-radius:16px 16px 0 0;
  }
  .fardeau-top { display:flex; align-items:center; gap:16px; margin-bottom:16px; }
  .fardeau-volume { font-size:1.6rem; font-weight:700; color:var(--accent); letter-spacing:1px; }
  .fardeau-format { font-size:0.78rem; color:var(--muted2); letter-spacing:1px; margin-top:2px; }
  .fardeau-desc {
    font-size:0.88rem; color:var(--muted2); line-height:1.6; margin-bottom:18px;
    border-left:2px solid rgba(0,212,245,0.35); padding-left:12px;
  }
  .fardeau-details { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
  .fardeau-detail {
    background: rgba(0,119,168,0.08); border-radius:10px;
    padding:10px 12px; text-align:center;
  }
  .detail-val { font-size:1.1rem; font-weight:700; color:var(--text); }
  .detail-lbl { font-size:0.72rem; color:var(--muted); margin-top:2px; letter-spacing:0.5px; }
  .fardeau-visual {
    display:flex; align-items:center; gap:6px; margin-top:14px;
    padding-top:14px; border-top:1px solid var(--border); flex-wrap:wrap;
  }
  .fardeau-visual-lbl { font-size:0.75rem; color:var(--muted); margin-right:4px; }
  .svg-bottles-grid { display:flex; flex-wrap:wrap; gap:4px; align-items:flex-end; }
  .svg-bottles-grid svg {
    filter: drop-shadow(0 2px 6px rgba(0,212,245,0.35));
    transition: transform 0.2s;
  }
  .svg-bottles-grid svg:hover { transform: translateY(-4px); }

  @media(max-width:700px){
    .naqaa-intro { flex-direction:column; padding:24px; }
    .naqaa-intro-logo { margin:0 auto; }
  }
  </style>

  <div class="fardeau-grid">

    <!-- ── 0.5L ── -->
    <div class="fardeau-card reveal">
      <div class="fardeau-top">
        <svg width="42" height="42" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
          <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
          <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
        </svg>
        <div>
          <div class="fardeau-volume">0.5 L</div>
          <div class="fardeau-format">FORMAT INDIVIDUEL</div>
        </div>
      </div>
      <div class="fardeau-desc">
        La bouteille du quotidien. Pratique pour les déplacements, les points de vente, les écoles et les événements. Format le plus vendu à l'unité.
      </div>
      <div class="fardeau-details">
        <div class="fardeau-detail"><div class="detail-val">12 bt</div><div class="detail-lbl">Bouteilles / fardeau</div></div>
        <div class="fardeau-detail"><div class="detail-val">500 mL</div><div class="detail-lbl">Contenance</div></div>
        <div class="fardeau-detail"><div class="detail-val">🧊</div><div class="detail-lbl">Fraîcheur garantie</div></div>
        <div class="fardeau-detail"><div class="detail-val">🏷️</div><div class="detail-lbl">Prix sur devis</div></div>
      </div>
      <div class="fardeau-visual">
        <span class="fardeau-visual-lbl">1 fardeau =</span>
        <div class="svg-bottles-grid">
          <?php for($i=0;$i<12;$i++): ?>
          <svg width="22" height="58" viewBox="0 0 22 58" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg05_<?php echo $i; ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#c8ecf8"/>
                <stop offset="40%" stop-color="#e8f7fd"/>
                <stop offset="100%" stop-color="#9fd8ef"/>
              </linearGradient>
              <linearGradient id="water05_<?php echo $i; ?>" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#0099cc"/>
                <stop offset="100%" stop-color="#005f87"/>
              </linearGradient>
              <linearGradient id="label05_<?php echo $i; ?>" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#003f6b"/>
              </linearGradient>
              <clipPath id="cp05_<?php echo $i; ?>">
                <path d="M4,11 Q4,8 7,7 L7,3.5 Q7,1.5 9,1.5 L13,1.5 Q15,1.5 15,3.5 L15,7 Q18,8 18,11 L18,49 Q18,52 15,52 L7,52 Q4,52 4,49 Z"/>
              </clipPath>
            </defs>
            <!-- Shadow -->
            <ellipse cx="11" cy="56.5" rx="6.5" ry="1.5" fill="#000" opacity="0.12"/>
            <!-- Body -->
            <path d="M4,11 Q4,8 7,7 L7,3.5 Q7,1.5 9,1.5 L13,1.5 Q15,1.5 15,3.5 L15,7 Q18,8 18,11 L18,49 Q18,52 15,52 L7,52 Q4,52 4,49 Z" fill="url(#bg05_<?php echo $i; ?>)" stroke="#6ecef0" stroke-width="0.4"/>
            <!-- Water fill bottom -->
            <rect x="4" y="33" width="14" height="19" fill="#29aedb" opacity="0.42" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Label band -->
            <rect x="4" y="22" width="14" height="16" fill="url(#label05_<?php echo $i; ?>)" opacity="0.95" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Label subtle inner glow top -->
            <rect x="4" y="22" width="14" height="4" fill="white" opacity="0.08" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Label top accent line (cyan) -->
            <rect x="4" y="22" width="14" height="0.8" fill="#00d4f5" opacity="0.9" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Label bottom accent line -->
            <rect x="4" y="37.2" width="14" height="0.8" fill="#00d4f5" opacity="0.9" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Left shine strip -->
            <rect x="4" y="22" width="2.5" height="16" fill="white" opacity="0.06" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Drop logo centered on label -->
            <g clip-path="url(#cp05_<?php echo $i; ?>)">
              <defs>
                <radialGradient id="lg05_<?php echo $i; ?>" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds05_<?php echo $i; ?>" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="0.5" stdDeviation="0.8" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <!-- drop shape -->
              <path d="M11,24.2 C13.8,26.8 14.8,28.5 14.8,29.6 C14.8,31.2 13.1,32.3 11,32.3 C8.9,32.3 7.2,31.2 7.2,29.6 C7.2,28.5 8.2,26.8 11,24.2 Z" fill="url(#lg05_<?php echo $i; ?>)" filter="url(#ds05_<?php echo $i; ?>)"/>
              <!-- drop highlight -->
              <path d="M9.5,25.5 C9.9,26.8 10,28.2 9.8,29.3 C9.6,30 9.1,30.6 8.7,30.4 C8.2,30 8.2,28.8 8.7,27.5 Z" fill="white" opacity="0.28"/>
              <!-- N letter in drop -->
              <text x="11" y="31" text-anchor="middle" font-family="Georgia,serif" font-size="5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <!-- NAQAA brand name -->
            <text x="11" y="34.8" text-anchor="middle" font-family="'Bebas Neue','Arial Narrow',sans-serif" font-size="3.8" fill="white" letter-spacing="1.2" opacity="0.97" clip-path="url(#cp05_<?php echo $i; ?>)">NAQAA</text>
            <!-- Arabic نقاء -->
            <text x="11" y="37" text-anchor="middle" font-family="'Amiri','Traditional Arabic','Arial Unicode MS',serif" font-size="3" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp05_<?php echo $i; ?>)">نقاء</text>
            <!-- Shine streak -->
            <rect x="6" y="9" width="2" height="38" rx="1" fill="white" opacity="0.3"/>
            <rect x="8.5" y="9" width="1" height="20" rx="0.5" fill="white" opacity="0.12"/>
            <!-- Shoulder ridges -->
            <rect x="4" y="19" width="14" height="1.2" rx="0.6" fill="#7ad4ef" opacity="0.3" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Bottom base -->
            <rect x="4" y="48" width="14" height="4" fill="#005f87" opacity="0.3" clip-path="url(#cp05_<?php echo $i; ?>)"/>
            <!-- Cap -->
            <rect x="7.5" y="0" width="7" height="4.5" rx="1.8" fill="#00d4f5"/>
            <rect x="7.5" y="3" width="7" height="1.5" fill="#0099bb"/>
            <!-- Cap shine -->
            <rect x="8" y="0.5" width="2" height="2" rx="1" fill="white" opacity="0.35"/>
          </svg>
          <?php endfor; ?>
        </div>
      </div>
    </div>

    <!-- ── 1.5L ── -->
    <div class="fardeau-card reveal reveal-delay-1">
      <div class="fardeau-top">
        <svg width="42" height="42" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
          <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
          <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
        </svg>
        <div>
          <div class="fardeau-volume">1.5 L</div>
          <div class="fardeau-format">FORMAT FAMILIAL</div>
        </div>
      </div>
      <div class="fardeau-desc">
        Le format star du marché algérien. Idéal pour la table familiale et la maison. Le plus commandé en fardeau par les épiceries et supermarchés.
      </div>
      <div class="fardeau-details">
        <div class="fardeau-detail"><div class="detail-val">6 bt</div><div class="detail-lbl">Bouteilles / fardeau</div></div>
        <div class="fardeau-detail"><div class="detail-val">1.5 L</div><div class="detail-lbl">Contenance</div></div>
        <div class="fardeau-detail"><div class="detail-val">⭐</div><div class="detail-lbl">Format le plus vendu</div></div>
        <div class="fardeau-detail"><div class="detail-val">🏷️</div><div class="detail-lbl">Prix sur devis</div></div>
      </div>
      <div class="fardeau-visual">
        <span class="fardeau-visual-lbl">1 fardeau =</span>
        <div class="svg-bottles-grid">
          <?php for($i=0;$i<6;$i++): ?>
          <svg width="28" height="74" viewBox="0 0 28 74" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg15_<?php echo $i; ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#b8e4f6"/>
                <stop offset="38%" stop-color="#e0f5fd"/>
                <stop offset="100%" stop-color="#8fcfe8"/>
              </linearGradient>
              <linearGradient id="label15_<?php echo $i; ?>" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#003f6b"/>
              </linearGradient>
              <clipPath id="cp15_<?php echo $i; ?>">
                <path d="M3,15 Q3,11 7,9 L7,4.5 Q7,2 10,2 L18,2 Q21,2 21,4.5 L21,9 Q25,11 25,15 L25,63 Q25,67 21,67 L7,67 Q3,67 3,63 Z"/>
              </clipPath>
            </defs>
            <!-- Shadow -->
            <ellipse cx="14" cy="72" rx="10" ry="2" fill="#000" opacity="0.11"/>
            <!-- Body -->
            <path d="M3,15 Q3,11 7,9 L7,4.5 Q7,2 10,2 L18,2 Q21,2 21,4.5 L21,9 Q25,11 25,15 L25,63 Q25,67 21,67 L7,67 Q3,67 3,63 Z" fill="url(#bg15_<?php echo $i; ?>)" stroke="#6ecef0" stroke-width="0.45"/>
            <!-- Water fill bottom -->
            <rect x="3" y="43" width="22" height="24" fill="#29aedb" opacity="0.4" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Label band -->
            <rect x="3" y="27" width="22" height="20" fill="url(#label15_<?php echo $i; ?>)" opacity="0.95" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Label subtle inner glow top -->
            <rect x="3" y="27" width="22" height="5" fill="white" opacity="0.08" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Label top accent line -->
            <rect x="3" y="27" width="22" height="1" fill="#00d4f5" opacity="0.9" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Label bottom accent line -->
            <rect x="3" y="46" width="22" height="1" fill="#00d4f5" opacity="0.9" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Left shine strip -->
            <rect x="3" y="27" width="3.5" height="20" fill="white" opacity="0.06" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Drop logo + text -->
            <g clip-path="url(#cp15_<?php echo $i; ?>)">
              <defs>
                <radialGradient id="lg15_<?php echo $i; ?>" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds15_<?php echo $i; ?>" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="0.8" stdDeviation="1" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <!-- drop shape -->
              <path d="M14,29.5 C17.5,33.2 18.8,35.8 18.8,37.4 C18.8,39.7 16.7,41.3 14,41.3 C11.3,41.3 9.2,39.7 9.2,37.4 C9.2,35.8 10.5,33.2 14,29.5 Z" fill="url(#lg15_<?php echo $i; ?>)" filter="url(#ds15_<?php echo $i; ?>)"/>
              <!-- drop highlight -->
              <path d="M11.8,31.2 C12.3,33 12.4,35.2 12.1,37 C11.9,38.1 11.3,38.9 10.8,38.6 C10.2,38.2 10.2,36.5 10.8,34.7 Z" fill="white" opacity="0.28"/>
              <!-- N in drop -->
              <text x="14" y="39.5" text-anchor="middle" font-family="Georgia,serif" font-size="6.5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <!-- NAQAA brand -->
            <text x="14" y="43.8" text-anchor="middle" font-family="'Bebas Neue','Arial Narrow',sans-serif" font-size="4.8" fill="white" letter-spacing="1.5" opacity="0.97" clip-path="url(#cp15_<?php echo $i; ?>)">NAQAA</text>
            <!-- Arabic نقاء -->
            <text x="14" y="46" text-anchor="middle" font-family="'Amiri','Traditional Arabic','Arial Unicode MS',serif" font-size="3.6" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp15_<?php echo $i; ?>)">نقاء</text>
            <!-- Shoulder ridges -->
            <rect x="3" y="23" width="22" height="1.5" rx="0.75" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <rect x="3" y="25.5" width="22" height="1" rx="0.5" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Shine streak -->
            <rect x="6" y="12" width="2.5" height="48" rx="1.25" fill="white" opacity="0.28"/>
            <rect x="9.5" y="12" width="1" height="26" rx="0.5" fill="white" opacity="0.11"/>
            <!-- Bottom base -->
            <rect x="3" y="62" width="22" height="5" fill="#005f87" opacity="0.28" clip-path="url(#cp15_<?php echo $i; ?>)"/>
            <!-- Cap -->
            <rect x="8.5" y="0" width="11" height="5.5" rx="2.2" fill="#00d4f5"/>
            <rect x="8.5" y="3.5" width="11" height="2" fill="#0099bb"/>
            <!-- Cap shine -->
            <rect x="9.5" y="0.8" width="3" height="2.2" rx="1" fill="white" opacity="0.35"/>
          </svg>
          <?php endfor; ?>
        </div>
      </div>
    </div>

    <!-- ── 5L ── -->
    <div class="fardeau-card reveal reveal-delay-2">
      <div class="fardeau-top">
        <svg width="42" height="42" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
          <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
          <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
        </svg>
        <div>
          <div class="fardeau-volume">5 L</div>
          <div class="fardeau-format">GRAND FORMAT</div>
        </div>
      </div>
      <div class="fardeau-desc">
        Format économique pour les familles nombreuses et les commerces. Réduction du nombre d'emballages et coût au litre plus avantageux.
      </div>
      <div class="fardeau-details">
        <div class="fardeau-detail"><div class="detail-val">4 bt</div><div class="detail-lbl">Bouteilles / fardeau</div></div>
        <div class="fardeau-detail"><div class="detail-val">5 L</div><div class="detail-lbl">Contenance</div></div>
        <div class="fardeau-detail"><div class="detail-val">💰</div><div class="detail-lbl">Économique</div></div>
        <div class="fardeau-detail"><div class="detail-val">🏷️</div><div class="detail-lbl">Prix sur devis</div></div>
      </div>
      <div class="fardeau-visual">
        <span class="fardeau-visual-lbl">1 fardeau =</span>
        <div class="svg-bottles-grid">
          <?php for($i=0;$i<4;$i++): ?>
          <svg width="44" height="88" viewBox="0 0 44 88" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg5L_<?php echo $i; ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#aaddf0"/>
                <stop offset="35%" stop-color="#dff4fc"/>
                <stop offset="100%" stop-color="#85c8e3"/>
              </linearGradient>
              <linearGradient id="label5L_<?php echo $i; ?>" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0077a8"/>
                <stop offset="100%" stop-color="#003356"/>
              </linearGradient>
              <linearGradient id="handle5L_<?php echo $i; ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#00d4f5"/>
              </linearGradient>
              <clipPath id="cp5L_<?php echo $i; ?>">
                <path d="M4,21 Q4,15 10,12 L10,6 Q10,3 14,3 L26,3 Q30,3 30,6 L30,12 Q36,15 36,21 L36,76 Q36,82 30,82 L10,82 Q4,82 4,76 Z"/>
              </clipPath>
            </defs>
            <!-- Shadow -->
            <ellipse cx="20" cy="86" rx="16" ry="2.5" fill="#000" opacity="0.11"/>
            <!-- Body -->
            <path d="M4,21 Q4,15 10,12 L10,6 Q10,3 14,3 L26,3 Q30,3 30,6 L30,12 Q36,15 36,21 L36,76 Q36,82 30,82 L10,82 Q4,82 4,76 Z" fill="url(#bg5L_<?php echo $i; ?>)" stroke="#6ecef0" stroke-width="0.5"/>
            <!-- Water fill bottom -->
            <rect x="4" y="53" width="32" height="29" fill="#29aedb" opacity="0.4" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Label band -->
            <rect x="4" y="33" width="32" height="24" fill="url(#label5L_<?php echo $i; ?>)" opacity="0.95" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Label subtle inner glow top -->
            <rect x="4" y="33" width="32" height="6" fill="white" opacity="0.08" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Label top accent line -->
            <rect x="4" y="33" width="32" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Label bottom accent line -->
            <rect x="4" y="55.8" width="32" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Left shine strip -->
            <rect x="4" y="33" width="5" height="24" fill="white" opacity="0.06" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Drop logo + text -->
            <g clip-path="url(#cp5L_<?php echo $i; ?>)">
              <defs>
                <radialGradient id="lg5L_<?php echo $i; ?>" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds5L_<?php echo $i; ?>" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <!-- drop shape -->
              <path d="M20,35.5 C24.5,40 26.2,43.2 26.2,45.2 C26.2,48.3 23.4,50.5 20,50.5 C16.6,50.5 13.8,48.3 13.8,45.2 C13.8,43.2 15.5,40 20,35.5 Z" fill="url(#lg5L_<?php echo $i; ?>)" filter="url(#ds5L_<?php echo $i; ?>)"/>
              <!-- drop highlight -->
              <path d="M17,38 C17.6,40.3 17.7,43 17.4,45.2 C17.1,46.6 16.3,47.6 15.7,47.3 C14.9,46.8 14.9,44.6 15.8,42.3 Z" fill="white" opacity="0.28"/>
              <!-- N in drop -->
              <text x="20" y="48" text-anchor="middle" font-family="Georgia,serif" font-size="8.5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <!-- NAQAA brand -->
            <text x="20" y="53.5" text-anchor="middle" font-family="'Bebas Neue','Arial Narrow',sans-serif" font-size="6" fill="white" letter-spacing="2" opacity="0.97" clip-path="url(#cp5L_<?php echo $i; ?>)">NAQAA</text>
            <!-- Arabic نقاء -->
            <text x="20" y="55.5" text-anchor="middle" font-family="'Amiri','Traditional Arabic','Arial Unicode MS',serif" font-size="4.5" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp5L_<?php echo $i; ?>)">نقاء</text>
            <!-- Shoulder ridges -->
            <rect x="4" y="28" width="32" height="2" rx="1" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <rect x="4" y="31" width="32" height="1.2" rx="0.6" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Shine streaks -->
            <rect x="8" y="16" width="3.5" height="60" rx="1.75" fill="white" opacity="0.26"/>
            <rect x="13" y="16" width="1.5" height="32" rx="0.75" fill="white" opacity="0.1"/>
            <!-- Handle -->
            <path d="M36,32 Q44,32 44,42 Q44,52 36,52" fill="none" stroke="url(#handle5L_<?php echo $i; ?>)" stroke-width="3" stroke-linecap="round"/>
            <!-- Bottom base -->
            <rect x="4" y="77" width="32" height="5" fill="#005f87" opacity="0.28" clip-path="url(#cp5L_<?php echo $i; ?>)"/>
            <!-- Cap -->
            <rect x="12" y="0" width="16" height="7" rx="2.8" fill="#00d4f5"/>
            <rect x="12" y="4.5" width="16" height="2.5" fill="#0099bb"/>
            <!-- Cap shine -->
            <rect x="13.5" y="1" width="4" height="3" rx="1.5" fill="white" opacity="0.35"/>
          </svg>
          <?php endfor; ?>
        </div>
      </div>
    </div>

    <!-- ── 19L BONBONNE ── -->
    <div class="fardeau-card reveal reveal-delay-3">
      <div class="fardeau-top">
        <svg width="42" height="42" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
          <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
          <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
          <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
        </svg>
        <div>
          <div class="fardeau-volume">19 L</div>
          <div class="fardeau-format">BONBONNE</div>
        </div>
      </div>
      <div class="fardeau-desc">
        La bonbonne rechargeable pour bureaux, hôtels, restaurants et grandes surfaces. Solution écologique et économique pour usage intensif et continu.
      </div>
      <div class="fardeau-details">
        <div class="fardeau-detail"><div class="detail-val">19 L</div><div class="detail-lbl">Contenance</div></div>
        <div class="fardeau-detail"><div class="detail-val">Unité</div><div class="detail-lbl">Vendue à l'unité</div></div>
        <div class="fardeau-detail"><div class="detail-val">♻️</div><div class="detail-lbl">Rechargeable</div></div>
        <div class="fardeau-detail"><div class="detail-val">🏷️</div><div class="detail-lbl">Prix sur devis</div></div>
      </div>
      <div class="fardeau-visual">
        <span class="fardeau-visual-lbl">1 bonbonne =</span>
        <svg width="80" height="110" viewBox="0 0 80 110" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bg19b" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#9dd4ea"/>
              <stop offset="32%" stop-color="#ddf3fc"/>
              <stop offset="100%" stop-color="#7abdd8"/>
            </linearGradient>
            <linearGradient id="label19b" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#0077a8"/>
              <stop offset="100%" stop-color="#002f54"/>
            </linearGradient>
            <linearGradient id="cap19b" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#00ffcc"/>
              <stop offset="100%" stop-color="#00c8a0"/>
            </linearGradient>
            <clipPath id="cp19b">
              <path d="M9,34 Q9,25 14,21 L14,12 Q14,7 19,7 L35,7 Q40,7 40,12 L40,21 Q45,25 45,34 L45,84 Q45,100 27,102 Q9,100 9,84 Z"/>
            </clipPath>
          </defs>
          <!-- Shadow -->
          <ellipse cx="27" cy="108" rx="22" ry="4" fill="#000" opacity="0.12"/>
          <!-- Body -->
          <path d="M9,34 Q9,25 14,21 L14,12 Q14,7 19,7 L35,7 Q40,7 40,12 L40,21 Q45,25 45,34 L45,84 Q45,100 27,102 Q9,100 9,84 Z" fill="url(#bg19b)" stroke="#6ecef0" stroke-width="0.6"/>
          <!-- Water fill bottom -->
          <rect x="9" y="63" width="36" height="39" fill="#29aedb" opacity="0.42" clip-path="url(#cp19b)"/>
          <!-- Label band -->
          <rect x="9" y="43" width="36" height="26" fill="url(#label19b)" opacity="0.95" clip-path="url(#cp19b)"/>
          <!-- Label subtle inner glow top -->
          <rect x="9" y="43" width="36" height="7" fill="white" opacity="0.08" clip-path="url(#cp19b)"/>
          <!-- Label top accent line -->
          <rect x="9" y="43" width="36" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp19b)"/>
          <!-- Label bottom accent line -->
          <rect x="9" y="68" width="36" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp19b)"/>
          <!-- Left shine strip -->
          <rect x="9" y="43" width="6" height="26" fill="white" opacity="0.06" clip-path="url(#cp19b)"/>
          <!-- Drop logo centered -->
          <g clip-path="url(#cp19b)">
            <defs>
              <radialGradient id="lgBon" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stop-color="#5dd8f0"/>
                <stop offset="60%" stop-color="#0e90c4"/>
                <stop offset="100%" stop-color="#003d6b"/>
              </radialGradient>
              <filter id="dsBon" x="-40%" y="-40%" width="180%" height="180%">
                <feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-color="#003d6b" flood-opacity="0.6"/>
              </filter>
            </defs>
            <!-- drop shape — centered at x=27 -->
            <path d="M27,45.5 C31.8,50.5 33.5,54 33.5,56.5 C33.5,60.2 30.6,62.8 27,62.8 C23.4,62.8 20.5,60.2 20.5,56.5 C20.5,54 22.2,50.5 27,45.5 Z" fill="url(#lgBon)" filter="url(#dsBon)"/>
            <!-- drop highlight -->
            <path d="M23.8,48.5 C24.5,51.2 24.6,54.5 24.3,56.8 C24,58.3 23.2,59.4 22.5,59.1 C21.6,58.5 21.7,56 22.7,53.3 Z" fill="white" opacity="0.30"/>
            <!-- N letter in drop -->
            <text x="27" y="60.5" text-anchor="middle" font-family="Georgia,serif" font-size="10" font-weight="700" fill="white" opacity="0.97">N</text>
          </g>
          <!-- NAQAA brand name -->
          <text x="27" y="65" text-anchor="middle" font-family="'Bebas Neue','Arial Narrow',sans-serif" font-size="6.5" fill="white" letter-spacing="2" opacity="0.97" clip-path="url(#cp19b)">NAQAA</text>
          <!-- Arabic نقاء -->
          <text x="27" y="67.5" text-anchor="middle" font-family="'Amiri','Traditional Arabic','Arial Unicode MS',serif" font-size="5" fill="#7ad4ef" opacity="0.90" clip-path="url(#cp19b)">نقاء</text>
          <!-- Shoulder ridges -->
          <rect x="9" y="38" width="36" height="2.5" rx="1.25" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp19b)"/>
          <rect x="9" y="41" width="36" height="1.5" rx="0.75" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp19b)"/>
          <!-- Shine streaks -->
          <rect x="14" y="27" width="4" height="70" rx="2" fill="white" opacity="0.24"/>
          <rect x="20" y="27" width="1.5" height="38" rx="0.75" fill="white" opacity="0.1"/>
          <!-- Shoulder collar -->
          <rect x="12" y="20" width="30" height="5" rx="2.5" fill="#00d4f5" opacity="0.45"/>
          <!-- Bottom dome -->
          <path d="M9,86 Q9,100 27,102 Q45,100 45,86 L45,93 Q45,107 27,109 Q9,107 9,93 Z" fill="#005f87" opacity="0.28"/>
          <!-- Recycle badge -->
          <circle cx="40" cy="94" r="7" fill="#00d4f5" opacity="0.18" stroke="#00d4f5" stroke-width="0.8"/>
          <text x="40" y="97" text-anchor="middle" font-family="sans-serif" font-size="8" fill="#00d4f5">♻</text>
          <!-- Cap (green = rechargeable) -->
          <rect x="17" y="1" width="20" height="9" rx="4.5" fill="url(#cap19b)"/>
          <rect x="17" y="7" width="20" height="3" fill="#00a87a"/>
          <!-- Cap shine -->
          <rect x="18.5" y="1.5" width="5" height="4" rx="2" fill="white" opacity="0.35"/>
        </svg>
        <span style="font-size:0.78rem;color:var(--muted2);margin-left:14px;">≈ 38 verres<br>de 500 mL</span>
      </div>
    </div>

    <!-- ── CTA ── -->
    <div class="product-cta-card reveal reveal-delay-1">
      <div class="product-icon">🛒</div>
      <h3>Prêt à Commander ?</h3>
      <p>Connectez-vous à votre espace client pour accéder au catalogue complet NAQAA avec les tarifs et passer vos commandes en ligne.</p>
      <a href="login_client.php" class="btn-primary">Connexion Client</a>
      <a href="login_client.php#register" class="btn-secondary">Créer un Compte</a>
    </div>

  </div>
</section>

<!-- ─── FOOTER ─── -->
<footer>
  <div class="footer-logo">
    <svg width="18" height="18" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;margin-right:6px;">
      <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
      <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
      <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
    </svg>
    NAQAA
  </div>
  <div class="footer-links">
    <a href="login.php">Connexion</a>
    <a href="#apropos">Système</a>
    <a href="#marques">Produits</a>
  </div>
  <div>© 2026 AquaStock/NAQAA نقاء — Système de Gestion du stock et de facturation d'une Usine d'Eau Minérale</div>
</footer>

<script>
// ─── PARTICLES
const c = document.getElementById('particles');
for(let i=0;i<40;i++){
  const d=document.createElement('div'); d.className='drop'+(Math.random()>0.7?' glow':'');
  const s=1.5+Math.random()*5;
  d.style.cssText=`left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*15}s;`;
  c.appendChild(d);
}

// ─── SCROLL PROGRESS LINE
const line=document.getElementById('scrollLine');
window.addEventListener('scroll',()=>{
  const h=document.documentElement.scrollHeight-window.innerHeight;
  line.style.width=(window.scrollY/h*100)+'%';
},{ passive:true });

// ─── SCROLL REVEAL
const obs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('visible'); obs.unobserve(e.target); } });
},{threshold:0.12});
document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));

// ─── NAV BACKGROUND
const nav=document.querySelector('nav');
window.addEventListener('scroll',()=>{
  nav.style.background=window.scrollY>60?'rgba(2,11,20,0.92)':'rgba(2,11,20,0.7)';
},{ passive:true });
</script>
</body>
</html>