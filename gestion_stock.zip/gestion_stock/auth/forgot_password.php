<?php
ob_start();
session_start();
include __DIR__ . "/../config/db.php";

$step  = 1;
$error = "";

if (isset($_GET['reset'])) {
    unset($_SESSION['fp_user']);
    ob_end_clean();
    header("Location: forgot_password.php");
    exit();
}

// ── STEP 1 : Find account by login, email or address ──────────────────────
if (isset($_POST['step1'])) {
    $identifier = trim($_POST['identifier'] ?? '');
    if (empty($identifier)) {
        $error = "Veuillez saisir votre identifiant, e-mail ou adresse.";
        $step  = 1;
    } else {
        $found = false;
        $like  = '%' . $identifier . '%';

        // 1a. Search in responsable table (login, email, ville, localisation)
        $stmt = $conn->prepare("SELECT idResponsable AS uid, COALESCE(NULLIF(full_name,''),nom) AS nom, login, email, role, 'responsable' AS table_name FROM responsable WHERE login=? OR email=? OR ville=? OR localisation LIKE ? LIMIT 1");
        $stmt->bind_param("ssss", $identifier, $identifier, $identifier, $like);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($row) {
            $_SESSION['fp_user'] = $row;
            $found = true;
            $step  = 2;
        }

        // 1b. Search in client table (login, email, adresse)
        if (!$found) {
            $stmt2 = $conn->prepare("SELECT idClient AS uid, nom, login, email, 'client' AS role, 'client' AS table_name FROM client WHERE login=? OR email=? OR adresse LIKE ? LIMIT 1");
            $stmt2->bind_param("sss", $identifier, $identifier, $like);
            $stmt2->execute();
            $row2 = $stmt2->get_result()->fetch_assoc();
            $stmt2->close();

            if ($row2) {
                $_SESSION['fp_user'] = $row2;
                $found = true;
                $step  = 2;
            }
        }

        if (!$found) {
            $error = "Aucun compte trouvé avec cet identifiant, e-mail ou adresse.";
            $step  = 1;
        }
    }
}

// ── STEP 2 : Set new password ──────────────────────────────────────────────
if (isset($_POST['step2'])) {
    $row     = $_SESSION['fp_user'] ?? null;
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!$row) {
        $step = 1; $error = "Session expirée, recommencez.";
    } elseif (strlen($new) < 8) {
        $error = "Le mot de passe doit contenir au moins 8 caractères."; $step = 2;
    } elseif ($new !== $confirm) {
        $error = "Les mots de passe ne correspondent pas."; $step = 2;
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);

        if ($row['table_name'] === 'responsable') {
            $upd = $conn->prepare("UPDATE responsable SET motdepasse = ? WHERE idResponsable = ?");
        } else {
            $upd = $conn->prepare("UPDATE client SET motdepasse = ? WHERE idClient = ?");
        }
        $upd->bind_param("si", $hashed, $row['uid']);

        if ($upd->execute()) {
            unset($_SESSION['fp_user']);
            $step = 3;
        } else {
            $error = "Erreur lors de la mise à jour. Réessayez."; $step = 2;
        }
        $upd->close();
    }
}

// Session rehydration
$sessionUser = $_SESSION['fp_user'] ?? null;
if ($step === 1 && $sessionUser && !isset($_POST['step1'])) $step = 2;

// Role label helper
function roleLabel($role) {
    return match($role) {
        'admin'              => '🛡️ Administrateur',
        'responsable_clients'=> '📋 Responsable',
        default              => '🛒 Client',
    };
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mot de passe oublié — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { font-family:'Outfit',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; overflow-x:hidden; }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:transparent; }
::-webkit-scrollbar-thumb { background:var(--accent2); border-radius:10px; }

.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 90% 70% at 20% 50%,rgba(0,119,168,0.22) 0%,transparent 60%),
    radial-gradient(ellipse 50% 50% at 85% 15%,rgba(0,212,245,0.07) 0%,transparent 55%),
    radial-gradient(ellipse 35% 35% at 10% 90%,rgba(0,255,204,0.05) 0%,transparent 50%);
}
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px,transparent 1px),
    linear-gradient(90deg,rgba(0,212,245,0.025) 1px,transparent 1px);
  background-size:60px 60px;
}
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background:radial-gradient(circle at 30% 30%,var(--accent),rgba(0,119,168,0.3));
  animation:rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
@keyframes rise { 0%{transform:translateY(100vh) scale(0.2);opacity:0} 10%{opacity:.45} 90%{opacity:.08} 100%{transform:translateY(-5vh) scale(1.8);opacity:0} }

.split { position:relative; z-index:10; display:flex; width:100%; min-height:100vh; align-items:stretch; }

/* LEFT */
.left { flex:1; display:flex; flex-direction:column; justify-content:center; padding:70px 64px; border-right:1px solid var(--border); position:relative; overflow:hidden; animation:slideL .8s cubic-bezier(.22,1,.36,1) both; }
@keyframes slideL { from{opacity:0;transform:translateX(-32px)} to{opacity:1;transform:translateX(0)} }
.brand { display:flex; align-items:center; gap:14px; margin-bottom:56px; text-decoration:none; width:fit-content; }
.brand-icon { width:52px; height:52px; border-radius:14px; background:linear-gradient(135deg,var(--accent),var(--accent2)); display:flex; align-items:center; justify-content:center; font-size:24px; box-shadow:0 0 36px rgba(0,212,245,0.4); animation:float 4s ease-in-out infinite; }
@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
.brand-name { font-family:'Bebas Neue',sans-serif; font-size:28px; letter-spacing:3px; color:var(--text); }
.brand-name span { color:var(--accent); }
.left-headline { font-family:'Bebas Neue',sans-serif; font-size:clamp(44px,5vw,68px); line-height:.95; letter-spacing:1px; margin-bottom:24px; }
.left-headline .solid { display:block; }
.left-headline .hl    { display:block; color:transparent; -webkit-text-stroke:1.5px var(--accent); }
.left-headline .hl2   { display:block; color:var(--accent); }
.left-desc { font-size:14px; color:var(--muted2); line-height:1.8; max-width:380px; margin-bottom:48px; font-weight:300; }
.feat-list { display:flex; flex-direction:column; gap:10px; max-width:380px; }
.feat { display:flex; align-items:center; gap:14px; padding:13px 16px; border-radius:12px; background:var(--surface); border:1px solid var(--border); transition:all .3s; }
.feat:hover { border-color:var(--border2); background:var(--surface2); transform:translateX(6px); box-shadow:-3px 0 0 var(--accent); }
.feat-icon { width:34px; height:34px; border-radius:9px; background:rgba(0,212,245,0.1); display:flex; align-items:center; justify-content:center; font-size:15px; flex-shrink:0; }
.feat-text strong { display:block; font-size:12px; font-weight:600; color:var(--text); margin-bottom:1px; }
.feat-text span   { font-size:11px; color:var(--muted); }
.status-badge { display:inline-flex; align-items:center; gap:9px; margin-top:36px; padding:8px 16px; border:1px solid rgba(0,255,204,0.2); border-radius:100px; font-size:11px; color:var(--accent3); background:rgba(0,255,204,0.05); }
.status-dot { width:7px; height:7px; border-radius:50%; background:var(--accent3); position:relative; }
.status-dot::after { content:''; position:absolute; inset:-3px; border-radius:50%; border:1px solid var(--accent3); animation:ripple 2s ease-in-out infinite; }
@keyframes ripple { 0%,100%{transform:scale(1);opacity:.8} 50%{transform:scale(2);opacity:0} }

/* RIGHT */
.right { width:460px; flex-shrink:0; display:flex; flex-direction:column; justify-content:center; padding:60px 52px; position:relative; animation:slideR .8s cubic-bezier(.22,1,.36,1) both .1s; }
@keyframes slideR { from{opacity:0;transform:translateX(32px)} to{opacity:1;transform:translateX(0)} }
.back-btn { position:absolute; top:28px; left:28px; display:flex; align-items:center; gap:7px; padding:8px 15px; border:1px solid var(--border); border-radius:9px; text-decoration:none; color:var(--muted); font-size:12px; font-weight:500; background:rgba(2,11,20,0.7); backdrop-filter:blur(10px); transition:all .25s; }
.back-btn:hover { color:var(--accent); border-color:var(--border2); }
.portal-tag { display:inline-flex; align-items:center; gap:8px; padding:6px 14px; border:1px solid var(--border2); border-radius:100px; font-size:10px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; color:var(--accent); background:rgba(0,212,245,0.05); margin-bottom:24px; width:fit-content; }
.portal-dot { width:6px; height:6px; border-radius:50%; background:var(--accent); box-shadow:0 0 8px var(--accent); animation:blink 2s ease-in-out infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.2} }
.form-title { font-family:'Bebas Neue',sans-serif; font-size:42px; letter-spacing:1px; line-height:1; margin-bottom:6px; }
.form-sub   { font-size:13px; color:var(--muted); margin-bottom:28px; line-height:1.6; font-weight:300; }

/* STEPPER */
.stepper { display:flex; align-items:center; margin-bottom:32px; }
.st-item { display:flex; align-items:center; position:relative; }
.st-item:not(:last-child) { flex:1; }
.st-dot { width:30px; height:30px; border-radius:50%; flex-shrink:0; z-index:1; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:700; transition:all .4s; border:1.5px solid var(--border); background:var(--bg); color:var(--muted); }
.st-dot.active { border-color:var(--accent); background:rgba(0,212,245,0.12); color:var(--accent); box-shadow:0 0 14px rgba(0,212,245,0.25); }
.st-dot.done   { border-color:var(--green);  background:rgba(0,255,204,0.1);  color:var(--green); }
.st-line { flex:1; height:1.5px; background:var(--border); margin:0 6px; transition:background .4s; }
.st-line.done { background:linear-gradient(90deg,var(--green),var(--accent)); }
.st-lbl { position:absolute; top:36px; left:50%; transform:translateX(-50%); font-size:8.5px; font-weight:700; text-transform:uppercase; letter-spacing:1px; white-space:nowrap; pointer-events:none; }

/* ALERT */
.alert { display:flex; align-items:flex-start; gap:10px; padding:12px 15px; border-radius:11px; margin-bottom:22px; font-size:13px; font-weight:500; line-height:1.5; animation:shake .4s ease; }
.alert-error { background:rgba(244,63,94,0.08); border:1px solid rgba(244,63,94,0.25); color:#fca5a5; }
@keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-5px)} 75%{transform:translateX(5px)} }

/* FORM */
.form-group { margin-bottom:20px; }
.form-group label { display:block; font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:var(--muted); margin-bottom:9px; }
.input-wrap { position:relative; }
.i-ico { position:absolute; left:14px; top:50%; transform:translateY(-50%); font-size:14px; pointer-events:none; opacity:.45; }
.form-group input { width:100%; padding:14px 16px 14px 42px; border-radius:11px; border:1.5px solid var(--border); background:rgba(0,0,0,0.35); color:var(--text); font-size:14px; font-family:'Outfit',sans-serif; outline:none; transition:all .25s; }
.form-group input:focus { border-color:var(--accent); background:rgba(0,212,245,0.04); box-shadow:0 0 0 4px rgba(0,212,245,0.08),0 0 20px rgba(0,212,245,0.1); }
.form-group input::placeholder { color:rgba(90,128,152,0.5); }
.form-group input.valid   { border-color:rgba(0,255,204,0.5); }
.form-group input.invalid { border-color:rgba(244,63,94,0.5); }
.field-hint { font-size:10.5px; color:var(--muted); margin-top:5px; }
.pw-wrap input { padding-right:48px; }
.pw-eye { position:absolute; right:14px; top:50%; transform:translateY(-50%); cursor:pointer; font-size:15px; color:var(--muted); transition:color .2s; user-select:none; }
.pw-eye:hover { color:var(--accent); }
.strength-bar  { height:3px; border-radius:10px; margin-top:7px; background:var(--border); overflow:hidden; display:none; }
.strength-fill { height:100%; width:0%; border-radius:10px; transition:width .35s,background .35s; }

/* ACCOUNT BOX */
.account-box { display:flex; align-items:center; gap:13px; padding:13px 15px; background:rgba(0,212,245,0.04); border:1px solid rgba(0,212,245,0.15); border-radius:11px; margin-bottom:24px; }
.account-avatar { width:40px; height:40px; border-radius:50%; flex-shrink:0; background:linear-gradient(135deg,var(--accent2),var(--accent)); display:flex; align-items:center; justify-content:center; font-size:17px; }
.account-details strong { display:block; font-size:13px; font-weight:600; margin-bottom:2px; }
.account-details span   { font-size:11px; color:var(--muted2); }
.role-pill { display:inline-flex; align-items:center; gap:5px; margin-top:4px; padding:3px 10px; border-radius:100px; font-size:10px; font-weight:700; letter-spacing:.5px; background:rgba(0,212,245,0.08); border:1px solid var(--border2); color:var(--accent); }

/* SUBMIT */
.btn-submit { width:100%; padding:15px; border:none; border-radius:11px; margin-top:4px; background:linear-gradient(135deg,var(--accent),var(--accent2)); color:#020b14; font-family:'Bebas Neue',sans-serif; font-size:20px; letter-spacing:2px; cursor:pointer; transition:all .25s; position:relative; overflow:hidden; box-shadow:0 0 24px rgba(0,212,245,0.2); }
.btn-submit::before { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(255,255,255,0.15),transparent); opacity:0; transition:opacity .25s; }
.btn-submit:hover { transform:translateY(-2px); box-shadow:0 0 40px rgba(0,212,245,0.4); }
.btn-submit:hover::before { opacity:1; }
.btn-submit:active { transform:translateY(0); }

/* LINKS */
.or-divider { display:flex; align-items:center; gap:12px; color:var(--muted); font-size:11px; letter-spacing:1px; margin:24px 0; }
.or-divider::before,.or-divider::after { content:''; flex:1; height:1px; background:var(--border); }
.portal-links { display:flex; flex-direction:column; gap:10px; }
.portal-link { display:flex; align-items:center; gap:12px; padding:13px 16px; border:1px solid var(--border); border-radius:11px; text-decoration:none; color:var(--muted2); font-size:13px; font-weight:500; background:var(--surface); transition:all .25s; }
.portal-link:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-2px); }
.pl-icon { width:32px; height:32px; border-radius:8px; background:rgba(0,212,245,0.08); border:1px solid var(--border); display:flex; align-items:center; justify-content:center; font-size:14px; flex-shrink:0; }
.pl-arrow { margin-left:auto; font-size:14px; color:var(--muted); transition:all .25s; }
.portal-link:hover .pl-arrow { color:var(--accent); transform:translateX(4px); }

/* SUCCESS */
.success-icon { font-size:52px; display:block; margin-bottom:16px; animation:popIn .5s cubic-bezier(.22,1,.36,1); }
@keyframes popIn { from{transform:scale(.3);opacity:0} to{transform:scale(1);opacity:1} }
.success-note { font-size:13px; color:var(--muted2); line-height:1.8; margin-bottom:28px; font-weight:300; }

@media(max-width:860px){ .left{display:none;} .right{width:100%;padding:40px 28px;} .back-btn{top:18px;left:18px;} }
</style>
</head>
<body>

<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="particles" id="particles"></div>

<div class="split">

  <!-- ════ LEFT ════ -->
  <div class="left">
    <a href="login.php" class="brand">
      <div class="brand-icon">💧</div>
      <div class="brand-name"><span>Aqua</span>Stock</div>
    </a>

    <?php if ($step === 1): ?>
    <h1 class="left-headline">
      <span class="solid">Retrouvez</span>
      <span class="hl">votre</span>
      <span class="hl2">ACCÈS</span>
    </h1>
    <p class="left-desc">Entrez votre <strong style="color:var(--accent)">login</strong>, <strong style="color:var(--accent)">e-mail</strong> ou <strong style="color:var(--accent)">adresse</strong> associée à votre compte — admin, responsable ou client — et créez un nouveau mot de passe en quelques secondes.</p>
    <div class="feat-list">
      <div class="feat"><div class="feat-icon">🛡️</div><div class="feat-text"><strong>Tous les rôles</strong><span>Fonctionne pour admin, responsable et client</span></div></div>
      <div class="feat"><div class="feat-icon">🔒</div><div class="feat-text"><strong>Mot de passe chiffré</strong><span>Votre nouveau mot de passe est stocké de façon sécurisée</span></div></div>
      <div class="feat"><div class="feat-icon">⚡</div><div class="feat-text"><strong>Processus rapide</strong><span>Seulement 2 étapes pour récupérer votre accès</span></div></div>
    </div>
    <?php elseif ($step === 2): ?>
    <h1 class="left-headline">
      <span class="solid">Nouveau</span>
      <span class="hl">mot de</span>
      <span class="hl2">PASSE</span>
    </h1>
    <p class="left-desc">Compte trouvé ! Choisissez un nouveau mot de passe fort pour sécuriser votre compte AquaStock.</p>
    <div class="feat-list">
      <div class="feat"><div class="feat-icon">💪</div><div class="feat-text"><strong>Mot de passe fort</strong><span>Minimum 8 caractères, avec chiffres et symboles</span></div></div>
      <div class="feat"><div class="feat-icon">🔄</div><div class="feat-text"><strong>Remplacement immédiat</strong><span>L'ancien mot de passe est désactivé instantanément</span></div></div>
      <div class="feat"><div class="feat-icon">✅</div><div class="feat-text"><strong>Confirmation requise</strong><span>Saisissez deux fois pour éviter toute erreur</span></div></div>
    </div>
    <?php else: ?>
    <h1 class="left-headline">
      <span class="solid">Accès</span>
      <span class="hl">restauré</span>
      <span class="hl2">AVEC SUCCÈS</span>
    </h1>
    <p class="left-desc">Votre mot de passe est mis à jour. Vous pouvez maintenant vous connecter avec vos nouvelles informations.</p>
    <div class="feat-list">
      <div class="feat"><div class="feat-icon">🔒</div><div class="feat-text"><strong>Compte sécurisé</strong><span>Nouveau mot de passe actif et chiffré</span></div></div>
      <div class="feat"><div class="feat-icon">🚀</div><div class="feat-text"><strong>Accès restauré</strong><span>Connectez-vous avec vos nouvelles informations</span></div></div>
    </div>
    <?php endif; ?>

    <div class="status-badge">
      <div class="status-dot"></div>
      <?php if($step===3): ?>Terminé ✓
      <?php else: ?>Étape <?= $step ?> sur 2<?php endif; ?>
    </div>
  </div>

  <!-- ════ RIGHT ════ -->
  <div class="right">
    <a href="login.php" class="back-btn">← Connexion</a>

    <div class="portal-tag">
      <span class="portal-dot"></span>
      Réinitialisation
    </div>

    <?php if ($step < 3): ?>
    <div class="stepper">
      <div class="st-item">
        <div class="st-dot <?= $step > 1 ? 'done' : 'active' ?>"><?= $step > 1 ? '✓' : '1' ?></div>
        <span class="st-lbl" style="color:<?= $step===1?'var(--accent)':'var(--green)' ?>">Identifiant</span>
        <div class="st-line <?= $step > 1 ? 'done' : '' ?>"></div>
      </div>
      <div class="st-item">
        <div class="st-dot <?= $step === 2 ? 'active' : '' ?>">2</div>
        <span class="st-lbl" style="color:<?= $step===2?'var(--accent)':'var(--muted)' ?>">Mot de passe</span>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- ════ STEP 1 ════ -->
    <?php if ($step === 1): ?>

    <div class="form-title">Mot de passe<br>oublié ?</div>
    <p class="form-sub">Entrez votre login, e-mail ou adresse — nous retrouverons votre compte.</p>

    <form method="POST" autocomplete="off" novalidate>
      <div class="form-group">
        <label>Login, E-mail ou Adresse</label>
        <div class="input-wrap">
          <span class="i-ico">🔍</span>
          <input type="text" name="identifier" id="identifierInput"
                 placeholder="votre login, email ou adresse"
                 value="<?= htmlspecialchars($_POST['identifier'] ?? '') ?>"
                 required autofocus>
        </div>
        <div class="field-hint" style="color:var(--muted);margin-top:5px;">Fonctionne pour admin, responsable et client.</div>
      </div>
      <button type="submit" name="step1" class="btn-submit">Rechercher mon compte →</button>
    </form>

    <div class="or-divider">vous souvenez-vous ?</div>
    <div class="portal-links">
      <a href="login.php" class="portal-link">
        <div class="pl-icon">🔑</div>
        Retour à la connexion
        <span class="pl-arrow">→</span>
      </a>
    </div>

    <!-- ════ STEP 2 ════ -->
    <?php elseif ($step === 2):
      $row = $sessionUser;
      $avatarIcon = match($row['role']) { 'admin' => '🛡️', 'responsable_clients' => '📋', default => '🛒' };
    ?>

    <div class="form-title">Nouveau<br>mot de passe</div>
    <p class="form-sub">Compte trouvé. Créez un nouveau mot de passe sécurisé.</p>

    <div class="account-box">
      <div class="account-avatar"><?= $avatarIcon ?></div>
      <div class="account-details">
        <strong><?= htmlspecialchars($row['nom']) ?></strong>
        <span><?= htmlspecialchars($row['email']) ?></span>
        <div class="role-pill"><?= roleLabel($row['role']) ?></div>
      </div>
    </div>

    <form method="POST" autocomplete="off">
      <div class="form-group">
        <label>Nouveau mot de passe</label>
        <div class="input-wrap pw-wrap">
          <span class="i-ico">🔑</span>
          <input type="password" name="new_password" id="newPwd"
                 placeholder="Minimum 8 caractères" required autocomplete="new-password"
                 oninput="checkStrength(this.value)">
          <span class="pw-eye" onclick="togglePw('newPwd',this)">👁</span>
        </div>
        <div class="strength-bar" id="strengthBar"><div class="strength-fill" id="strengthFill"></div></div>
        <div class="field-hint" id="strengthLabel"></div>
      </div>
      <div class="form-group">
        <label>Confirmer le mot de passe</label>
        <div class="input-wrap pw-wrap">
          <span class="i-ico">🔑</span>
          <input type="password" name="confirm_password" id="confirmPwd"
                 placeholder="Répétez le mot de passe" required autocomplete="new-password"
                 oninput="checkMatch()">
          <span class="pw-eye" onclick="togglePw('confirmPwd',this)">👁</span>
        </div>
        <div class="field-hint" id="matchHint"></div>
      </div>
      <button type="submit" name="step2" class="btn-submit">🔐 Enregistrer →</button>
    </form>

    <div class="or-divider">changer de compte ?</div>
    <div class="portal-links">
      <a href="?reset=1" class="portal-link">
        <div class="pl-icon">↩️</div>
        Recommencer avec un autre e-mail
        <span class="pl-arrow">→</span>
      </a>
    </div>

    <!-- ════ STEP 3 ════ -->
    <?php elseif ($step === 3): ?>

    <span class="success-icon">✅</span>
    <div class="form-title" style="color:var(--green)">Mot de passe<br>réinitialisé !</div>
    <p class="success-note">
      Votre mot de passe a été mis à jour avec succès.<br>
      Vous pouvez maintenant vous connecter avec vos nouvelles informations.
    </p>

    <div class="portal-links">
      <a href="login.php" class="portal-link"
         style="border-color:rgba(0,255,204,0.25);background:rgba(0,255,204,0.05);color:var(--green)">
        <div class="pl-icon" style="background:rgba(0,255,204,0.1);border-color:rgba(0,255,204,0.2)">→</div>
        Se connecter maintenant
        <span class="pl-arrow" style="color:var(--green)">→</span>
      </a>
    </div>

    <?php endif; ?>

  </div>
</div>

<script>
const pc = document.getElementById('particles');
for (let i = 0; i < 30; i++) {
  const d = document.createElement('div'); d.className = 'drop';
  const s = 1.5 + Math.random() * 3.5;
  d.style.cssText = `left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*14}s;`;
  pc.appendChild(d);
}

function validateEmail(inp) {
  const h = document.getElementById('emailHint');
  if (!h) return;
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inp.value);
  inp.classList.toggle('valid',   inp.value.length > 0 && ok);
  inp.classList.toggle('invalid', inp.value.length > 0 && !ok);
  h.textContent = inp.value.length > 0 && !ok ? '✗ Format d\'e-mail invalide' : '';
  h.style.color = '#fca5a5';
}

function togglePw(id, btn) {
  const f = document.getElementById(id);
  if (!f) return;
  f.type = f.type === 'password' ? 'text' : 'password';
  if (btn) btn.textContent = f.type === 'password' ? '👁' : '🙈';
}

function checkStrength(val) {
  const bar   = document.getElementById('strengthBar');
  const fill  = document.getElementById('strengthFill');
  const label = document.getElementById('strengthLabel');
  if (!bar) return;
  bar.style.display = val.length ? 'block' : 'none';
  let score = 0;
  if (val.length >= 8)           score++;
  if (val.length >= 12)          score++;
  if (/[A-Z]/.test(val))         score++;
  if (/[0-9]/.test(val))         score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const lvl = [
    {w:'20%',c:'#f43f5e',t:'Très faible'},
    {w:'40%',c:'#f97316',t:'Faible'},
    {w:'60%',c:'#facc15',t:'Moyen'},
    {w:'80%',c:'#a3e635',t:'Fort'},
    {w:'100%',c:'#00ffcc',t:'Très fort'},
  ];
  const l = lvl[Math.min(score, 4)];
  fill.style.width      = l.w;
  fill.style.background = l.c;
  if (label) { label.textContent = l.t; label.style.color = l.c; }
  checkMatch();
}

function checkMatch() {
  const np = document.getElementById('newPwd');
  const cp = document.getElementById('confirmPwd');
  const h  = document.getElementById('matchHint');
  if (!np || !cp || !h || !cp.value) { if(h) h.textContent=''; return; }
  const ok = np.value === cp.value;
  h.textContent  = ok ? '✓ Les mots de passe correspondent' : '✗ Les mots de passe ne correspondent pas';
  h.style.color  = ok ? 'var(--green)' : '#fca5a5';
  cp.classList.toggle('valid',   ok);
  cp.classList.toggle('invalid', !ok);
}
</script>
</body>
</html>