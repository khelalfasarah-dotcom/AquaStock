</div><!-- .main -->
</div><!-- .layout -->

<script>
// ── SCROLL PROGRESS LINE — identical to index.php & login.php
(function(){
  const line = document.getElementById('scrollLine');
  if(!line) return;
  function updateLine(){
    const h = document.documentElement.scrollHeight - window.innerHeight;
    line.style.width = (h > 0 ? (window.scrollY / h * 100) : 0) + '%';
  }
  window.addEventListener('scroll', updateLine, { passive:true });
  updateLine(); // init
})();

// ── FLOATING PARTICLES — identical to index.php & login.php
(function(){
  const c = document.getElementById('particles');
  if(!c) return;
  for(let i = 0; i < 30; i++){
    const d = document.createElement('div');
    d.className = 'drop' + (Math.random() > 0.7 ? ' glow' : '');
    const s = 1.5 + Math.random() * 4.5;
    d.style.cssText =
      'left:'  + (Math.random()*100) + '%;' +
      'width:' + s + 'px;height:' + s + 'px;' +
      '--d:'   + (5 + Math.random()*12) + 's;' +
      '--delay:'+ (Math.random()*16) + 's;';
    c.appendChild(d);
  }
})();
</script>
</body>
</html>
