<?php
$current = basename($_SERVER['PHP_SELF']);
function isActive($page, $current) { return $page === $current ? 'active' : ''; }
?>
<div class="sidebar">
    <div class="brand">
        <h2>
            <div class="brand-icon">💧</div>
            AquaStock
        </h2>
        <span>Usine d'Eau — ERP</span>
    </div>
    <a href="../views/dashboard.php" class="<?= isActive('dashboard.php', $current) ?>">
        <span class="icon">📊</span> Tableau de bord
    </a>
    <a href="../views/clients.php" class="<?= isActive('clients.php', $current) ?>">
        <span class="icon">👥</span> Clients
    </a>
    <a href="../views/produits.php" class="<?= isActive('produits.php', $current) ?>">
        <span class="icon">🍶</span> Produits
    </a>
    <a href="../views/commandes.php" class="<?= isActive('commandes.php', $current) ?>">
        <span class="icon">📦</span> Commandes
    </a>
    <a href="../views/factures.php" class="<?= isActive('factures.php', $current) ?>">
        <span class="icon">🧾</span> Factures
    </a>
    <a href="../views/team.php" class="<?= isActive('team.php', $current) ?>">
        <span class="icon">🛡️</span> Équipe
    </a>
    <div class="logout-wrap">
        <a href="../auth/logout.php"><span class="icon">🚪</span> Déconnexion</a>
    </div>
</div>
