<?php if(!isset($pageTitle)) $pageTitle = "Tableau de bord"; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?> — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- Background layers (same as index/login) -->
<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="scroll-line" id="scrollLine"></div>
<div class="particles" id="particles"></div>

<div class="layout">
<?php include_once "../components/sidebar.php"; ?>
<div class="main">

<?php
if(!isset($conn)) require_once __DIR__ . "/../config/db.php";

$_bellAlerts = $conn->query("
    SELECT nomProduit, volume, quantiteStock, btParFardeau,
           FLOOR(quantiteStock / btParFardeau) AS fardeaux
    FROM produit
    WHERE FLOOR(quantiteStock / btParFardeau) < 10 OR quantiteStock < 0
    ORDER BY fardeaux ASC
");
$_bellRows = [];
if($_bellAlerts) while($_ba = $_bellAlerts->fetch_assoc()) $_bellRows[] = $_ba;
$_negStock   = array_values(array_filter($_bellRows, fn($x) => (int)$x['fardeaux'] < 0));
$_outOfStock = array_values(array_filter($_bellRows, fn($x) => (int)$x['fardeaux'] === 0));
$_critStock  = array_values(array_filter($_bellRows, fn($x) => (int)$x['fardeaux'] > 0 && (int)$x['fardeaux'] < 5));
$_lowStock   = array_values(array_filter($_bellRows, fn($x) => (int)$x['fardeaux'] >= 5 && (int)$x['fardeaux'] < 10));
$_bellCount  = count($_bellRows);
?>

<style>
/* ── Notification dropdown ── */
.notif-bell {
  background:var(--surface); border:1px solid var(--border); border-radius:10px;
  width:40px; height:40px; display:flex; align-items:center; justify-content:center;
  cursor:pointer; font-size:17px; transition:all .2s; position:relative; color:var(--text);
}
.notif-bell:hover { border-color:var(--border2); background:var(--surface2); box-shadow:0 0 16px rgba(0,212,245,0.15); }
.notif-badge {
  position:absolute; top:-7px; right:-7px; background:#f43f5e; color:white;
  font-size:10px; font-weight:700; border-radius:99px; min-width:18px; height:18px;
  display:flex; align-items:center; justify-content:center; padding:0 4px;
  border:2px solid var(--bg);
}
.notif-dropdown {
  position:absolute; top:calc(100% + 10px); right:0; width:340px;
  background:rgba(8,20,40,0.97); border:1px solid var(--border);
  border-radius:14px; box-shadow:0 20px 60px rgba(0,0,0,0.6);
  z-index:9999; display:none; overflow:hidden; backdrop-filter:blur(20px);
}
.notif-dropdown.open { display:block; animation:fadeDown .15s ease; }
@keyframes fadeDown { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
.notif-hdr { padding:14px 18px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
.notif-hdr strong { font-family:'Bebas Neue',sans-serif; font-size:16px; letter-spacing:0.5px; }
.notif-body { max-height:380px; overflow-y:auto; }
.notif-group { padding:7px 18px 3px; font-size:10px; text-transform:uppercase; letter-spacing:.8px; color:var(--muted); font-weight:700; background:rgba(0,0,0,0.2); }
.notif-item { display:flex; align-items:center; gap:12px; padding:11px 18px; border-bottom:1px solid rgba(0,212,245,0.04); transition:.15s; }
.notif-item:last-child { border:none; }
.notif-item:hover { background:rgba(0,212,245,0.04); }
.notif-icon { width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; font-size:17px; flex-shrink:0; }
.notif-icon.red    { background:rgba(244,63,94,0.15); }
.notif-icon.yellow { background:rgba(251,191,36,0.12); }
.notif-icon.blue   { background:rgba(0,212,245,0.1); }
.notif-name { font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.notif-sub  { font-size:11px; margin-top:2px; }
.notif-empty { padding:32px 18px; text-align:center; color:var(--muted); font-size:13px; }
.notif-footer { padding:10px 18px; border-top:1px solid var(--border); text-align:center; }
.notif-footer a { font-size:12px; color:var(--accent); text-decoration:none; font-weight:600; }
.notif-footer a:hover { text-decoration:underline; }
</style>

<div class="topbar">
    <div class="page-name"><?= $pageTitle ?></div>
    <div style="display:flex;align-items:center;gap:14px;">

        <!-- 🔔 Bell -->
        <div class="notif-wrap">
            <button class="notif-bell" onclick="toggleNotif(event)" title="Alertes stock">
                🔔
                <?php if($_bellCount > 0): ?>
                <span class="notif-badge"><?= $_bellCount ?></span>
                <?php endif; ?>
            </button>
            <div class="notif-dropdown" id="notifDropdown">
                <div class="notif-hdr">
                    <strong>🔔 Alertes Stock</strong>
                    <?php if($_bellCount > 0): ?>
                    <span style="font-size:11px;color:var(--muted);"><?= $_bellCount ?> produit<?= $_bellCount>1?'s':'' ?></span>
                    <?php endif; ?>
                </div>
                <div class="notif-body">
                    <?php if($_bellCount === 0): ?>
                    <div class="notif-empty">✅ Tous les stocks sont suffisants</div>
                    <?php else: ?>
                    <?php if(!empty($_negStock)): ?>
                    <div class="notif-group">🔴 Stock dépassé — urgent</div>
                    <?php foreach($_negStock as $_r): ?>
                    <div class="notif-item"><div class="notif-icon red">🔴</div><div style="flex:1;min-width:0;"><div class="notif-name"><?= htmlspecialchars($_r['nomProduit']) ?> <?= htmlspecialchars($_r['volume']) ?></div><div class="notif-sub" style="color:#f43f5e;">Déficit de <?= abs((int)$_r['fardeaux']) ?> fardeau<?= abs((int)$_r['fardeaux'])>1?'x':'' ?></div></div></div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    <?php if(!empty($_outOfStock)): ?>
                    <div class="notif-group">🚨 Rupture totale</div>
                    <?php foreach($_outOfStock as $_r): ?>
                    <div class="notif-item"><div class="notif-icon red">🚨</div><div style="flex:1;min-width:0;"><div class="notif-name"><?= htmlspecialchars($_r['nomProduit']) ?> <?= htmlspecialchars($_r['volume']) ?></div><div class="notif-sub" style="color:#f43f5e;">0 fardeau — Stock épuisé</div></div></div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    <?php if(!empty($_critStock)): ?>
                    <div class="notif-group">⚠️ Stock critique (&lt;5 fardeaux)</div>
                    <?php foreach($_critStock as $_r): ?>
                    <div class="notif-item"><div class="notif-icon yellow">⚠️</div><div style="flex:1;min-width:0;"><div class="notif-name"><?= htmlspecialchars($_r['nomProduit']) ?> <?= htmlspecialchars($_r['volume']) ?></div><div class="notif-sub" style="color:#fbbf24;"><?= (int)$_r['fardeaux'] ?> fardeau<?= (int)$_r['fardeaux']>1?'x':'' ?> restant</div></div></div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    <?php if(!empty($_lowStock)): ?>
                    <div class="notif-group">📉 Stock bas (5–9 fardeaux)</div>
                    <?php foreach($_lowStock as $_r): ?>
                    <div class="notif-item"><div class="notif-icon blue">📉</div><div style="flex:1;min-width:0;"><div class="notif-name"><?= htmlspecialchars($_r['nomProduit']) ?> <?= htmlspecialchars($_r['volume']) ?></div><div class="notif-sub" style="color:var(--accent);"><?= (int)$_r['fardeaux'] ?> fardeaux restants</div></div></div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="notif-footer"><a href="../views/produits.php">Gérer le stock →</a></div>
            </div>
        </div>

        <!-- User info -->
        <div class="user-info" style="display:flex;align-items:center;gap:10px;">
            <div class="avatar"><?= isset($_SESSION['user']) ? strtoupper(substr($_SESSION['user'],0,1)) : 'A' ?></div>
            <div>
                <div class="user-name" style="font-weight:600;font-size:14px;"><?= htmlspecialchars($_SESSION['user'] ?? 'Admin') ?></div>
                <div class="user-role" style="font-size:11px;color:var(--muted);"><?= ($_SESSION['role'] ?? '') === 'admin' ? 'Administrateur' : 'Responsable' ?></div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleNotif(e){
    e.stopPropagation();
    document.getElementById('notifDropdown').classList.toggle('open');
}
document.addEventListener('click', function(e){
    const dd=document.getElementById('notifDropdown');
    if(dd && !dd.closest('.notif-wrap').contains(e.target)) dd.classList.remove('open');
});
</script>
