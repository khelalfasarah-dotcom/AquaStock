<?php
// ══════════════════════════════════════════════════════════
//  TWILIO CREDENTIALS — keep this file OUTSIDE the web root
//  or add it to .gitignore. Never commit real secrets.
// ══════════════════════════════════════════════════════════

define('TWILIO_SID',        'AC9edeae548d9e0aefa94b3276be7db396');
define('TWILIO_TOKEN',      '94190ac465e3553dd853997b6520feb6');

// Verify Service SID (starts with VA...)
define('VERIFY_SERVICE_ID', 'VA4a7fef91e9fe593d452cebde7ce89dd2');
