<?php
$isLocal = (isset($_SERVER['HTTP_HOST']) && (
    $_SERVER['HTTP_HOST'] === 'localhost' ||
    str_contains($_SERVER['HTTP_HOST'], '127.0.0.1')
));

if ($isLocal) {
    $host     = "localhost";
    $user     = "root";
    $password = "";
    $database = "gestion_stock_eau";
} else {
    $host     = "sql312.infinityfree.com";
    $user     = "if0_41933943";
    $password = "ilhemo123";
    $database = "if0_41933943_ilhemo1";
}

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("<div style='font-family:sans-serif;padding:20px;background:#fee;color:#c00;border-radius:8px;'>
        <strong>Erreur de connexion :</strong> " . $conn->connect_error . "
    </div>");
}

$conn->set_charset("utf8mb4");
?>
