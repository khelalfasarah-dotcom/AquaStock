<?php
include "config/db.php";

$pass = password_hash("123456", PASSWORD_DEFAULT);

$conn->query("INSERT INTO users(username,password) VALUES('admin','$pass')");

echo "Utilisateur créé";
?>