<?php
$lifetime = 8 * 60 * 60;

ini_set('session.gc_maxlifetime',  $lifetime);
ini_set('session.cookie_lifetime', $lifetime);
ini_set('session.gc_probability',  1);
ini_set('session.gc_divisor',      100);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => $lifetime,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Refresh cookie expiry on every page load
if (isset($_SESSION['user']) || isset($_SESSION['client_id'])) {
    setcookie(session_name(), session_id(), [
        'expires'  => time() + $lifetime,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}
