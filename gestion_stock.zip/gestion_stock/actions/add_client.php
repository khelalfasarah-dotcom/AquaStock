<?php
include "../config/db.php";
require_once "../controllers/ClientController.php";
$ctrl = new ClientController($conn);
if($_SERVER['REQUEST_METHOD']==='POST'){
    $dateNaissance = !empty($_POST['dateNaissance']) ? trim($_POST['dateNaissance']) : null;
    $sexe          = !empty($_POST['sexe'])          ? trim($_POST['sexe'])          : null;
    $email         = !empty($_POST['email'])         ? trim($_POST['email'])         : null;
    $willaya       = !empty($_POST['willaya'])        ? trim($_POST['willaya'])       : null;
    $ctrl->store(
        trim($_POST['nom']??''),
        trim($_POST['adresse']??''),
        trim($_POST['telephone']??''),
        $dateNaissance,
        $sexe,
        $email,
        $willaya
    );
}
header("Location: ../views/clients.php"); exit();
?>