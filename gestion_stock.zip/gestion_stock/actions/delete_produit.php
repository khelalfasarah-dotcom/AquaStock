<?php
include "../config/db.php";
if(isset($_POST['id'])){
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM ligne_produit WHERE idProduit=$id");
    $conn->query("DELETE FROM produit WHERE idProduit=$id");
}
header("Location: ../views/produits.php"); exit();
?>
