<?php
include "../config/db.php";
$id = (int)($_GET['id'] ?? 0);

if(isset($_GET['valider'])){
    $id = (int)$_GET['valider'];
    $stmt = $conn->prepare("UPDATE commande SET etatCommande='validee' WHERE idCommande=?");
    $stmt->bind_param("i", $id); $stmt->execute();
}
if(isset($_GET['annuler'])){
    $id = (int)$_GET['annuler'];
    $stmt = $conn->prepare("UPDATE commande SET etatCommande='annulee' WHERE idCommande=?");
    $stmt->bind_param("i", $id); $stmt->execute();
}
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM commande WHERE idCommande=?");
    $stmt->bind_param("i", $id); $stmt->execute();
}
header("Location: ../views/commandes.php"); exit();
?>
