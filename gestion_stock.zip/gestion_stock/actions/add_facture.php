<?php
include "../config/db.php";
require_once "../controllers/FactureController.php";
$ctrl = new FactureController($conn);
if(isset($_POST['commande_id'])){
    $idCmd = (int)$_POST['commande_id'];
    $ht = (float)($_POST['montantHT'] ?? 0);
    $tva = round($ht * 0.19, 2);
    $timbre = 25.00; $ttc = round($ht + $tva + $timbre, 2);
    $date = date('Y-m-d');
    $ctrl->store($idCmd, $date, $ht, $tva, $timbre, $ttc);
}
header("Location: ../views/factures.php"); exit();
?>
