<?php
include "../config/db.php";
if(isset($_POST['id'])){
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM facture WHERE idFacture=$id");
}
header("Location: ../views/factures.php"); exit();
?>
