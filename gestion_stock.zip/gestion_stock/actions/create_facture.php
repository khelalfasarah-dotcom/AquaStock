<?php
include "../config/db.php";
if(isset($_POST['id'])){
    $id = (int)$_POST['id'];
    $cmds = $conn->query("SELECT idCommande FROM commande WHERE idClient=$id");
    while($c = $cmds->fetch_assoc()){
        $cid = $c['idCommande'];
        $conn->query("DELETE FROM facture WHERE idCommande=$cid");
        $conn->query("DELETE FROM ligne_produit WHERE idCommande=$cid");
    }
    $conn->query("DELETE FROM commande WHERE idClient=$id");
    $conn->query("DELETE FROM client WHERE idClient=$id");
}
header("Location: ../views/clients.php"); exit();
?>
