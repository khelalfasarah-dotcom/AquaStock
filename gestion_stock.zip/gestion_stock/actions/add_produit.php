<?php
include "../config/db.php";
require_once "../controllers/ProduitController.php";
$ctrl = new ProduitController($conn);
if($_SERVER['REQUEST_METHOD']==='POST'){
    $ctrl->store(trim($_POST['nomProduit']??''), trim($_POST['volume']??''), (float)($_POST['prix']??0), (int)($_POST['quantiteStock']??0));
}
header("Location: ../views/produits.php"); exit();
?>
