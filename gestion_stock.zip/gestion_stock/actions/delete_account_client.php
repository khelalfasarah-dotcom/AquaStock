<?php
require_once __DIR__ . '/../config/session.php';
include "../config/db.php";

if (!isset($_SESSION['client_id'])) {
    header("Location: ../auth/login.php"); exit();
}

$idClient = (int)$_SESSION['client_id'];

// Verify password before deleting
if (!isset($_POST['confirm_password_delete'])) {
    header("Location: ../client/profile.php"); exit();
}

$password = trim($_POST['confirm_password_delete']);

// Fetch stored password
$stmt = $conn->prepare("SELECT motdepasse FROM client WHERE idClient = ?");
$stmt->bind_param("i", $idClient);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row || (!password_verify($password, $row['motdepasse']) && $password !== $row['motdepasse'])) {
    $_SESSION['delete_error'] = "Mot de passe incorrect. Suppression annulée.";
    header("Location: ../client/profile.php"); exit();
}

// ── Delete everything in order (respect foreign keys) ──────────────────
$conn->begin_transaction();

try {
    // 1. Delete factures linked to client's commandes
    $conn->query("DELETE f FROM facture f
                  INNER JOIN commande c ON f.idCommande = c.idCommande
                  WHERE c.idClient = $idClient");

    // 2. Delete lignes de commande if table exists
    $conn->query("DELETE lc FROM ligne_commande lc
                  INNER JOIN commande c ON lc.idCommande = c.idCommande
                  WHERE c.idClient = $idClient");

    // 3. Delete commandes
    $conn->query("DELETE FROM commande WHERE idClient = $idClient");

    // 4. Delete panier/cart items if table exists
    $conn->query("DELETE FROM panier WHERE idClient = $idClient");
    $conn->query("DELETE FROM cart WHERE idClient = $idClient");

    // 5. Delete client
    $stmt = $conn->prepare("DELETE FROM client WHERE idClient = ?");
    $stmt->bind_param("i", $idClient);
    $stmt->execute();
    $stmt->close();

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['delete_error'] = "Erreur lors de la suppression. Réessayez.";
    header("Location: ../client/profile.php"); exit();
}

// Clear only client session data, not the entire session
// (avoids logging out an admin who may be browsing at the same time)
unset($_SESSION['client_id']);
unset($_SESSION['client_name']);
unset($_SESSION['cart']);
unset($_SESSION['pending_order']);
unset($_SESSION['active_order_id']);
unset($_SESSION['payment_type']);
unset($_SESSION['role']);
session_regenerate_id(true);
header("Location: ../auth/login.php?deleted=1"); exit();
?>
