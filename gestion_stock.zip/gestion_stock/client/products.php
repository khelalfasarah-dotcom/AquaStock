<?php
session_start();
include "../config/db.php";

$msg = "";

if(isset($_POST['register'])){

    $nom = $_POST['nom'];
    $adresse = $_POST['adresse'];
    $telephone = $_POST['telephone'];

    $stmt = $conn->prepare("INSERT INTO client(nom,adresse,telephone) VALUES(?,?,?)");
    $stmt->bind_param("sss",$nom,$adresse,$telephone);

    if($stmt->execute()){

        $_SESSION['client'] = [
            "nom"=>$nom,
            "telephone"=>$telephone
        ];

        $_SESSION['role']="client";

        header("Location: home.php");
        exit();

    } else {
        $msg = "❌ Error";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
<?php include "../assets/style.css"; ?>

body{
    font-family:Poppins;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:url('../assets/img/wt.jpg') center/cover;
}

.box{
    background:rgba(15,23,42,0.8);
    padding:30px;
    border-radius:20px;
    width:350px;
    color:white;
    backdrop-filter:blur(10px);
    animation:fadeUp .8s;
}

@keyframes fadeUp{
    from{opacity:0;transform:translateY(20px);}
    to{opacity:1;transform:translateY(0);}
}

input,button{
    width:100%;
    padding:10px;
    margin:8px 0;
    border-radius:10px;
    border:none;
}

button{
    background:#22c55e;
    color:white;
    cursor:pointer;
}

button:hover{
    background:#00f2fe;
    color:black;
}

h2{color:#00f2fe;}
</style>
</head>
<body>

<div class="box">
<h2>👤 Client Register</h2>

<form method="POST">
<input name="nom" placeholder="Name">
<input name="adresse" placeholder="Address">
<input name="telephone" placeholder="Phone">
<button name="register">Register</button>
</form>

<?php if($msg) echo $msg; ?>

</div>

</body>
</html>