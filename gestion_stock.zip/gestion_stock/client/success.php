<?php
session_start();
$orderID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$orderID){ header("Location: home.php"); exit(); }
?>
<!DOCTYPE html>
<html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Order Confirmed | AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
<style>
:root{--accent:#00b4d8;--bg:#050d1a;--green:#22d3a0;}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Outfit',sans-serif;}
body{background:var(--bg);min-height:100vh;display:flex;align-items:center;justify-content:center;color:white;}
.box{background:rgba(8,20,40,0.85);border:1px solid rgba(0,180,216,0.2);border-radius:20px;padding:60px 50px;text-align:center;max-width:500px;animation:up .6s ease;}
@keyframes up{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
.check{width:80px;height:80px;background:var(--green);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 24px;font-size:36px;box-shadow:0 0 30px rgba(34,211,160,0.4);}
h1{font-size:28px;font-weight:700;margin-bottom:12px;}
p{color:#94a3b8;margin-bottom:24px;line-height:1.6;}
.ref{display:inline-block;background:rgba(0,180,216,0.1);border:1px solid rgba(0,180,216,0.3);padding:6px 16px;border-radius:20px;color:var(--accent);font-weight:700;}
.next-btn{display:inline-block;margin-top:28px;padding:14px 36px;background:var(--accent);color:#050d1a;border-radius:10px;text-decoration:none;font-weight:700;font-size:15px;transition:.2s;}
.next-btn:hover{background:#48cae4;transform:translateY(-2px);box-shadow:0 0 25px rgba(0,180,216,0.4);}
</style>
</head>
<body>
<div class="box">
    <div class="check">✓</div>
    <h1>Order Confirmed! 🎉</h1>
    <p>Your order has been successfully placed and is now being processed.</p>
    <div class="ref">Order #<?= $orderID ?></div>
    <br>
    <a href="payment_methods.php?id=<?= $orderID ?>" class="next-btn">Select Payment Method →</a>
</div>
</body></html>
