<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['client_name']) || !isset($_SESSION['client_id'])) {
    header("Location: ../auth/login_client.php"); exit();
}
if (empty($_SESSION['pending_order'])) {
    header("Location: payment.php"); exit();
}

$method  = trim($_POST['method'] ?? $_SESSION['payment_type'] ?? 'cash');
$pending = $_SESSION['pending_order'];
$cart    = $pending['cart'];

// Map method to DB value
$methodMap = [
    'cash'     => 'especes',
    'ccp'      => 'ccp',
    'card'     => 'carte',
    'dahabia'  => 'carte',
    'especes'  => 'especes',
    'carte'    => 'carte',
    'cheque'   => 'cheque',
    'virement' => 'virement',
];
$dbMethod = $methodMap[$method] ?? 'especes';

// Collect payment details from POST
$pay_name      = trim($_POST['pay_name']      ?? '');
$pay_num       = trim($_POST['pay_num']       ?? '');
$pay_ref       = trim($_POST['pay_ref']       ?? '');
$pay_date      = trim($_POST['pay_date']      ?? '');
$pay_amount    = isset($_POST['pay_amount']) && $_POST['pay_amount'] !== '' ? (float)$_POST['pay_amount'] : null;
$pay_card_type = trim($_POST['pay_card_type'] ?? '');
$pay_expiry    = trim($_POST['pay_expiry']    ?? '');

$idClient = (int)$_SESSION['client_id'];
$date     = date('Y-m-d');

// Get a valid responsable
$respRow = $conn->query("SELECT idResponsable FROM responsable LIMIT 1")->fetch_assoc();
$idResponsable = $respRow ? (int)$respRow['idResponsable'] : null;
if (!$idResponsable) {
    $_SESSION['error_message'] = "Erreur configuration : aucun responsable trouvé.";
    header("Location: payment.php?error=failed"); exit();
}

// Ensure modePaiement enum accepts ccp and carte (safe: MySQL ignores if already present)
@$conn->query("ALTER TABLE paiement MODIFY COLUMN modePaiement ENUM('espece','especes','cheque','virement','ccp','carte') DEFAULT NULL");

// Ensure extra paiement columns exist
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_name VARCHAR(255) DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_num  VARCHAR(100) DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_ref  VARCHAR(100) DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_date DATE         DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_amount DECIMAL(12,2) DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_card_type VARCHAR(50) DEFAULT NULL");
$conn->query("ALTER TABLE paiement ADD COLUMN IF NOT EXISTS pay_expiry VARCHAR(10)  DEFAULT NULL");

// Ensure etatCommande supports en_attente status
@$conn->query("ALTER TABLE commande MODIFY COLUMN etatCommande ENUM('en_cours','validee','en_attente','annulee','livree') DEFAULT 'en_cours'");

// Ensure optional columns exist
$conn->query("ALTER TABLE facture ADD COLUMN IF NOT EXISTS modePaiement VARCHAR(50) DEFAULT NULL");
$conn->query("ALTER TABLE commande ADD COLUMN IF NOT EXISTS modePaiement VARCHAR(50) DEFAULT NULL");

$conn->begin_transaction();
try {
    // 1. Create order — only NOW
    // Dahabia is always auto-validated (payment is instant/electronic)
    $isDahabia = (strtolower($pay_card_type) === 'edahabia');
    // cash starts en_cours (admin validates on delivery)
    // ccp starts en_cours UNLESS it's Dahabia (electronic = instant)
    // card/cheque/virement are auto-validated
    $newStatus = ($method === 'cash' || ($method === 'ccp' && !$isDahabia)) ? 'en_cours' : 'validee';
    $stmt = $conn->prepare("INSERT INTO commande (dateCommande, etatCommande, modePaiement, idClient, idResponsable) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) throw new Exception("Prepare commande failed: " . $conn->error);
    $stmt->bind_param("sssii", $date, $newStatus, $dbMethod, $idClient, $idResponsable);
    $stmt->execute();
    $idCommande = $conn->insert_id;
    if (!$idCommande) throw new Exception("Échec création commande.");

    // 2. Order lines + stock deduction
    $totalTTC = 0;
    foreach ($cart as $item) {
        $idProd         = (int)$item['id'];
        $qty_fardeaux   = (int)$item['qty_fardeaux'];
        $bpf            = (int)$item['bpf'];
        $prix_fardeau   = (float)$item['prix_fardeau'];
        $qty_bouteilles = $qty_fardeaux * $bpf;
        $subTotal       = $qty_fardeaux * $prix_fardeau;
        $totalTTC      += $subTotal;

        $l = $conn->prepare("INSERT INTO ligne_produit (quantite, sousTotal, idCommande, idProduit) VALUES (?,?,?,?)");
        if (!$l) throw new Exception("Prepare ligne failed: " . $conn->error);
        $l->bind_param("idii", $qty_fardeaux, $subTotal, $idCommande, $idProd);
        $l->execute();

        $upd = $conn->prepare("UPDATE produit SET quantiteStock = quantiteStock - ? WHERE idProduit = ?");
        $upd->bind_param("ii", $qty_bouteilles, $idProd);
        $upd->execute();
    }

    // 3. Create invoice
    $timbre      = 25.00;
    $totalHT     = round(($totalTTC - $timbre) / 1.19, 2);
    $tva         = round($totalTTC - $timbre - $totalHT, 2);
    // Dahabia and all card payments -> facture immediately confirmee
    $etatFacture = ($newStatus === 'validee') ? 'confirmee' : 'en_attente';
    $conn->query("ALTER TABLE facture ADD COLUMN IF NOT EXISTS etatFacture ENUM('en_attente','confirmee','annulee') NOT NULL DEFAULT 'en_attente'");
    $f = $conn->prepare("INSERT INTO facture (dateFacture, montantTotal, tva, timbre, montantTC, idCommande, modePaiement, etatFacture) VALUES (?,?,?,?,?,?,?,?)");
    if (!$f) throw new Exception("Prepare facture failed: " . $conn->error);
    $f->bind_param("sddddiss", $date, $totalHT, $tva, $timbre, $totalTTC, $idCommande, $dbMethod, $etatFacture);
    $f->execute();
    $idFacture = $conn->insert_id;

    // 4. Create paiement record
    $enumMethods = ['espece', 'especes', 'cheque', 'virement', 'ccp', 'carte'];
    $dbMethodEnum = ($dbMethod === 'especes') ? 'espece' : $dbMethod;
    if (in_array($dbMethodEnum, $enumMethods)) {
        $payDateVal = $pay_date ?: $date;
        $ins = $conn->prepare("INSERT INTO paiement (montant, modePaiement, idFacture, pay_name, pay_num, pay_ref, pay_date, pay_amount, pay_card_type, pay_expiry) VALUES (?,?,?,?,?,?,?,?,?,?)");
        if (!$ins) throw new Exception("Prepare paiement failed: " . $conn->error);
        $ins->bind_param("dsissssdss", $totalTTC, $dbMethodEnum, $idFacture, $pay_name, $pay_num, $pay_ref, $payDateVal, $pay_amount, $pay_card_type, $pay_expiry);
        $ins->execute();
    }

    $conn->commit();

    // Clear cart and pending order ONLY after full success
    $_SESSION['cart'] = [];
    unset($_SESSION['pending_order']);
    unset($_SESSION['payment_type']);
    $_SESSION['active_order_id'] = $idCommande;

    header("Location: thank_you.php?id=" . $idCommande); exit();

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error_message'] = "Erreur lors de la confirmation : " . $e->getMessage();
    header("Location: payment.php?error=failed"); exit();
}
?>
