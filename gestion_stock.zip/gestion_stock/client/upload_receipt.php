<?php
session_start();
$orderID = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'card';

$config = [
    'card' => ['color' => '#00f2fe', 'icon' => '💳', 'title' => 'Edahabia Gateway', 'btn' => 'Valider le Paiement'],
    'ccp'  => ['color' => '#fbbf24', 'icon' => '🏦', 'title' => 'Poste Algérie CCP', 'btn' => 'Envoyer le Talon'],
    'cash' => ['color' => '#22c55e', 'icon' => '🚚', 'title' => 'Paiement à la Livraison', 'btn' => 'Confirmer la Commande']
];
$ui = $config[$type] ?? $config['card'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Finalisation Commande #<?= $orderID ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        /* All your existing styles stay exactly the same */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins'; }
        body { 
            background: #0f172a; color: white; 
            display: flex; justify-content: center; align-items: center; 
            min-height: 100vh; overflow-x: hidden;
            background-image: radial-gradient(circle at 2px 2px, rgba(255,255,255,0.03) 1px, transparent 0);
            background-size: 30px 30px;
        }
        .container { width: 100%; max-width: 480px; padding: 20px; animation: fadeIn 0.8s ease; }
        .back {
            display: inline-flex; align-items: center; gap: 8px;
            margin-bottom: 20px; padding: 10px 20px;
            border: 1px solid <?= $ui['color'] ?>; color: <?= $ui['color'] ?>;
            border-radius: 12px; text-decoration: none; font-size: 0.85rem;
            transition: 0.3s; background: rgba(0,0,0,0.2);
        }
        .back:hover { transform: translateX(-5px); box-shadow: 0 0 20px <?= $ui['color'] ?>66; background: <?= $ui['color'] ?>11; }
        .card { 
            background: rgba(30,41,59,0.7); padding: 40px; border-radius: 30px; 
            border: 1px solid rgba(255,255,255,0.05); border-bottom: 4px solid <?= $ui['color'] ?>;
            backdrop-filter: blur(20px); text-align: center;
            box-shadow: 0 25px 50px rgba(0,0,0,0.4);
        }
        .icon-circle {
            width: 80px; height: 80px; background: <?= $ui['color'] ?>15;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 40px; margin: 0 auto 20px; color: <?= $ui['color'] ?>;
            border: 1px solid <?= $ui['color'] ?>33;
        }
        .input-group { text-align: left; margin-top: 20px; }
        .input-group label { display: block; font-size: 0.75rem; color: #94a3b8; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        .input-group input { 
            width: 100%; background: rgba(0,0,0,0.2); border: 1px solid #334155; 
            border-radius: 10px; padding: 12px; color: white; outline: none; transition: 0.3s;
        }
        .input-group input:focus { border-color: <?= $ui['color'] ?>; box-shadow: 0 0 10px <?= $ui['color'] ?>33; }
        .upload-box {
            border: 2px dashed #334155; padding: 30px; border-radius: 15px;
            margin: 20px 0; cursor: pointer; transition: 0.3s; position: relative;
        }
        .upload-box:hover { border-color: <?= $ui['color'] ?>; background: rgba(255,255,255,0.02); }
        .upload-box input { position: absolute; inset: 0; opacity: 0; cursor: pointer; }
        .btn-confirm {
            background: <?= $ui['color'] ?>; color: #0f172a; width: 100%;
            padding: 16px; border: none; border-radius: 12px;
            font-weight: 700; font-size: 1rem; cursor: pointer;
            transition: 0.3s; margin-top: 10px;
        }
        .btn-confirm:hover { transform: translateY(-3px); box-shadow: 0 10px 20px <?= $ui['color'] ?>44; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } }
    </style>
</head>
<body>

<div class="container">
    <a href="payment_methods.php?id=<?= $orderID ?>" class="back">← Retour</a>

    <div class="card">
        <div class="icon-circle"><?= $ui['icon'] ?></div>
        <h2 style="letter-spacing: 1px;"><?= $ui['title'] ?></h2>
        <p style="color: #64748b; font-size: 0.85rem; margin-top: 5px;">Commande en attente: #ORD-<?= $orderID ?></p>

        <!-- FORM ACTION FIXED TO thank.php -->
        <form action="thank.php?id=<?= $orderID ?>&status=validat" method="POST" enctype="multipart/form-data" id="paymentForm">
            
            <?php if($type == 'card'): ?>
                <div class="input-group">
                    <label>Numéro de Carte (Edahabia/CIB)</label>
                    <input type="text" placeholder="6035 9200 0000 0000" required>
                </div>
                <div style="display:flex; gap:15px;" class="input-group">
                    <div style="flex:1">
                        <label>Expiration</label>
                        <input type="text" placeholder="MM/YY" required>
                    </div>
                    <div style="flex:1">
                        <label>CVV</label>
                        <input type="password" placeholder="***" required>
                    </div>
                </div>

            <?php elseif($type == 'ccp'): ?>
                <div style="margin-top:20px; text-align:left; font-size:0.8rem; color:#94a3b8;">
                    Compte: <b style="color:white;">0021456789 / 44</b><br>
                    Veuillez joindre une copie du talon de versement :
                </div>
                <div class="upload-box">
                    <span id="fn" style="color:#64748b;">📎 Joindre le reçu</span>
                    <input type="file" name="proof" id="fi" required>
                </div>

            <?php else: ?>
                <div style="background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.2); padding:15px; border-radius:12px; margin:20px 0; color:#94a3b8; font-size:0.85rem; text-align:left;">
                    <b style="color:#22c55e;">Validation Manuelle:</b><br>
                    Le montant sera encaissé par notre agent de livraison. Aucun prépaiement requis.
                </div>
            <?php endif; ?>

            <button type="submit" class="btn-confirm" id="submitBtn">
                <span id="btnText"><?= $ui['btn'] ?></span>
            </button>
        </form>
    </div>
</div>

<script>
    // File upload label update
    if(document.getElementById('fi')) {
        document.getElementById('fi').onchange = function() {
            document.getElementById('fn').innerText = "Fichier: " + this.files[0].name;
            document.getElementById('fn').style.color = "<?= $ui['color'] ?>";
        };
    }

    // Professional Loading Logic to prevent 404 feel
    document.getElementById('paymentForm').onsubmit = function() {
        const btn = document.getElementById('submitBtn');
        const txt = document.getElementById('btnText');
        
        btn.disabled = true;
        btn.style.opacity = "0.7";
        txt.innerHTML = "Traitement en cours... ⏳";
    };
</script>

</body>
</html>