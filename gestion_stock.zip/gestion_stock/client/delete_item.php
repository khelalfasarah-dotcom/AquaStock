<?php
session_start();

/* Check cart exists */
if (!isset($_SESSION['cart'])) {
    header("Location: payment.php");
    exit();
}

/* Check index from URL */
if (isset($_GET['index'])) {

    $index = $_GET['index'];

    /* Delete item safely */
    if (isset($_SESSION['cart'][$index])) {
        unset($_SESSION['cart'][$index]);
    }

    /* Reindex array (important) */
    $_SESSION['cart'] = array_values($_SESSION['cart']);
}

/* Return to payment page */
header("Location: payment.php");
exit();
?>