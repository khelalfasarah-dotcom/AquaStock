<?php
session_start();
$orderID = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'payment';

if ($orderID == 0) {
    header("Location: payment_methods.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Proof of Payment</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #0f172a; color: white; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .upload-card {
            background: rgba(30, 41, 59, 0.7); padding: 40px; border-radius: 25px;
            border: 1px solid #fbbf24; width: 90%; max-width: 500px; text-align: center;
            backdrop-filter: blur(15px);
        }
        .instruction-box {
            background: rgba(251, 191, 36, 0.1); border-left: 4px solid #fbbf24;
            padding: 15px; margin: 20px 0; text-align: left; font-size: 0.9rem;
        }
        .btn-submit {
            background: #fbbf24; color: #0f172a; width: 100%; padding: 15px;
            border: none; border-radius: 12px; font-weight: bold; cursor: pointer; transition: 0.3s;
        }
        .btn-submit:hover { transform: scale(1.02); background: #fcd34d; }
    </style>
</head>
<body>
    <div class="upload-card">
        <h2 style="color: #fbbf24;">Finalize Your Payment</h2>
        <p style="color: #94a3b8; margin-top: 10px;">Please upload your payment screenshot or confirmation document.</p>

        <div class="instruction-box">
            <p><strong>Order ID:</strong> #ORD-<?= $orderID ?></p>
            <p><strong>Method:</strong> <?= strtoupper($type) ?></p>
            <p style="margin-top:5px; font-size:0.8rem; color:#fcd34d;">* This proof is required to validate your order in our system.</p>
        </div>

        <form action="thank.php?id=<?= $orderID ?>" method="POST" enctype="multipart/form-data">
            <input type="file" name="receipt_img" accept="image/*" required 
                   style="display:block; width:100%; padding:20px; border:1px dashed #94a3b8; margin-bottom:20px; border-radius:10px; color:#94a3b8;">
            <button type="submit" class="btn-submit">Confirm & Show Receipt</button>
        </form>
    </div>
</body>
</html>