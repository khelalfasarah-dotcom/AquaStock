<?php
session_start();

if (isset($_POST['add_to_cart'])) {
    $id           = $_POST['id'];
    $name         = $_POST['name'];
    $prix_fardeau = (float)$_POST['prix_fardeau'];
    $bpf          = (int)$_POST['bpf'];           // bouteilles par fardeau
    $qty_fardeaux = max(1, (int)$_POST['qty_fardeaux']);

    if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }

    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]['qty_fardeaux'] += $qty_fardeaux;
    } else {
        $_SESSION['cart'][$id] = [
            "id"           => $id,
            "product_name" => $name,
            "prix_fardeau" => $prix_fardeau,   // prix d'un fardeau
            "bpf"          => $bpf,             // bouteilles par fardeau
            "qty_fardeaux" => $qty_fardeaux,    // quantité en fardeaux
        ];
    }
}

header("Location: payment.php");
exit();
?>
