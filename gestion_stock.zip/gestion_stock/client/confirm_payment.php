<?php
session_start();
if (!isset($_SESSION['client_name'])) { header("Location: ../auth/login_client.php"); exit(); }
if (empty($_SESSION['pending_order']))  { header("Location: payment.php"); exit(); }

$type = $_GET['type'] ?? 'cash';
$_SESSION['payment_type'] = $type;

include "../config/db.php";

$pending = $_SESSION['pending_order'];
$ttc    = number_format($pending['ttc'], 2);
$ht     = number_format($pending['totalHT'], 2);
$tva    = number_format($pending['tva'], 2);
$timbre = number_format($pending['timbre'], 2);

$clientRes = $conn->prepare("SELECT nom, telephone, adresse FROM client WHERE idClient=?");
$cid = (int)$_SESSION['client_id']; $clientRes->bind_param("i", $cid); $clientRes->execute();
$order = $clientRes->get_result()->fetch_assoc();
$orderID = 0;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Paiement — NAQAA</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --yellow:  #fbbf24;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
}
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5);
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0; transition:width 0.1s linear;
}
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 50% at 50% 0%, rgba(0,119,168,0.2) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 90% 80%, rgba(0,212,245,0.06) 0%, transparent 50%),
    radial-gradient(ellipse 30% 30% at 10% 70%, rgba(0,255,204,0.04) 0%, transparent 50%);
}
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}
body::before {
  content:''; position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.35;
}
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background:radial-gradient(circle at 30% 30%, var(--accent), rgba(0,119,168,0.3));
  animation:rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
@keyframes rise {
  0%   { transform:translateY(100vh) scale(0.2); opacity:0; }
  10%  { opacity:0.4; }
  90%  { opacity:0.08; }
  100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
}

/* ─── NAV ─── */
nav {
  position:sticky; top:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px; height:70px;
  background:rgba(2,11,20,0.85);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  transition:background 0.3s;
}
.nav-brand {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text);
  text-decoration:none;
}
.nav-brand-icon {
  width:42px; height:42px; border-radius:10px;
  display:flex; align-items:center; justify-content:center;
  box-shadow:0 0 20px rgba(0,212,245,0.3);
  overflow:hidden;
}
.nav-back {
  display:flex; align-items:center; gap:7px;
  padding:9px 18px; border:1px solid var(--border); border-radius:9px;
  color:var(--muted); text-decoration:none; font-size:12px; font-weight:500;
  background:var(--surface); transition:all .25s;
}
.nav-back:hover { color:var(--accent); border-color:var(--border2); background:var(--surface2); }

/* ─── PAGE LAYOUT ─── */
.page {
  position:relative; z-index:10;
  max-width:1100px; margin:44px auto;
  padding:0 32px;
  display:grid;
  grid-template-columns:1fr 360px;
  gap:28px;
  align-items:start;
}
@media(max-width:860px) { .page { grid-template-columns:1fr; } }

.section-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:14px;
  display:flex; align-items:center; gap:8px;
}
.section-label::before { content:''; width:24px; height:1px; background:var(--accent); }

.panel {
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:18px;
  overflow:hidden;
  animation:fadeUp .6s cubic-bezier(.22,1,.36,1) both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

.panel-head {
  padding:28px 32px 22px;
  border-bottom:1px solid var(--border);
  display:flex; align-items:center; gap:14px;
}
.panel-icon {
  width:48px; height:48px; border-radius:13px;
  background:rgba(0,212,245,0.1); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;
}
.panel-icon.gold { background:rgba(251,191,36,0.1); border-color:rgba(251,191,36,0.3); }
.panel-icon.green { background:rgba(0,255,204,0.08); border-color:rgba(0,255,204,0.25); }
.panel-title { font-family:'Bebas Neue',sans-serif; font-size:26px; letter-spacing:0.5px; line-height:1; }
.panel-sub { font-size:12px; color:var(--muted); margin-top:3px; font-weight:300; }
.panel-body { padding:28px 32px; }

.method-badge {
  display:inline-flex; align-items:center; gap:8px;
  background:rgba(0,212,245,0.06); border:1px solid var(--border2);
  color:var(--accent); padding:7px 18px; border-radius:100px;
  font-size:12px; font-weight:700; letter-spacing:0.5px; margin-bottom:26px;
}
.method-badge.gold { background:rgba(251,191,36,0.06); border-color:rgba(251,191,36,0.3); color:var(--yellow); }

/* ─── CCP ACCOUNT CARD ─── */
.ccp-account-card {
  background:linear-gradient(135deg, rgba(0,119,168,0.25), rgba(0,212,245,0.1));
  border:1.5px solid var(--accent2);
  border-radius:16px; padding:28px 28px 24px;
  margin-bottom:28px;
  position:relative; overflow:hidden;
}
.ccp-account-card::before {
  content:''; position:absolute; top:-30px; right:-30px;
  width:120px; height:120px;
  background:rgba(0,212,245,0.07); border-radius:50%;
}
.ccp-account-card::after {
  content:''; position:absolute; bottom:-40px; left:20px;
  width:160px; height:160px;
  background:rgba(0,119,168,0.05); border-radius:50%;
}
.ccp-card-header {
  display:flex; align-items:center; gap:12px; margin-bottom:22px;
  position:relative; z-index:1;
}
.ccp-card-header .post-logo {
  width:44px; height:44px; border-radius:10px;
  background:linear-gradient(135deg, #e8c000, #f5a800);
  display:flex; align-items:center; justify-content:center;
  font-size:22px; box-shadow:0 4px 14px rgba(245,168,0,0.3);
}
.ccp-card-header .bank-name {
  font-family:'Bebas Neue',sans-serif; font-size:18px; letter-spacing:1px; color:var(--text);
}
.ccp-card-header .bank-sub { font-size:11px; color:var(--muted2); margin-top:1px; }

.ccp-num-block {
  position:relative; z-index:1;
  background:rgba(0,0,0,0.3); border:1px solid rgba(0,212,245,0.2);
  border-radius:12px; padding:18px 20px; margin-bottom:18px;
  display:flex; align-items:center; justify-content:space-between;
}
.ccp-num-label {
  font-size:9px; text-transform:uppercase; letter-spacing:2px;
  color:var(--muted); font-weight:700; margin-bottom:6px;
}
.ccp-num-value {
  font-family:'Bebas Neue',sans-serif; font-size:28px; letter-spacing:4px;
  color:var(--accent); display:flex; align-items:baseline; gap:8px;
}
.ccp-num-value .ccp-key {
  font-size:14px; color:var(--muted2); letter-spacing:1px;
  font-family:'Outfit',sans-serif; font-weight:600;
}
.copy-btn {
  background:rgba(0,212,245,0.1); border:1px solid var(--border2);
  color:var(--accent); padding:8px 14px; border-radius:8px;
  font-size:12px; font-weight:700; cursor:pointer; transition:all .2s;
  font-family:'Outfit',sans-serif; white-space:nowrap; flex-shrink:0;
}
.copy-btn:hover { background:rgba(0,212,245,0.18); transform:translateY(-1px); }
.copy-btn.copied { background:rgba(0,255,204,0.12); border-color:var(--green); color:var(--green); }

.ccp-info-grid {
  display:grid; grid-template-columns:1fr 1fr; gap:14px;
  position:relative; z-index:1;
}
.ccp-info-item { }
.ccp-info-item .ci-label {
  font-size:9px; text-transform:uppercase; letter-spacing:1.5px;
  color:var(--muted); font-weight:700; margin-bottom:4px;
}
.ccp-info-item .ci-val {
  font-size:13px; color:var(--text); font-weight:600;
}

/* ─── AMOUNT TO SEND ─── */
.amount-send-box {
  background:rgba(0,255,204,0.05); border:1.5px solid rgba(0,255,204,0.2);
  border-radius:13px; padding:18px 22px; margin-bottom:24px;
  display:flex; align-items:center; justify-content:space-between;
  flex-wrap:wrap; gap:12px;
}
.amount-send-box .asl { font-size:12px; color:var(--muted2); font-weight:500; }
.amount-send-box .asv {
  font-family:'Bebas Neue',sans-serif; font-size:32px;
  color:var(--green); letter-spacing:1px;
}
.amount-send-box .asv small {
  font-family:'Outfit',sans-serif; font-size:12px;
  color:var(--muted); font-weight:400; margin-left:4px;
}

/* ─── STEPS LIST ─── */
.steps-list { list-style:none; margin-bottom:26px; }
.steps-list li {
  display:flex; gap:14px; align-items:flex-start;
  padding:11px 0; border-bottom:1px solid rgba(0,212,245,0.06);
  font-size:13px; color:var(--muted2); line-height:1.6;
}
.steps-list li:last-child { border:none; }
.step-num {
  width:26px; height:26px; border-radius:50%; flex-shrink:0;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; display:flex; align-items:center; justify-content:center;
  font-size:11px; font-weight:800; margin-top:1px;
}
.steps-list li strong { color:var(--text); }

/* ─── INFO BOX ─── */
.info-box {
  background:rgba(0,212,245,0.04); border:1px solid var(--border);
  border-radius:13px; padding:20px 22px; margin-bottom:24px;
}
.info-box .box-label {
  font-size:9px; text-transform:uppercase; letter-spacing:1.5px;
  color:var(--accent); font-weight:700; margin-bottom:14px;
}
.info-box p { font-size:13px; color:var(--muted2); margin-bottom:6px; line-height:1.6; }
.info-box p:last-child { margin:0; }
.info-box span { font-weight:700; color:var(--text); }

/* ─── FORM FIELDS ─── */
.field { margin-bottom:18px; }
.field label {
  display:block; font-size:10px; font-weight:700;
  text-transform:uppercase; letter-spacing:1.5px;
  color:var(--muted); margin-bottom:9px;
}
.field input, .field select {
  width:100%; padding:14px 16px; border-radius:11px;
  border:1.5px solid var(--border);
  background:rgba(0,0,0,0.3); color:var(--text);
  font-size:14px; font-family:'Outfit',sans-serif;
  outline:none; transition:all .25s;
}
.field input:focus, .field select:focus {
  border-color:var(--accent);
  background:rgba(0,212,245,0.04);
  box-shadow:0 0 0 4px rgba(0,212,245,0.08), 0 0 20px rgba(0,212,245,0.08);
}
.field input::placeholder { color:rgba(90,128,152,0.45); }
.field-hint { font-size:11px; margin-top:5px; min-height:16px; transition:color .2s; }
.row2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }

/* ─── NOTE ─── */
.note {
  background:rgba(0,212,245,0.04);
  border-left:3px solid var(--accent);
  border-radius:0 10px 10px 0;
  padding:13px 16px; font-size:12px;
  color:var(--muted2); margin-bottom:22px; line-height:1.7;
}
.note strong { color:var(--accent); }
.note.yellow { border-left-color:var(--yellow); background:rgba(251,191,36,0.04); }
.note.yellow strong { color:var(--yellow); }
.note.green { border-left-color:var(--green); background:rgba(0,255,204,0.04); }
.note.green strong { color:var(--green); }

/* ─── CASH ─── */
.cash-hero { text-align:center; padding:30px 0 36px; }
.cash-hero .big { font-size:72px; display:block; margin-bottom:18px; }
.cash-hero p { color:var(--muted2); font-size:14px; line-height:1.85; font-weight:300; }
.cash-amount {
  display:inline-flex; align-items:center; gap:10px;
  margin-top:22px; padding:12px 28px;
  background:rgba(0,212,245,0.06); border:1px solid var(--border2); border-radius:100px;
  font-family:'Bebas Neue',sans-serif; font-size:28px; color:var(--accent); letter-spacing:1px;
}
.cash-amount small { font-family:'Outfit',sans-serif; font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:1px; }

.divider { border:none; border-top:1px solid var(--border); margin:24px 0; }

/* ─── CARD VISUAL ─── */
.card-visual {
  background:linear-gradient(135deg, var(--accent2), #0891b2, var(--accent));
  border-radius:14px; padding:24px 26px; margin-bottom:24px;
  position:relative; overflow:hidden;
}
.card-visual::before {
  content:''; position:absolute; top:-40px; right:-40px;
  width:140px; height:140px; background:rgba(255,255,255,0.08); border-radius:50%;
}
.card-visual::after {
  content:''; position:absolute; bottom:-50px; right:10px;
  width:180px; height:180px; background:rgba(255,255,255,0.05); border-radius:50%;
}
.card-chip { font-size:26px; margin-bottom:16px; position:relative; z-index:1; }
.card-num-display {
  font-size:18px; letter-spacing:5px; font-weight:600; margin-bottom:18px;
  font-family:monospace; color:rgba(255,255,255,0.9); position:relative; z-index:1;
}
.card-foot {
  display:flex; justify-content:space-between; font-size:10px;
  color:rgba(255,255,255,0.6); text-transform:uppercase; letter-spacing:0.5px;
  position:relative; z-index:1;
}
.card-foot span { display:block; font-size:14px; font-weight:600; color:white; margin-top:3px; }

/* ─── SUBMIT BUTTON ─── */
.btn-submit {
  width:100%; padding:15px; border:none; border-radius:11px; margin-top:6px;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; font-family:'Bebas Neue',sans-serif;
  font-size:20px; letter-spacing:2px;
  cursor:pointer; transition:all .25s;
  position:relative; overflow:hidden;
  box-shadow:0 0 24px rgba(0,212,245,0.2);
}
.btn-submit::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
  opacity:0; transition:opacity .25s;
}
.btn-submit:hover { transform:translateY(-2px); box-shadow:0 0 40px rgba(0,212,245,0.4); }
.btn-submit:hover::before { opacity:1; }
.btn-submit:active { transform:translateY(0); }
.btn-submit.gold-btn {
  background:linear-gradient(135deg, var(--yellow), #f59e0b);
  box-shadow:0 0 24px rgba(251,191,36,0.15);
}
.btn-submit.gold-btn:hover { box-shadow:0 0 40px rgba(251,191,36,0.35); }

/* ─── SIDEBAR ─── */
.sidebar-card {
  background:var(--surface); border:1px solid var(--border);
  border-radius:18px; overflow:hidden;
  animation:fadeUp .6s cubic-bezier(.22,1,.36,1) both .1s;
  position:sticky; top:90px;
}
.sidebar-head { padding:22px 26px 18px; border-bottom:1px solid var(--border); }
.sidebar-head .sh-label {
  font-size:9px; text-transform:uppercase; letter-spacing:2px;
  color:var(--accent); font-weight:700; margin-bottom:8px;
}
.sidebar-head .sh-title { font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:0.5px; }
.client-block { padding:18px 26px 16px; border-bottom:1px solid var(--border); }
.client-row { font-size:12px; color:var(--muted2); margin-bottom:5px; display:flex; gap:8px; }
.client-row:last-child { margin:0; }
.client-row .cr-label { color:var(--muted); min-width:60px; flex-shrink:0; }
.client-row .cr-val { color:var(--text); font-weight:500; }
.summary-rows { padding:16px 26px; }
.summary-row {
  display:flex; justify-content:space-between; align-items:center;
  padding:9px 0; border-bottom:1px solid rgba(0,212,245,0.05); font-size:13px;
}
.summary-row:last-of-type { border:none; }
.summary-row .lbl { color:var(--muted); }
.summary-row.total {
  padding-top:14px; margin-top:4px;
  border-top:1px solid var(--border); border-bottom:none;
}
.summary-row.total .lbl { color:var(--text); font-weight:600; font-size:14px; }
.summary-row.total .val {
  font-family:'Bebas Neue',sans-serif; font-size:24px; color:var(--accent); letter-spacing:0.5px;
}
.order-num-row {
  display:flex; justify-content:space-between; align-items:center;
  padding:9px 0; font-size:13px; border-bottom:1px solid rgba(0,212,245,0.05);
}
.order-num-row .lbl { color:var(--muted); }
.order-num-badge {
  padding:3px 10px; border-radius:100px;
  background:rgba(0,212,245,0.06); border:1px solid var(--border);
  font-size:11px; color:var(--muted); font-weight:600;
}

/* ─── STEPS INDICATOR ─── */
.steps {
  display:flex; align-items:center; justify-content:center;
  gap:0; margin-bottom:36px; animation:fadeUp .5s ease both;
}
.step-item { display:flex; align-items:center; gap:0; }
.step-dot {
  width:32px; height:32px; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  font-size:12px; font-weight:700; flex-shrink:0;
  border:1.5px solid var(--border); color:var(--muted);
  background:var(--surface); transition:all .3s;
}
.step-dot.done { background:rgba(0,212,245,0.12); border-color:var(--accent); color:var(--accent); }
.step-dot.active {
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  border-color:var(--accent); color:#020b14;
  box-shadow:0 0 20px rgba(0,212,245,0.35);
}
.step-label { font-size:10px; color:var(--muted); font-weight:500; white-space:nowrap; margin-left:6px; letter-spacing:0.3px; }
.step-label.active { color:var(--accent); }
.step-line { width:32px; height:1px; background:linear-gradient(90deg, var(--accent), var(--border)); margin:0 4px; flex-shrink:0; opacity:0.4; }

@media(max-width:768px) {
  nav { padding:0 20px; }
  .page { padding:0 16px; margin:24px auto; }
  .panel-body { padding:22px 20px; }
  .panel-head { padding:20px 20px 16px; }
  .row2 { grid-template-columns:1fr; }
  .steps { display:none; }
  .ccp-info-grid { grid-template-columns:1fr; }
  .ccp-num-block { flex-direction:column; align-items:flex-start; gap:12px; }
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="particles" id="particles"></div>

<!-- ─── NAV ─── -->
<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">
      <svg width="42" height="42" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
        <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="#1a7bbf"/>
        <path d="M60,8 C90,40 98,65 98,80 C98,100 81,114 60,114 C39,114 22,100 22,80 C22,65 30,40 60,8 Z" fill="url(#dropGradNav)" opacity="0.55"/>
        <path d="M42,30 C46,45 47,65 45,80 C43,90 38,98 33,94 C28,88 28,70 34,52 C38,40 40,33 42,30 Z" fill="white" opacity="0.18"/>
        <text x="60" y="88" text-anchor="middle" font-family="Georgia,serif" font-size="48" font-weight="700" fill="white">N</text>
        <defs>
          <radialGradient id="dropGradNav" cx="60%" cy="35%" r="55%" fx="60%" fy="35%">
            <stop offset="0%" stop-color="#00d4f5" stop-opacity="0.7"/>
            <stop offset="100%" stop-color="#0077a8" stop-opacity="0"/>
          </radialGradient>
        </defs>
      </svg>
    </div>
    NAQAA
  </a>
  <a href="payment_methods.php" class="nav-back">← Changer de mode</a>
</nav>

<div class="page">

  <!-- ═══════════ LEFT : PAYMENT FORM ═══════════ -->
  <div>

    <!-- Progress Steps -->
    <div class="steps">
      <div class="step-item">
        <div class="step-dot done">✓</div>
        <span class="step-label">Panier</span>
      </div>
      <div class="step-line"></div>
      <div class="step-item">
        <div class="step-dot done">✓</div>
        <span class="step-label">Mode</span>
      </div>
      <div class="step-line"></div>
      <div class="step-item">
        <div class="step-dot active">3</div>
        <span class="step-label active">Paiement</span>
      </div>
      <div class="step-line"></div>
      <div class="step-item">
        <div class="step-dot">4</div>
        <span class="step-label">Confirmation</span>
      </div>
    </div>

<?php if($type === 'cash'): ?>
<!-- ══════════════════════════════════
     CASH ON DELIVERY
══════════════════════════════════ -->
<div class="panel">
  <div class="panel-head">
    <div class="panel-icon gold">💵</div>
    <div>
      <div class="panel-title">Espèces à la livraison</div>
      <div class="panel-sub">Aucun paiement requis maintenant — règlement à la réception</div>
    </div>
  </div>
  <div class="panel-body">
    <div class="method-badge gold">💵 Cash on Delivery</div>
    <div class="cash-hero">
      <span class="big">🚚</span>
      <p>Aucun paiement n'est requis à cette étape.<br>Notre agent de livraison collectera le montant<br>directement à votre adresse à la réception.</p>
      <div class="cash-amount">
        <small>À préparer</small>
        <?= $ttc ?> DZD
      </div>
    </div>
    <div class="note yellow">
      💡 Veuillez préparer le <strong>montant exact de <?= $ttc ?> DZD</strong>. Notre agent ne dispose pas toujours de monnaie.
    </div>
    <form action="final_confirm.php" method="POST">
      <input type="hidden" name="id" value="<?= $orderID ?>">
      <input type="hidden" name="method" value="cash">
      <button type="submit" class="btn-submit gold-btn">✅ Confirmer la commande</button>
    </form>
  </div>
</div>

<?php elseif($type === 'ccp'): ?>
<!-- ══════════════════════════════════
     CCP / BARIDIMOB
══════════════════════════════════ -->
<div class="panel">
  <div class="panel-head">
    <div class="panel-icon">📮</div>
    <div>
      <div class="panel-title">CCP / Baridimob</div>
      <div class="panel-sub">Virement postal — Algérie Poste</div>
    </div>
  </div>
  <div class="panel-body">
    <div class="method-badge">📮 CCP / Baridimob</div>

    <!-- ★ MONTANT À ENVOYER — visible immédiatement ★ -->
    <div class="amount-send-box">
      <div>
        <div class="asl">💸 Montant exact à virer maintenant</div>
        <div style="font-size:11px;color:var(--muted);margin-top:3px;">Incluant TVA + timbre fiscal</div>
      </div>
      <div class="asv"><?= $ttc ?><small>DZD</small></div>
    </div>

    <!-- ★ COMPTE DESTINATAIRE NAQAA ★ -->
    <div class="ccp-account-card">
      <div class="ccp-card-header">
        <div class="post-logo">📮</div>
        <div>
          <div class="bank-name">Compte ABDESSELAMI ILHEM — Algérie Poste</div>
          <div class="bank-sub">Virez directement sur ce compte</div>
        </div>
      </div>

      <div class="ccp-num-block">
        <div>
          <div class="ccp-num-label">Numéro CCP</div>
          <div class="ccp-num-value" id="ccpNumDisplay">
            6280703133327350
          </div>
        </div>
        <button class="copy-btn" id="copyBtn" onclick="copyCCP()">📋 Copier</button>
      </div>

      <div class="ccp-info-grid">
        <div class="ccp-info-item">
          <div class="ci-label">Titulaire</div>
          <div class="ci-val">ABDESSELAMI ILHEM</div>
        </div>
        <div class="ccp-info-item">
          <div class="ci-label">Banque</div>
          <div class="ci-val">Algérie Poste</div>
        </div>
        <div class="ccp-info-item">
          <div class="ci-label">RIP Baridimob</div>
          <div class="ci-val" style="font-size:11px;">6280703133327350</div>
        </div>
        <div class="ccp-info-item">
          <div class="ci-label">Référence objet</div>
          <div class="ci-val">Commande NAQAA</div>
        </div>
      </div>
    </div>

    <!-- Étapes à suivre -->
    <div class="section-label">Comment procéder</div>
    <ul class="steps-list">
      <li>
        <div class="step-num">1</div>
        <div>Ouvrez votre application <strong>Baridimob</strong> ou rendez-vous dans un bureau de poste.</div>
      </li>
      <li>
        <div class="step-num">2</div>
        <div>Effectuez un virement de <strong><?= $ttc ?> DZD</strong> vers le CCP <strong>6280703133327350 </strong>.</div>
      </li>
      <li>
        <div class="step-num">3</div>
        <div>Notez le <strong>numéro de reçu / référence</strong> fourni par l'application ou le guichet.</div>
      </li>
      <li>
        <div class="step-num">4</div>
        <div>Remplissez le formulaire ci-dessous et soumettez — nous confirmons votre commande sous <strong>1 à 2h</strong>.</div>
      </li>
    </ul>

    <hr class="divider">

    <!-- Formulaire de confirmation -->
    <div class="section-label" style="margin-bottom:18px;">Confirmer votre virement</div>
    <form action="final_confirm.php" method="POST" onsubmit="return validateCcpForm()">
      <input type="hidden" name="id" value="<?= $orderID ?>">
      <input type="hidden" name="method" value="ccp">
      <input type="hidden" id="h_ccp_num" name="pay_num" value="">

      <div class="field">
        <label>Votre nom complet <span style="color:var(--red)">*</span></label>
        <input type="text" id="ccpNameInput" name="pay_name"
          placeholder="Prénom NOM tel qu'enregistré sur votre compte CCP"
          autocomplete="name" required oninput="validateCcpName(this)">
        <div class="field-hint" id="ccpNameHint"></div>
      </div>

      <div class="field">
        <label>Votre numéro CCP <span style="color:var(--red)">*</span></label>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <input type="text" id="ccpPart1" maxlength="5" placeholder="00411"
            style="width:90px;text-align:center;letter-spacing:2px;"
            oninput="fmtCcp(this,5,'ccpPart2')" autocomplete="off">
          <span style="color:var(--muted);font-size:14px;">&mdash;</span>
          <input type="text" id="ccpPart2" maxlength="7" placeholder="2345678"
            style="width:120px;text-align:center;letter-spacing:2px;"
            oninput="fmtCcp(this,7,'ccpKey')" autocomplete="off">
          <span style="color:var(--muted);font-size:13px;">Clé</span>
          <input type="text" id="ccpKey" maxlength="2" placeholder="12"
            style="width:58px;text-align:center;letter-spacing:2px;"
            oninput="this.value=this.value.replace(/\D/g,'');buildCcp();" autocomplete="off">
        </div>
        <div class="field-hint" id="ccpNumHint" style="margin-top:6px;">
          Format : 5 chiffres &middot; 7 chiffres &middot; Clé 2 chiffres
        </div>
      </div>

      <div class="row2">
        <div class="field">
          <label>Référence / N° de reçu <span style="color:var(--red)">*</span></label>
          <input type="text" id="ccpRefInput" name="pay_ref"
            placeholder="ex : TRF-20250503-001" required oninput="valCcpRef(this)">
          <div class="field-hint" id="ccpRefHint"></div>
        </div>
        <div class="field">
          <label>Date du virement <span style="color:var(--red)">*</span></label>
          <input type="date" name="pay_date" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>" required>
        </div>
      </div>

      <div class="field">
        <label>Montant envoyé (DZD) <span style="color:var(--red)">*</span></label>
        <input type="number" id="ccpAmtInput" name="pay_amount" step="0.01"
          value="<?= $pending['ttc'] ?>" min="1" required
          oninput="valCcpAmt(this,<?= $pending['ttc'] ?>)">
        <div class="field-hint" id="ccpAmtHint"></div>
      </div>

      <div class="note green">
        ✅ Après soumission, notre équipe vérifiera votre virement sous <strong>1 à 2 heures ouvrables</strong> et confirmera votre commande par SMS.
      </div>

      <button type="submit" class="btn-submit">📨 Soumettre le paiement & Confirmer</button>
    </form>
  </div>
</div>

<?php elseif($type === 'card'): ?>
<!-- ══════════════════════════════════
     EDAHABIA / BANK CARD
══════════════════════════════════ -->
<div class="panel">
  <div class="panel-head">
    <div class="panel-icon">💳</div>
    <div>
      <div class="panel-title">Paiement par carte</div>
      <div class="panel-sub">Edahabia, CIB, Visa ou Mastercard</div>
    </div>
  </div>
  <div class="panel-body">
    <div class="method-badge">💳 Edahabia / Carte bancaire</div>

    <div class="card-visual" id="cardVisual">
      <div class="card-chip" id="cardTypeLogo">💳</div>
      <div class="card-num-display" id="cardNumDisplay">•••• •••• •••• ••••</div>
      <div class="card-foot">
        <div>
          <div>Titulaire</div>
          <span id="cardNameDisplay">VOTRE NOM</span>
        </div>
        <div>
          <div>Expire</div>
          <span id="cardExpDisplay">MM/AA</span>
        </div>
      </div>
    </div>

    <form action="final_confirm.php" method="POST" onsubmit="return validateCardForm()">
      <input type="hidden" name="id" value="<?= $orderID ?>">
      <input type="hidden" name="method" value="card">
      <input type="hidden" id="h_card_num_masked" name="pay_num" value="">

      <div class="field">
        <label>Type de carte</label>
        <select id="cardTypeSelect" name="pay_card_type" onchange="updateCardType()">
          <option value="Edahabia">🟡 Edahabia (Algérie Poste)</option>
          <option value="CIB">🔵 CIB (Banque)</option>
          <option value="Visa">💙 Visa</option>
          <option value="Mastercard">🔴 Mastercard</option>
        </select>
      </div>
      <div class="field">
        <label>Nom du titulaire <span style="color:var(--red)">*</span></label>
        <input type="text" id="cardNameInput" name="pay_name"
          placeholder="Prénom NOM tel qu'imprimé sur la carte" required autocomplete="cc-name"
          oninput="document.getElementById('cardNameDisplay').textContent=this.value.toUpperCase()||'VOTRE NOM';valCardName(this)">
        <div class="field-hint" id="cardNameHint"></div>
      </div>
      <div class="field">
        <label>Numéro de carte <span style="color:var(--red)">*</span>
          <span style="font-size:10px;color:var(--muted);margin-left:6px;">(Edahabia : 18 chiffres &bull; CIB / Visa / MC : 16 chiffres)</span>
        </label>
        <input type="text" id="cardNumInput" maxlength="22"
          placeholder="XXXX XXXX XXXX XXXX" required
          oninput="formatCardNum(this)" autocomplete="cc-number">
        <div class="field-hint" id="cardNumHint"></div>
      </div>
      <div class="row2">
        <div class="field">
          <label>Date d'expiration</label>
          <input type="text" id="cardExpInput" name="pay_expiry" maxlength="5"
            placeholder="MM/AA" required autocomplete="cc-exp"
            oninput="let v=this.value.replace(/\D/g,'');if(v.length>=3)v=v.slice(0,2)+'/'+v.slice(2);this.value=v;document.getElementById('cardExpDisplay').textContent=this.value||'MM/AA';">
        </div>
        <div class="field">
          <label>CVV / CVC</label>
          <input type="password" name="pay_cvv" maxlength="3"
            placeholder="•••" required autocomplete="cc-csc">
        </div>
      </div>
      <div class="note">
        🔒 Vos données de carte sont utilisées à des fins de <strong>vérification d'identité uniquement</strong>. Aucun débit en ligne n'est effectué.
      </div>
      <button type="submit" class="btn-submit">✅ Confirmer la commande</button>
    </form>
  </div>
</div>

<?php endif; ?>

  </div><!-- /left -->

  <!-- ═══════════ RIGHT : SIDEBAR ═══════════ -->
  <div>
    <div class="sidebar-card">
      <div class="sidebar-head">
        <div class="sh-label">Récapitulatif</div>
        <div class="sh-title">Votre commande</div>
      </div>
      <div class="client-block">
        <div class="client-row">
          <span class="cr-label">Client</span>
          <span class="cr-val"><?= htmlspecialchars($order['nom'] ?? '—') ?></span>
        </div>
        <div class="client-row">
          <span class="cr-label">Téléphone</span>
          <span class="cr-val"><?= htmlspecialchars($order['telephone'] ?? '—') ?></span>
        </div>
        <div class="client-row">
          <span class="cr-label">Adresse</span>
          <span class="cr-val"><?= htmlspecialchars($order['adresse'] ?? '—') ?></span>
        </div>
      </div>
      <div class="summary-rows">
        <div class="order-num-row">
          <span class="lbl">Commande #</span>
          <span class="order-num-badge">En cours…</span>
        </div>
        <div class="summary-row">
          <span class="lbl">Sous-total HT</span>
          <span><?= $ht ?> DZD</span>
        </div>
        <div class="summary-row">
          <span class="lbl">TVA (19%)</span>
          <span><?= $tva ?> DZD</span>
        </div>
        <div class="summary-row">
          <span class="lbl">Timbre fiscal</span>
          <span><?= $timbre ?> DZD</span>
        </div>
        <div class="summary-row total">
          <span class="lbl">Total TTC</span>
          <span class="val"><?= $ttc ?> DZD</span>
        </div>
      </div>
    </div>
  </div>

</div><!-- /page -->

<script>
// ── COPY CCP NUMBER ──
function copyCCP() {
  navigator.clipboard.writeText('6280703133327350').then(() => {
    var btn = document.getElementById('copyBtn');
    btn.textContent = '✅ Copié !';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = '📋 Copier'; btn.classList.remove('copied'); }, 2500);
  });
}

// ── CARD JS ──
const typeLogos = {Edahabia:'🟡',CIB:'🔵',Visa:'💙',Mastercard:'🔴'};
function updateCardType(){
  var t=document.getElementById('cardTypeSelect').value;
  document.getElementById('cardTypeLogo').textContent=typeLogos[t]||'💳';
  var el=document.getElementById('cardNumInput');
  el.value='';
  document.getElementById('cardNumDisplay').textContent='•••• •••• •••• ••••';
  document.getElementById('h_card_num_masked').value='';
  var h=document.getElementById('cardNumHint');if(h)h.textContent='';
  var maxD=(t==='Edahabia')?18:16;
  el.maxLength=(maxD===18)?22:19;
  el.placeholder=(t==='Edahabia')?'XXXX XXXX XXXX XXXX XX (18 chiffres)':'XXXX XXXX XXXX XXXX';
}
function formatCardNum(el){
  var ctype=document.getElementById('cardTypeSelect')?document.getElementById('cardTypeSelect').value:'Edahabia';
  var maxD=(ctype==='Edahabia')?18:16;
  var v=el.value.replace(/\D/g,'').substring(0,maxD);
  el.value=v.replace(/(.{4})/g,'$1 ').trim();
  var masked=v?'•••• •••• •••• '+v.slice(-4).padStart(4,'•'):'•••• •••• •••• ••••';
  document.getElementById('cardNumDisplay').textContent=masked;
  document.getElementById('h_card_num_masked').value='**** **** **** '+v.slice(-4);
  var h=document.getElementById('cardNumHint');
  if(h){if(v.length===maxD){if(/^(\d)\1+$/.test(v)){h.textContent='⚠️ Numéro invalide';h.style.color='var(--red)';}else{h.textContent='✅ '+maxD+' chiffres saisis';h.style.color='var(--green)';}}else{h.textContent=v.length+' / '+maxD+' chiffres';h.style.color='var(--muted)';}}
}
function valCardName(el){
  var v=el.value.trim(),h=document.getElementById('cardNameHint');
  if(v.length<2){h.textContent='';return;}
  if(v.split(/\s+/).filter(Boolean).length<2){h.textContent='⚠️ Saisissez Prénom + Nom';h.style.color='var(--yellow)';return;}
  h.textContent='✅ Nom valide';h.style.color='var(--green)';
}
function validateCardForm(){
  var ctype=document.getElementById('cardTypeSelect').value;
  var name=document.getElementById('cardNameInput').value.trim();
  var num=document.getElementById('cardNumInput').value.replace(/\s/g,'');
  var exp=document.getElementById('cardExpInput').value.trim();
  var cvv=document.querySelector('[name="pay_cvv"]').value.trim();
  var expLen=(ctype==='Edahabia')?18:16;
  if(name.split(/\s+/).filter(Boolean).length<2){alert('Saisissez le nom complet (Prénom + Nom).');return false;}
  if(num.length!==expLen){alert('Numéro de carte invalide.\nActuellement : '+num.length+' chiffres.');return false;}
  if(/^(\d)\1+$/.test(num)){alert('Numéro de carte invalide.');return false;}
  if(ctype!=='Edahabia'){var s=0,odd=false;for(var i=num.length-1;i>=0;i--){var d=parseInt(num[i]);if(odd){d*=2;if(d>9)d-=9;}s+=d;odd=!odd;}if(s%10!==0){alert('Numéro de carte invalide.');return false;}}
  if(exp.length<5){alert('Saisissez la date d\'expiration MM/AA.');return false;}
  var mm=parseInt(exp.split('/')[0]),yy=2000+parseInt(exp.split('/')[1]);
  var now=new Date();
  if(mm<1||mm>12){alert('Mois invalide.');return false;}
  if(yy<now.getFullYear()||(yy===now.getFullYear()&&mm<now.getMonth()+1)){alert('Carte expirée.');return false;}
  if(cvv.length<3){alert('CVV invalide (3 chiffres requis).');return false;}
  return true;
}

// ── CCP JS ──
function fmtCcp(el,max,nextId){
  el.value=el.value.replace(/\D/g,'');
  if(el.value.length>=max)document.getElementById(nextId)&&document.getElementById(nextId).focus();
  buildCcp();
}
function buildCcp(){
  var p1=(document.getElementById('ccpPart1')||{value:''}).value;
  var p2=(document.getElementById('ccpPart2')||{value:''}).value;
  var k=(document.getElementById('ccpKey')||{value:''}).value;
  var h=document.getElementById('ccpNumHint');
  if(!h)return;
  if(p1.length===5&&p2.length===7&&k.length>=1){
    var fmt=p1+' '+p2+' Clé '+k;
    document.getElementById('h_ccp_num').value=fmt;
    h.textContent='✅ '+fmt;h.style.color='var(--green)';
  }else{
    document.getElementById('h_ccp_num').value='';
    h.textContent='Format : 5 chiffres · 7 chiffres · Clé 2 chiffres';
    h.style.color='var(--muted)';
  }
}
function validateCcpName(el){
  var v=el.value.trim(),h=document.getElementById('ccpNameHint');
  if(!h||v.length<3){if(h)h.textContent='';return;}
  if(v.split(/\s+/).filter(Boolean).length<2){h.textContent='⚠️ Saisissez Nom + Prénom';h.style.color='var(--yellow)';return;}
  h.textContent='✅ Nom valide';h.style.color='var(--green)';
}
function valCcpRef(el){
  var v=el.value.trim(),h=document.getElementById('ccpRefHint');
  if(!h||v.length<4){if(h)h.textContent='';return;}
  if(v.length<6){h.textContent='⚠️ Référence trop courte';h.style.color='var(--yellow)';return;}
  h.textContent='✅ Référence enregistrée';h.style.color='var(--green)';
}
function valCcpAmt(el,expected){
  var v=parseFloat(el.value),h=document.getElementById('ccpAmtHint');
  if(!h||isNaN(v)){if(h)h.textContent='';return;}
  if(v<expected*0.99){h.textContent='⚠️ Minimum '+expected.toFixed(2)+' DZD';h.style.color='var(--red)';return;}
  h.textContent='✅ Montant correct';h.style.color='var(--green)';
}
function validateCcpForm(){
  var name=document.getElementById('ccpNameInput').value.trim();
  var p1=document.getElementById('ccpPart1').value.trim();
  var p2=document.getElementById('ccpPart2').value.trim();
  var k=document.getElementById('ccpKey').value.trim();
  var ref=document.getElementById('ccpRefInput').value.trim();
  var ccpNum=document.getElementById('h_ccp_num').value;
  if(name.split(/\s+/).filter(Boolean).length<2){alert('Saisissez votre nom complet (Prénom + Nom).');return false;}
  if(p1.length!==5||p2.length!==7||k.length<1){alert('Numéro CCP invalide. Format: 5 chiffres, 7 chiffres et la clé.');return false;}
  if(!ccpNum){alert('Numéro CCP invalide — vérifiez vos saisies.');return false;}
  if(ref.length<6){alert('Référence de reçu trop courte (minimum 6 caractères).');return false;}
  return true;
}

// ── SCROLL PROGRESS ──
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40 ? 'rgba(2,11,20,0.97)' : 'rgba(2,11,20,0.85)';
}, { passive:true });

// ── PARTICLES ──
const c = document.getElementById('particles');
for(let i=0;i<28;i++){
  const d = document.createElement('div'); d.className = 'drop';
  const s = 1.5 + Math.random()*4;
  d.style.cssText = `left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*15}s;`;
  c.appendChild(d);
}

document.querySelectorAll('input,select').forEach(inp => {
  inp.addEventListener('input', () => {
    inp.style.borderColor = inp.value ? 'rgba(0,212,245,0.5)' : '';
  });
});
</script>
</body>
</html>