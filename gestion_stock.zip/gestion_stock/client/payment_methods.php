<?php
session_start();
if (!isset($_SESSION['client_name'])) { header("Location: ../auth/login_client.php"); exit(); }
if (empty($_SESSION['pending_order'])) { header("Location: payment.php"); exit(); }

$ttc = number_format($_SESSION['pending_order']['ttc'], 2);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Mode de Paiement — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --yellow:  #fbbf24;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  padding:60px 20px;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5);
}
::-webkit-scrollbar-thumb:hover {
  background:linear-gradient(to bottom, var(--accent), var(--accent3));
  box-shadow:0 0 14px rgba(0,212,245,0.8);
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

/* ─── SCROLL LINE ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0;
  transition:width 0.1s linear;
}

/* ─── AMBIENT ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 60% at 50% 0%, rgba(0,119,168,0.22) 0%, transparent 60%),
    radial-gradient(ellipse 50% 50% at 90% 90%, rgba(0,212,245,0.06) 0%, transparent 50%);
}
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}
body::before {
  content:''; position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.35;
}

/* ─── PARTICLES ─── */
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background:radial-gradient(circle at 30% 30%, var(--accent), rgba(0,119,168,0.3));
  animation:rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
@keyframes rise {
  0%   { transform:translateY(100vh) scale(0.2); opacity:0; }
  10%  { opacity:0.4; }
  90%  { opacity:0.08; }
  100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
}

/* ─── CONTENT ─── */
.content { position:relative; z-index:10; width:100%; max-width:880px; }

/* ─── HEADER ─── */
.header { text-align:center; margin-bottom:52px; animation:fadeUp .7s ease both; }
.header-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:16px;
  display:flex; align-items:center; justify-content:center; gap:8px;
}
.header-label::before,.header-label::after { content:''; width:24px; height:1px; background:var(--accent); }
.header h1 {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(42px,6vw,72px); letter-spacing:1px; line-height:0.95;
  margin-bottom:12px;
}
.header h1 span { color:var(--accent); }
.header p { font-size:14px; color:var(--muted2); font-weight:300; margin-bottom:24px; }

.ttc-badge {
  display:inline-flex; align-items:center; gap:10px;
  padding:12px 28px;
  background:rgba(0,212,245,0.06);
  border:1px solid var(--border2); border-radius:100px;
  font-family:'Bebas Neue',sans-serif; font-size:26px; letter-spacing:1px;
  color:var(--accent);
  box-shadow:0 0 30px rgba(0,212,245,0.1);
}
.ttc-badge small { font-family:'Outfit',sans-serif; font-size:11px; color:var(--muted); letter-spacing:1px; text-transform:uppercase; }

/* ─── GRID ─── */
.pay-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit, minmax(250px,1fr));
  gap:18px;
  margin-bottom:36px;
}

/* ─── PAY CARD ─── */
.pay-card {
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:18px; padding:36px 24px;
  text-align:center; cursor:pointer;
  transition:all .35s; position:relative; overflow:hidden;
  animation:fadeUp .6s cubic-bezier(.22,1,.36,1) both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

.pay-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:2px;
  background:linear-gradient(90deg, var(--accent), var(--accent3));
  transform:scaleX(0); transform-origin:left; transition:transform .4s;
}
.pay-card:hover::before { transform:scaleX(1); }
.pay-card:hover {
  border-color:var(--border2);
  background:var(--surface2);
  transform:translateY(-6px);
  box-shadow:0 24px 50px rgba(0,0,0,0.4), 0 0 30px rgba(0,212,245,0.08);
}
.pay-card.cash-card:hover {
  border-color:rgba(251,191,36,0.35);
  box-shadow:0 24px 50px rgba(0,0,0,0.4), 0 0 30px rgba(251,191,36,0.08);
}
.pay-card.cash-card::before {
  background:linear-gradient(90deg, var(--yellow), #f59e0b);
}

.pay-icon {
  font-size:52px; display:block; margin-bottom:18px;
  filter:drop-shadow(0 0 12px rgba(0,212,245,0.3));
  transition:transform .3s;
}
.pay-card:hover .pay-icon { transform:scale(1.1); }

.pay-card h3 {
  font-family:'Bebas Neue',sans-serif;
  font-size:22px; letter-spacing:0.5px; margin-bottom:10px;
}
.pay-card p {
  color:var(--muted); font-size:12px; line-height:1.7;
  margin-bottom:20px; font-weight:300;
}

.confirm-tag {
  display:inline-flex; align-items:center; gap:5px;
  padding:4px 14px; border-radius:100px;
  font-size:10px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase;
  margin-bottom:20px;
}
.confirm-tag.instant { background:rgba(0,255,204,0.08); color:var(--green); border:1px solid rgba(0,255,204,0.2); }
.confirm-tag.manual  { background:rgba(251,191,36,0.08); color:var(--yellow); border:1px solid rgba(251,191,36,0.2); }

.select-btn {
  width:100%; padding:12px 20px; border:none; border-radius:10px;
  font-family:'Bebas Neue',sans-serif; font-size:18px; letter-spacing:1.5px;
  cursor:pointer; transition:all .25s; position:relative; overflow:hidden;
}
.select-btn.cyan {
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14;
  box-shadow:0 0 20px rgba(0,212,245,0.15);
}
.select-btn.cyan:hover { box-shadow:0 0 35px rgba(0,212,245,0.35); transform:translateY(-1px); }
.select-btn.gold {
  background:linear-gradient(135deg, var(--yellow), #f59e0b);
  color:#020b14;
  box-shadow:0 0 20px rgba(251,191,36,0.15);
}
.select-btn.gold:hover { box-shadow:0 0 35px rgba(251,191,36,0.35); transform:translateY(-1px); }

/* ─── BACK LINK ─── */
.back-link {
  display:inline-flex; align-items:center; gap:8px;
  padding:10px 20px; border:1px solid var(--border); border-radius:9px;
  color:var(--muted); font-size:13px; text-decoration:none;
  background:var(--surface); transition:all .25s;
}
.back-link:hover { color:var(--accent); border-color:var(--border2); background:var(--surface2); }
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="particles" id="particles"></div>

<div class="content">

  <div class="header">
    <div class="header-label">Étape finale</div>
    <h1>Mode de <span>Paiement</span></h1>
    <p>Sélectionnez votre mode de règlement pour finaliser la commande</p>
    <div class="ttc-badge">
      <small>Total TTC</small>
      <?= $ttc ?> DZD
    </div>
  </div>

  <div class="pay-grid">

    <div class="pay-card" style="animation-delay:.05s" onclick="location.href='process_payment.php?type=card'">
      <span class="pay-icon">💳</span>
      <h3>Carte Bancaire</h3>
      <p>Edahabia, CIB ou carte Visa/Mastercard. Paiement sécurisé en ligne.</p>
      <div class="confirm-tag instant">✅ Confirmation instantanée</div>
      <button class="select-btn cyan">Payer par carte</button>
    </div>

    <div class="pay-card" style="animation-delay:.12s" onclick="location.href='process_payment.php?type=ccp'">
      <span class="pay-icon">📮</span>
      <h3>CCP / Baridimob</h3>
      <p>Virement via Algérie Poste. Envoyez le talon de versement après confirmation.</p>
      <div class="confirm-tag instant">✅ Confirmation instantanée</div>
      <button class="select-btn cyan">Payer par CCP</button>
    </div>

    <div class="pay-card cash-card" style="animation-delay:.19s" onclick="location.href='process_payment.php?type=cash'">
      <span class="pay-icon">💵</span>
      <h3>Espèces à la livraison</h3>
      <p>Payez en cash à la réception de votre commande. La validation est effectuée par l'équipe.</p>
      <div class="confirm-tag manual">⏳ En attente de validation</div>
      <button class="select-btn gold">Payer en espèces</button>
    </div>

  </div>

  <div style="text-align:center;">
    <a href="payment.php" class="back-link">← Retour au panier</a>
  </div>

</div>

<script>
// Scroll progress
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

// Particles
const c = document.getElementById('particles');
for(let i=0;i<25;i++){
  const d=document.createElement('div'); d.className='drop';
  const s=1.5+Math.random()*4;
  d.style.cssText=`left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*15}s;`;
  c.appendChild(d);
}
</script>
</body>
</html>