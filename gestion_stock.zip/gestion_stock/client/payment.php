<?php
session_start();
if (!isset($_SESSION['client_name'])) { header("Location: ../auth/login_client.php"); exit(); }
if (!isset($_SESSION['client_id'])) {
    session_destroy();
    header("Location: ../auth/login_client.php?error=session_expired"); exit();
}

$cart = $_SESSION['cart'] ?? [];
$ttc = 0;
foreach ($cart as $item) { $ttc += $item['qty_fardeaux'] * $item['prix_fardeau']; }
$timbre  = 25.00;
$totalHT = round(($ttc - $timbre) / 1.19, 2);
$tva     = round($ttc - $timbre - $totalHT, 2);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Panier — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5);
}
::-webkit-scrollbar-thumb:hover {
  background:linear-gradient(to bottom, var(--accent), var(--accent3));
  box-shadow:0 0 14px rgba(0,212,245,0.8);
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

/* ─── SCROLL LINE ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0;
  transition:width 0.1s linear;
}

/* ─── AMBIENT ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 50% at 50% 0%, rgba(0,119,168,0.2) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 90% 80%, rgba(0,212,245,0.06) 0%, transparent 50%);
}
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}
body::before {
  content:''; position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.35;
}

/* ─── NAV ─── */
nav {
  position:sticky; top:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px; height:70px;
  background:rgba(2,11,20,0.85);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  transition:background 0.3s;
}
.nav-brand {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text);
  text-decoration:none;
}
.nav-brand-icon {
  width:38px; height:38px; border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center; font-size:18px;
  box-shadow:0 0 20px rgba(0,212,245,0.4);
}
.nav-right { display:flex; align-items:center; gap:10px; }
.welcome { font-size:13px; color:var(--muted2); margin-right:6px; }
.welcome strong { color:var(--text); font-weight:600; }
.nav-btn {
  display:flex; align-items:center; gap:7px;
  padding:9px 16px; border-radius:9px; text-decoration:none;
  font-weight:600; font-size:12px; transition:all .25s;
  border:1px solid var(--border); color:var(--muted2);
  background:var(--surface);
}
.nav-btn:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-1px); }
.nav-btn.active { border-color:rgba(0,212,245,0.3); color:var(--accent); background:rgba(0,212,245,0.06); }
.orders-btn { border-color:rgba(0,255,204,0.2); color:var(--green) !important; background:rgba(0,255,204,0.05); }
.orders-btn:hover { background:rgba(0,255,204,0.1) !important; border-color:rgba(0,255,204,0.4) !important; }
.logout-btn:hover { color:var(--red) !important; border-color:rgba(244,63,94,0.3) !important; }

/* ─── MAIN ─── */
main { position:relative; z-index:10; padding:52px 56px; max-width:960px; margin:0 auto; }

/* ─── PAGE HEADER ─── */
.page-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:14px;
  display:flex; align-items:center; gap:8px;
}
.page-label::before { content:''; width:24px; height:1px; background:var(--accent); }
.page-title {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(40px,5vw,62px); letter-spacing:1px; line-height:0.95;
  margin-bottom:12px;
}
.page-title span { color:var(--accent); }
.page-sub { font-size:14px; color:var(--muted2); font-weight:300; margin-bottom:36px; }

/* ─── ERROR BANNER ─── */
.error-banner {
  display:flex; align-items:center; gap:10px;
  background:rgba(244,63,94,0.08); border:1px solid rgba(244,63,94,0.25);
  color:#fca5a5; padding:14px 18px; border-radius:11px; margin-bottom:24px;
  font-size:13px;
}

/* ─── TABLE ─── */
.cart-table {
  width:100%; border-collapse:collapse;
  background:var(--surface); border:1px solid var(--border);
  border-radius:14px; overflow:hidden;
  margin-bottom:20px;
  animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
.cart-table thead th {
  background:rgba(0,212,245,0.06);
  color:var(--muted); font-size:10px; text-transform:uppercase;
  letter-spacing:1.2px; padding:14px 18px; text-align:left;
  font-weight:700; border-bottom:1px solid var(--border);
}
.cart-table td {
  padding:16px 18px; border-bottom:1px solid rgba(0,212,245,0.05);
  font-size:13px; color:var(--muted2);
}
.cart-table tr:last-child td { border:none; }
.cart-table td:first-child { color:var(--text); font-weight:500; }
.cart-table td:nth-child(5) { color:var(--accent); font-weight:700; }
.cart-table tr:hover td { background:rgba(0,212,245,0.03); }

.del-btn {
  display:inline-flex; align-items:center; gap:5px;
  padding:6px 12px; border:1px solid rgba(244,63,94,0.25);
  background:rgba(244,63,94,0.06); color:var(--red);
  border-radius:7px; text-decoration:none; font-size:11px;
  font-weight:600; transition:all .2s;
}
.del-btn:hover { background:var(--red); color:#fff; border-color:var(--red); }

/* ─── SUMMARY ─── */
.summary-box {
  background:var(--surface);
  border:1px solid var(--border); border-radius:14px;
  padding:26px;
  animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both .1s;
}
.summary-row {
  display:flex; justify-content:space-between; align-items:center;
  padding:10px 0; border-bottom:1px solid rgba(0,212,245,0.06);
  font-size:13px;
}
.summary-row:last-of-type { border:none; }
.summary-row .label { color:var(--muted); }
.summary-row .value { color:var(--muted2); font-weight:600; }
.summary-total {
  display:flex; justify-content:space-between; align-items:center;
  padding:18px 0 0; margin-top:4px;
  border-top:1px solid var(--border2);
}
.summary-total .label {
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:1px; color:var(--text);
}
.summary-total .value {
  font-family:'Bebas Neue',sans-serif; font-size:28px; letter-spacing:1px; color:var(--accent);
}

.checkout-btn {
  width:100%; margin-top:20px; padding:16px;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; border:none; border-radius:11px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px;
  cursor:pointer; transition:all .25s; position:relative; overflow:hidden;
  box-shadow:0 0 24px rgba(0,212,245,0.2);
}
.checkout-btn::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
  opacity:0; transition:opacity .25s;
}
.checkout-btn:hover { transform:translateY(-2px); box-shadow:0 0 40px rgba(0,212,245,0.4); }
.checkout-btn:hover::before { opacity:1; }
.checkout-btn:active { transform:translateY(0); }

/* ─── EMPTY ─── */
.empty-box {
  text-align:center; padding:80px 20px;
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
}
.empty-icon { font-size:56px; margin-bottom:16px; opacity:0.4; }
.empty-box p { font-size:15px; color:var(--muted); margin-bottom:24px; }
.shop-btn {
  display:inline-block; padding:13px 28px;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; border-radius:10px; text-decoration:none;
  font-weight:700; font-size:13px;
  box-shadow:0 0 24px rgba(0,212,245,0.2); transition:all .25s;
}
.shop-btn:hover { box-shadow:0 0 40px rgba(0,212,245,0.4); transform:translateY(-2px); }

@media(max-width:768px){
  nav { padding:0 20px; }
  .welcome { display:none; }
  main { padding:32px 20px; }
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>

<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">💧</div>
    AquaStock
  </a>
  <div class="nav-right">
    <div class="welcome">Bonjour, <strong><?= htmlspecialchars($_SESSION['client_name']) ?></strong></div>
    <a href="home.php"      class="nav-btn">🛒 Boutique</a>
    <a href="my_orders.php" class="nav-btn orders-btn">📋 Mes commandes</a>
    <a href="payment.php"   class="nav-btn active">🛒 Panier</a>
    <a href="../auth/logout.php" class="nav-btn logout-btn">↩ Déconnexion</a>
  </div>
</nav>

<main>
  <?php if(isset($_SESSION['error_message'])): ?>
  <div class="error-banner">⚠️ <?= htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?></div>
  <?php endif; ?>

  <div class="page-label">Panier</div>
  <h1 class="page-title">Votre <span>Commande</span></h1>
  <p class="page-sub">Vérifiez votre panier avant de confirmer la commande.</p>

  <?php if(empty($cart)): ?>
  <div class="empty-box">
    <div class="empty-icon">🛒</div>
    <p>Votre panier est vide.</p>
    <a href="home.php" class="shop-btn">Parcourir les produits →</a>
  </div>

  <?php else: ?>

  <table class="cart-table">
    <thead>
      <tr>
        <th>Produit</th><th>Fardeaux</th><th>Bt/fardeau</th>
        <th>Prix/fardeau</th><th>Sous-total</th><th></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($cart as $index => $item): ?>
    <tr>
      <td><?= htmlspecialchars($item['product_name']) ?></td>
      <td><?= $item['qty_fardeaux'] ?> fardeaux</td>
      <td><?= $item['bpf'] ?> bt</td>
      <td><?= number_format($item['prix_fardeau'],2) ?> DZD</td>
      <td><?= number_format($item['qty_fardeaux'] * $item['prix_fardeau'],2) ?> DZD</td>
      <td><a href="delete_item.php?index=<?= $index ?>" class="del-btn">✕ Retirer</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <div class="summary-box">
    <div class="summary-row">
      <span class="label">Montant HT</span>
      <span class="value"><?= number_format($totalHT,2) ?> DZD</span>
    </div>
    <div class="summary-row">
      <span class="label">TVA (19%)</span>
      <span class="value"><?= number_format($tva,2) ?> DZD</span>
    </div>
    <div class="summary-row">
      <span class="label">Timbre fiscal</span>
      <span class="value"><?= number_format($timbre,2) ?> DZD</span>
    </div>
    <div class="summary-total">
      <span class="label">Total TTC</span>
      <span class="value"><?= number_format($ttc,2) ?> DZD</span>
    </div>
    <form action="checkout.php" method="POST">
      <button type="submit" class="checkout-btn">✅ Confirmer la commande</button>
    </form>
  </div>

  <?php endif; ?>
</main>

<script>
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40 ? 'rgba(2,11,20,0.97)' : 'rgba(2,11,20,0.85)';
}, { passive:true });
</script>
</body>
</html>