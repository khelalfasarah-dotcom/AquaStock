<?php
session_start();
include "../config/db.php";
$orderID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$orderID){ header("Location: home.php"); exit(); }

$stmt = $conn->prepare("SELECT c.*, cl.nom, cl.telephone, cl.adresse FROM commande c JOIN client cl ON c.idClient=cl.idClient WHERE c.idCommande=?");
$stmt->bind_param("i", $orderID);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

$fRes = $conn->prepare("SELECT f.*, c.modePaiement as payMode FROM facture f LEFT JOIN commande c ON c.idCommande=f.idCommande WHERE f.idCommande=?");
$fRes->bind_param("i", $orderID); $fRes->execute();
$facture = $fRes->get_result()->fetch_assoc();

// Fetch order lines
$lines = [];
$lRes = $conn->prepare("SELECT lp.quantite, lp.sousTotal, pr.nomProduit, pr.volume, pr.prixFardeau FROM ligne_produit lp JOIN produit pr ON pr.idProduit=lp.idProduit WHERE lp.idCommande=?");
$lRes->bind_param("i", $orderID); $lRes->execute();
$lResult = $lRes->get_result();
while($row = $lResult->fetch_assoc()) $lines[] = $row;

$payModeLabels = ['cash'=>'💵 Cash à la livraison','card'=>'💳 Edahabia / Carte','carte'=>'💳 Edahabia / Carte','ccp'=>'📮 CCP / Baridimob','espece'=>'💵 Espèces','especes'=>'💵 Espèces','cheque'=>'📝 Chèque','virement'=>'🏦 Virement'];
$payMode  = $facture['payMode'] ?? 'cash';
$payLabel = $payModeLabels[$payMode] ?? ucfirst($payMode);

// Build lines JS array for print
$linesJS = json_encode(array_map(fn($l)=>[
    'name'=>$l['nomProduit'],
    'volume'=>$l['volume'],
    'qty'=>$l['quantite'],
    'prixFardeau'=>number_format($l['prixFardeau'],2),
    'sub'=>number_format($l['sousTotal'],2)
], $lines));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Commande Confirmée — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5);
}
::-webkit-scrollbar-thumb:hover {
  background:linear-gradient(to bottom, var(--accent), var(--accent3));
  box-shadow:0 0 14px rgba(0,212,245,0.8);
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

/* ─── SCROLL LINE ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0;
  transition:width 0.1s linear;
}

/* ─── AMBIENT ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 60% at 50% -10%, rgba(0,119,168,0.28) 0%, transparent 60%),
    radial-gradient(ellipse 50% 50% at 90% 80%, rgba(0,212,245,0.06) 0%, transparent 50%),
    radial-gradient(ellipse 40% 40% at 5% 90%, rgba(0,255,204,0.05) 0%, transparent 50%);
}

/* ─── GRID ─── */
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}

/* ─── PARTICLES ─── */
.particles { position:fixed; inset:0; z-index:0; pointer-events:none; overflow:hidden; }
.drop {
  position:absolute; border-radius:50%; opacity:0;
  background:radial-gradient(circle at 30% 30%, var(--accent), rgba(0,119,168,0.3));
  animation:rise var(--d,8s) ease-in var(--delay,0s) infinite;
}
.drop.glow { box-shadow:0 0 6px var(--accent); }
@keyframes rise {
  0%   { transform:translateY(100vh) scale(0.2); opacity:0; }
  10%  { opacity:0.6; }
  90%  { opacity:0.1; }
  100% { transform:translateY(-5vh) scale(1.8); opacity:0; }
}

/* ─── NAV ─── */
nav {
  position:fixed; top:0; left:0; right:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px; height:70px;
  background:rgba(2,11,20,0.85);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  transition:background 0.3s;
}
.nav-brand {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text);
  text-decoration:none;
}
.nav-brand-icon {
  width:38px; height:38px; border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center; font-size:18px;
  box-shadow:0 0 20px rgba(0,212,245,0.4);
}
.nav-right { display:flex; align-items:center; gap:10px; }
.welcome { font-size:13px; color:var(--muted2); margin-right:6px; }
.welcome strong { color:var(--text); font-weight:600; }
.nav-btn {
  display:flex; align-items:center; gap:7px;
  padding:9px 16px; border-radius:9px; text-decoration:none;
  font-weight:600; font-size:12px; transition:all .25s;
  border:1px solid var(--border); color:var(--muted2);
  background:var(--surface);
}
.nav-btn:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-1px); }
.logout-btn:hover { color:var(--red) !important; border-color:rgba(244,63,94,0.3) !important; }

/* ─── MAIN ─── */
main {
  position:relative; z-index:10;
  padding:110px 56px 80px;
  max-width:960px; margin:0 auto;
}

/* ─── SUCCESS HEADER ─── */
.success-header {
  text-align:center; margin-bottom:52px;
  animation:fadeUp .7s cubic-bezier(.22,1,.36,1) both;
}
.success-icon-wrap {
  position:relative; display:inline-block;
  width:96px; height:96px; margin:0 auto 24px;
}
.success-icon-bg {
  position:absolute; inset:0; border-radius:50%;
  background:radial-gradient(circle, rgba(0,255,204,0.15) 0%, transparent 70%);
  animation:pulse 3s ease-in-out infinite;
}
.success-icon-bg2 {
  position:absolute; inset:-12px; border-radius:50%;
  border:1px solid rgba(0,255,204,0.15);
  animation:pulse 3s ease-in-out infinite .5s;
}
@keyframes pulse { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.1);opacity:0.5} }
.success-icon {
  position:relative; z-index:1; font-size:52px;
  display:flex; align-items:center; justify-content:center;
  width:100%; height:100%;
}

.success-eyebrow {
  display:inline-flex; align-items:center; gap:8px;
  padding:6px 14px; border-radius:100px;
  border:1px solid rgba(0,255,204,0.3);
  background:rgba(0,255,204,0.05);
  font-size:11px; font-weight:600; letter-spacing:1.5px;
  text-transform:uppercase; color:var(--green);
  margin-bottom:20px;
}
.success-eyebrow-dot {
  width:5px; height:5px; background:var(--green); border-radius:50%;
  animation:blink 2s ease-in-out infinite;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }

.success-title {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(44px,6vw,68px);
  line-height:1; letter-spacing:1.5px;
  margin-bottom:14px;
}
.success-title .hl { color:var(--accent); }

.success-sub {
  font-size:15px; color:var(--muted2); line-height:1.8;
  font-weight:300; max-width:480px; margin:0 auto 20px;
}

.order-badge {
  display:inline-flex; align-items:center; gap:7px;
  padding:7px 16px; border-radius:100px;
  background:var(--surface); border:1px solid var(--border2);
  font-size:13px; font-weight:600; color:var(--text);
}

.status-confirmed {
  display:inline-flex; align-items:center; gap:7px;
  padding:7px 14px; border-radius:100px;
  background:rgba(0,255,204,0.08); border:1px solid rgba(0,255,204,0.22);
  font-size:11px; font-weight:700; color:var(--green);
}
.status-dot {
  width:6px; height:6px; border-radius:50%; background:var(--green);
  position:relative;
}
.status-dot::after {
  content:''; position:absolute; inset:-3px; border-radius:50%;
  border:1px solid var(--green);
  animation:ripple 2s ease-in-out infinite;
}
@keyframes ripple { 0%,100%{transform:scale(1);opacity:0.8} 50%{transform:scale(2);opacity:0} }

.badges-row {
  display:flex; justify-content:center; gap:10px; flex-wrap:wrap;
  margin-top:14px;
}

/* ─── CONTENT GRID ─── */
.content-grid {
  display:grid; grid-template-columns:1fr 1fr; gap:20px;
  margin-bottom:20px;
  animation:fadeUp .7s cubic-bezier(.22,1,.36,1) both .15s;
}

/* ─── CARDS ─── */
.card {
  background:rgba(8,20,40,0.75);
  border:1px solid var(--border);
  border-radius:18px; overflow:hidden;
  backdrop-filter:blur(12px);
  transition:border-color .3s;
}
.card:hover { border-color:var(--border2); }
.card-full {
  margin-bottom:20px;
  animation:fadeUp .7s cubic-bezier(.22,1,.36,1) both .25s;
}
.card-header {
  display:flex; align-items:center; gap:12px;
  padding:18px 22px;
  border-bottom:1px solid var(--border);
  background:rgba(0,212,245,0.03);
}
.card-header-icon {
  width:34px; height:34px; border-radius:9px;
  background:rgba(0,212,245,0.1); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center; font-size:16px;
}
.card-header-title {
  font-size:13px; font-weight:700; letter-spacing:0.4px;
  text-transform:uppercase; color:var(--muted2);
}
.card-body { padding:20px 22px; }
.info-row {
  display:flex; justify-content:space-between; align-items:center;
  padding:10px 0;
  border-bottom:1px solid rgba(0,212,245,0.06);
}
.info-row:last-child { border:none; }
.info-row .k { font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:0.6px; }
.info-row .v { font-size:14px; font-weight:600; color:var(--text); text-align:right; max-width:60%; }
.info-row .v.accent { color:var(--accent); }
.info-row .v.big {
  font-family:'Bebas Neue',sans-serif;
  font-size:20px; letter-spacing:0.5px; color:var(--accent);
}

/* ─── ITEMS TABLE ─── */
.lines-table { width:100%; border-collapse:collapse; }
.lines-table thead tr {
  background:rgba(0,212,245,0.04);
  border-bottom:1px solid var(--border);
}
.lines-table th {
  padding:13px 20px;
  font-size:10px; font-weight:700; letter-spacing:1.2px;
  text-transform:uppercase; color:var(--muted);
}
.lines-table td {
  padding:14px 20px;
  font-size:14px; color:var(--muted2);
  border-bottom:1px solid rgba(0,212,245,0.05);
  transition:background .2s;
}
.lines-table td:first-child { color:var(--text); font-weight:500; }
.lines-table td:last-child { color:var(--text); font-weight:600; }
.lines-table tr:last-child td { border:none; }
.lines-table tr:hover td { background:rgba(0,212,245,0.03); }
.qty-badge {
  display:inline-flex; align-items:center; justify-content:center;
  width:28px; height:28px; border-radius:7px;
  background:rgba(0,212,245,0.08); border:1px solid var(--border2);
  font-size:12px; font-weight:700; color:var(--accent);
}

/* ─── TOTALS STRIP ─── */
.totals-strip {
  display:flex; justify-content:flex-end;
  padding:16px 22px;
  border-top:1px solid var(--border);
  background:rgba(0,0,0,0.15);
  flex-wrap:wrap; gap:24px;
}
.tot-item { text-align:right; }
.tot-item .t-label { font-size:10px; color:var(--muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:3px; }
.tot-item .t-val { font-size:14px; font-weight:700; color:var(--text); }
.tot-item.ttc .t-val {
  font-family:'Bebas Neue',sans-serif;
  font-size:26px; letter-spacing:0.5px; color:var(--accent);
}

/* ─── BUTTONS ─── */
.btn-row {
  display:flex; gap:12px;
  animation:fadeUp .7s cubic-bezier(.22,1,.36,1) both .35s;
}
.btn-primary {
  flex:1; display:flex; align-items:center; justify-content:center; gap:9px;
  padding:15px 24px; border-radius:12px; cursor:pointer;
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; border:none;
  font-family:'Bebas Neue',sans-serif; font-size:18px; letter-spacing:1.5px;
  text-decoration:none; font-weight:700;
  box-shadow:0 0 24px rgba(0,212,245,0.2);
  transition:all .25s; position:relative; overflow:hidden;
}
.btn-primary::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg, rgba(255,255,255,0.15), transparent);
  opacity:0; transition:opacity .25s;
}
.btn-primary:hover { box-shadow:0 0 40px rgba(0,212,245,0.45); transform:translateY(-2px); }
.btn-primary:hover::before { opacity:1; }
.btn-outline {
  flex:1; display:flex; align-items:center; justify-content:center; gap:9px;
  padding:15px 24px; border-radius:12px; cursor:pointer;
  background:var(--surface); border:1px solid var(--border2);
  color:var(--accent);
  font-family:'Bebas Neue',sans-serif; font-size:18px; letter-spacing:1.5px;
  font-weight:700; text-decoration:none;
  transition:all .25s;
}
.btn-outline:hover {
  background:var(--surface2); border-color:var(--accent);
  box-shadow:0 0 24px rgba(0,212,245,0.15); transform:translateY(-2px);
}

/* ─── ANIMATIONS ─── */
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

/* ─── MOBILE ─── */
@media(max-width:768px){
  nav { padding:0 20px; }
  .welcome { display:none; }
  main { padding:90px 20px 60px; }
  .content-grid { grid-template-columns:1fr; }
  .btn-row { flex-direction:column; }
  .totals-strip { justify-content:space-between; }
  .success-title { font-size:42px; }
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>
<div class="particles" id="particles"></div>

<!-- ─── NAV ─── -->
<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">💧</div>
    AquaStock
  </a>
  <div class="nav-right">
    <div class="welcome">Bonjour, <strong><?= htmlspecialchars($order['nom'] ?? '') ?></strong></div>
    <a href="my_orders.php" class="nav-btn">📋 Mes commandes</a>
    <a href="../auth/logout.php" class="nav-btn logout-btn">↩ Déconnexion</a>
  </div>
</nav>

<!-- ─── MAIN ─── -->
<main>

  <!-- SUCCESS HEADER -->
  <div class="success-header">
    <div class="success-icon-wrap">
      <div class="success-icon-bg"></div>
      <div class="success-icon-bg2"></div>
      <span class="success-icon">✅</span>
    </div>

    <div style="display:flex;justify-content:center;margin-bottom:16px;">
      <div class="success-eyebrow">
        <span class="success-eyebrow-dot"></span>
        Commande Confirmée
      </div>
    </div>

    <h1 class="success-title">
      Merci, <span class="hl"><?= htmlspecialchars($order['nom'] ?? '') ?></span> !
    </h1>
    <p class="success-sub">
      Votre commande a été <strong>enregistrée avec succès</strong>.<br>
      Vous recevrez une confirmation dès validation par notre équipe.
    </p>

    <div class="badges-row">
      <div class="order-badge">📦 Commande #<?= $orderID ?></div>
      <?php if($facture): ?>
      <div class="order-badge">🧾 Facture #<?= $facture['idFacture'] ?></div>
      <?php endif; ?>
      <div class="status-confirmed"><span class="status-dot"></span> Confirmée</div>
    </div>
  </div>

  <!-- TWO COLUMN: DELIVERY + PAYMENT -->
  <div class="content-grid">

    <!-- Delivery Info -->
    <div class="card">
      <div class="card-header">
        <div class="card-header-icon">📍</div>
        <div class="card-header-title">Informations de livraison</div>
      </div>
      <div class="card-body">
        <div class="info-row">
          <span class="k">Client</span>
          <span class="v"><?= htmlspecialchars($order['nom'] ?? '—') ?></span>
        </div>
        <div class="info-row">
          <span class="k">Téléphone</span>
          <span class="v"><?= htmlspecialchars($order['telephone'] ?? '—') ?></span>
        </div>
        <div class="info-row">
          <span class="k">Adresse</span>
          <span class="v"><?= htmlspecialchars($order['adresse'] ?? '—') ?></span>
        </div>
      </div>
    </div>

    <!-- Payment Info -->
    <div class="card">
      <div class="card-header">
        <div class="card-header-icon">💳</div>
        <div class="card-header-title">Paiement &amp; Facturation</div>
      </div>
      <div class="card-body">
        <div class="info-row">
          <span class="k">Mode de paiement</span>
          <span class="v accent"><?= $payLabel ?></span>
        </div>
        <?php if($facture): ?>
        <div class="info-row">
          <span class="k">Date facture</span>
          <span class="v"><?= $facture['dateFacture'] ?? '—' ?></span>
        </div>
        <div class="info-row">
          <span class="k">Total TTC</span>
          <span class="v big"><?= number_format($facture['montantTC'],2) ?> DZD</span>
        </div>
        <?php else: ?>
        <div class="info-row">
          <span class="k">Statut facture</span>
          <span class="v" style="color:var(--muted);font-style:italic;">En attente</span>
        </div>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- /content-grid -->

  <!-- ORDER ITEMS -->
  <?php if(!empty($lines)): ?>
  <div class="card card-full">
    <div class="card-header">
      <div class="card-header-icon">🛒</div>
      <div class="card-header-title">Articles commandés</div>
    </div>
    <div style="overflow-x:auto;">
      <table class="lines-table">
        <thead>
          <tr>
            <th style="text-align:left;">Produit</th>
            <th style="text-align:center;">Volume</th>
            <th style="text-align:center;">Fardeaux</th>
            <th style="text-align:right;">Prix/fardeau</th>
            <th style="text-align:right;">Sous-total</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($lines as $l): ?>
          <tr>
            <td><?= htmlspecialchars($l['nomProduit']) ?></td>
            <td style="text-align:center;"><?= htmlspecialchars($l['volume']) ?></td>
            <td style="text-align:center;"><span class="qty-badge"><?= $l['quantite'] ?></span> fardeau(x)</td>
            <td style="text-align:right;"><?= number_format($l['prixFardeau'],2) ?> DZD</td>
            <td style="text-align:right;"><?= number_format($l['sousTotal'],2) ?> DZD</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if($facture): ?>
    <div class="totals-strip">
      <div class="tot-item">
        <div class="t-label">Sous-total HT</div>
        <div class="t-val"><?= number_format($facture['montantTotal'],2) ?> DZD</div>
      </div>
      <div class="tot-item">
        <div class="t-label">TVA (19%)</div>
        <div class="t-val"><?= number_format($facture['tva'],2) ?> DZD</div>
      </div>
      <div class="tot-item">
        <div class="t-label">Timbre fiscal</div>
        <div class="t-val"><?= number_format($facture['timbre'],2) ?> DZD</div>
      </div>
      <div class="tot-item ttc">
        <div class="t-label">Total TTC</div>
        <div class="t-val"><?= number_format($facture['montantTC'],2) ?> DZD</div>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- ACTION BUTTONS -->
  <div class="btn-row">
    <button class="btn-outline" onclick="printReceipt()">🖨 Imprimer le reçu</button>
    <a href="my_orders.php" class="btn-outline">📋 Mes commandes</a>
    <a href="home.php" class="btn-primary">🏠 Retour à la boutique</a>
  </div>

</main>

<!-- ─── PRINT RECEIPT ─── -->
<script>
const orderLines = <?= $linesJS ?>;

function printReceipt(){
  const nom    = <?= json_encode($order['nom']       ?? '') ?>;
  const tel    = <?= json_encode($order['telephone'] ?? '—') ?>;
  const adr    = <?= json_encode($order['adresse']   ?? '—') ?>;
  const ordId  = <?= $orderID ?>;
  const facId  = <?= $facture ? $facture['idFacture'] : 'null' ?>;
  const date   = <?= json_encode($facture['dateFacture'] ?? date('Y-m-d')) ?>;
  const ht     = <?= $facture ? $facture['montantTotal'] : 0 ?>;
  const tva    = <?= $facture ? $facture['tva']        : 0 ?>;
  const timbre = <?= $facture ? $facture['timbre']     : 0 ?>;
  const ttc    = <?= $facture ? $facture['montantTC']  : 0 ?>;
  const mode   = <?= json_encode($payLabel) ?>;

  let linesHtml = '';
  if(orderLines.length){
    linesHtml = `
    <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
      <thead>
        <tr style="background:#f1f5f9;">
          <th style="text-align:left;padding:8px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#64748b;border-bottom:2px solid #e2e8f0;">Produit</th>
          <th style="text-align:center;padding:8px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#64748b;border-bottom:2px solid #e2e8f0;">Volume</th>
          <th style="text-align:center;padding:8px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#64748b;border-bottom:2px solid #e2e8f0;">Fardeaux</th>
          <th style="text-align:right;padding:8px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#64748b;border-bottom:2px solid #e2e8f0;">Prix/fardeau</th>
          <th style="text-align:right;padding:8px 12px;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:#64748b;border-bottom:2px solid #e2e8f0;">Sous-total</th>
        </tr>
      </thead>
      <tbody>
        ${orderLines.map(l=>`
        <tr>
          <td style="padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;">${l.name}</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;text-align:center;">${l.volume}</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;text-align:center;">${l.qty} fardeau(x)</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;text-align:right;">${l.prixFardeau} DZD</td>
          <td style="padding:10px 12px;border-bottom:1px solid #f1f5f9;font-size:13px;text-align:right;font-weight:600;">${l.sub} DZD</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
  }

  const html = `<html><head><title>Reçu — Commande #${ordId}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap');
    body{font-family:'Outfit',Arial,sans-serif;padding:44px;color:#111;max-width:720px;margin:0 auto;}
    .header{text-align:center;border-bottom:3px solid #00d4f5;padding-bottom:22px;margin-bottom:32px;}
    .logo{font-size:30px;font-weight:700;color:#00d4f5;letter-spacing:2px;margin:0;}
    .logo-sub{color:#64748b;font-size:13px;margin:4px 0 0;}
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:30px;}
    .info-box{background:#f8fafc;border-radius:10px;padding:18px;border:1px solid #e2e8f0;}
    .info-box h3{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:#64748b;margin:0 0 10px;font-weight:700;}
    .info-box p{margin:4px 0;font-size:13px;color:#334155;}
    .totals{background:#f8fafc;border-radius:10px;padding:20px;margin-left:auto;width:320px;border:1px solid #e2e8f0;}
    .tot-row{display:flex;justify-content:space-between;padding:7px 0;font-size:13px;border-bottom:1px solid #e2e8f0;color:#64748b;}
    .tot-row:last-child{border:none;font-size:18px;font-weight:700;color:#00d4f5;padding-top:13px;}
    .footer{text-align:center;margin-top:44px;color:#94a3b8;font-size:11px;border-top:1px solid #e2e8f0;padding-top:18px;}
    @media print{body{padding:20px;}}
  </style></head><body>
  <div class="header">
    <p class="logo">💧 AquaStock</p>
    <p class="logo-sub">Usine d'Eau Minérale — Reçu de Commande</p>
  </div>
  <div class="info-grid">
    <div class="info-box">
      <h3>Détails commande</h3>
      <p><b>Commande # :</b> ${ordId}</p>
      ${facId ? `<p><b>Facture # :</b> ${facId}</p>` : ''}
      <p><b>Date :</b> ${date}</p>
      <p><b>Paiement :</b> ${mode}</p>
    </div>
    <div class="info-box">
      <h3>Client</h3>
      <p><b>${nom}</b></p>
      <p>📞 ${tel}</p>
      <p>📍 ${adr}</p>
    </div>
  </div>
  ${linesHtml}
  <div class="totals">
    <div class="tot-row"><span>Sous-total HT</span><span>${parseFloat(ht).toFixed(2)} DZD</span></div>
    <div class="tot-row"><span>TVA (19%)</span><span>${parseFloat(tva).toFixed(2)} DZD</span></div>
    <div class="tot-row"><span>Timbre fiscal</span><span>${parseFloat(timbre).toFixed(2)} DZD</span></div>
    <div class="tot-row"><span>TOTAL TTC</span><span>${parseFloat(ttc).toFixed(2)} DZD</span></div>
  </div>
  <div class="footer">Merci pour votre confiance — AquaStock Usine d'Eau Minérale</div>
  </body></html>`;

  const w = window.open('','_blank','width=800,height=700');
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(()=>{ w.print(); }, 500);
}
</script>

<script>
// Scroll progress line
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

// Nav background on scroll
const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40
    ? 'rgba(2,11,20,0.97)'
    : 'rgba(2,11,20,0.85)';
}, { passive:true });

// Floating particles
const c = document.getElementById('particles');
for(let i = 0; i < 35; i++){
  const d = document.createElement('div');
  d.className = 'drop' + (Math.random() > 0.7 ? ' glow' : '');
  const s = 1.5 + Math.random() * 4.5;
  d.style.cssText = `left:${Math.random()*100}%;width:${s}px;height:${s}px;--d:${5+Math.random()*12}s;--delay:${Math.random()*15}s;`;
  c.appendChild(d);
}
</script>
</body>
</html>