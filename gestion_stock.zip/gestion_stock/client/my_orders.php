<?php
session_start();
include "../config/db.php";
if (!isset($_SESSION['client_name']) || !isset($_SESSION['client_id'])) {
    header("Location: ../auth/login_client.php"); exit();
}
$idClient = (int)$_SESSION['client_id'];

// ── Stats résumé ──────────────────────────────────────────────────────────────
$stmtStats = $conn->prepare("
    SELECT
        COUNT(*)                                                        AS total_cmd,
        COUNT(CASE WHEN c.etatCommande = 'validee'  THEN 1 END)        AS nb_validees,
        COUNT(CASE WHEN c.etatCommande = 'en_cours' THEN 1 END)        AS nb_en_cours,
        COUNT(CASE WHEN c.etatCommande = 'annulee'  THEN 1 END)        AS nb_annulees,
        COALESCE(SUM(f.montantTC), 0)                                   AS ttc_total,
        COALESCE(SUM(CASE WHEN c.etatCommande='validee'  THEN f.montantTC END), 0) AS ttc_validees,
        COALESCE(SUM(CASE WHEN c.etatCommande='en_cours' THEN f.montantTC END), 0) AS ttc_en_cours
    FROM commande c
    LEFT JOIN facture f ON f.idCommande = c.idCommande
    WHERE c.idClient = ?
      AND c.modePaiement IS NOT NULL
");
$stmtStats->bind_param("i", $idClient);
$stmtStats->execute();
$s = $stmtStats->get_result()->fetch_assoc();

// ── Liste commandes ───────────────────────────────────────────────────────────
$stmt = $conn->prepare("
    SELECT c.idCommande, c.dateCommande, c.etatCommande, c.modePaiement,
           f.idFacture, f.montantTotal, f.tva, f.timbre, f.montantTC
    FROM commande c
    LEFT JOIN facture f ON f.idCommande = c.idCommande
    WHERE c.idClient = ?
      AND c.modePaiement IS NOT NULL
    ORDER BY c.idCommande DESC
");
$stmt->bind_param("i", $idClient);
$stmt->execute();
$orders = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mes Commandes — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --yellow:  #fbbf24;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body { font-family:'Outfit',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; overflow-x:hidden; }

::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb { background:linear-gradient(to bottom,var(--accent2),var(--accent),var(--accent3)); border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5); }
::-webkit-scrollbar-thumb:hover { background:linear-gradient(to bottom,var(--accent),var(--accent3)); box-shadow:0 0 14px rgba(0,212,245,0.8); }
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

.scroll-line { position:fixed; top:0; left:0; z-index:999; pointer-events:none; height:3px; width:0%; background:linear-gradient(90deg,var(--accent2),var(--accent),var(--accent3)); box-shadow:0 0 20px var(--accent),0 0 40px rgba(0,212,245,0.4); border-radius:0 2px 2px 0; transition:width 0.1s linear; }

.ambient { position:fixed; inset:0; z-index:0; pointer-events:none; background: radial-gradient(ellipse 80% 50% at 50% 0%,rgba(0,119,168,0.2) 0%,transparent 60%), radial-gradient(ellipse 40% 40% at 90% 80%,rgba(0,212,245,0.06) 0%,transparent 50%); }
.grid-bg { position:fixed; inset:0; z-index:0; pointer-events:none; background-image:linear-gradient(rgba(0,212,245,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,245,0.025) 1px,transparent 1px); background-size:60px 60px; }
body::before { content:''; position:fixed; inset:0; z-index:1; pointer-events:none; background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E"); opacity:0.35; }

nav { position:sticky; top:0; z-index:500; display:flex; align-items:center; justify-content:space-between; padding:0 56px; height:70px; background:rgba(2,11,20,0.85); backdrop-filter:blur(20px); border-bottom:1px solid var(--border); transition:background 0.3s; }
.nav-brand { display:flex; align-items:center; gap:10px; font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text); text-decoration:none; }
.nav-brand-icon { width:38px; height:38px; border-radius:10px; background:linear-gradient(135deg,var(--accent),var(--accent2)); display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 0 20px rgba(0,212,245,0.4); }
.nav-right { display:flex; align-items:center; gap:10px; }
.welcome { font-size:13px; color:var(--muted2); margin-right:6px; }
.welcome strong { color:var(--text); font-weight:600; }
.nav-btn { display:flex; align-items:center; gap:7px; padding:9px 16px; border-radius:9px; text-decoration:none; font-weight:600; font-size:12px; transition:all .25s; border:1px solid var(--border); color:var(--muted2); background:var(--surface); }
.nav-btn:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-1px); }
.nav-btn.active { border-color:rgba(0,255,204,0.3); color:var(--green); background:rgba(0,255,204,0.06); }
.cart-btn { background:linear-gradient(135deg,var(--accent),var(--accent2)); border-color:transparent; color:#020b14 !important; font-weight:700 !important; box-shadow:0 0 20px rgba(0,212,245,0.2); }
.cart-btn:hover { box-shadow:0 0 35px rgba(0,212,245,0.4) !important; transform:translateY(-2px) !important; }
.logout-btn:hover { color:var(--red) !important; border-color:rgba(244,63,94,0.3) !important; }

main { position:relative; z-index:10; padding:52px 56px; max-width:1100px; margin:0 auto; }

.page-header { margin-bottom:40px; }
.page-label { font-size:10px; text-transform:uppercase; letter-spacing:3px; color:var(--accent); font-weight:600; margin-bottom:14px; display:flex; align-items:center; gap:8px; }
.page-label::before { content:''; width:24px; height:1px; background:var(--accent); }
.page-title { font-family:'Bebas Neue',sans-serif; font-size:clamp(40px,5vw,62px); letter-spacing:1px; line-height:0.95; margin-bottom:14px; }
.page-title span { color:var(--accent); }
.page-sub { font-size:14px; color:var(--muted2); font-weight:300; line-height:1.7; }

/* ═══════════ SUMMARY STATS ═══════════ */
.summary-grid {
  display:grid;
  grid-template-columns:repeat(4, 1fr);
  gap:16px;
  margin-bottom:44px;
}
.sc {
  border-radius:16px; padding:24px 22px;
  border:1px solid var(--border);
  background:var(--surface);
  position:relative; overflow:hidden;
  transition:transform .3s, border-color .3s, box-shadow .3s;
  animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both;
  cursor:default;
}
.sc:hover { transform:translateY(-5px); box-shadow:0 20px 50px rgba(0,0,0,.45); }
/* top color bar */
.sc::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; }
.sc.total::before    { background:linear-gradient(90deg,var(--accent),var(--accent3)); }
.sc.valid::before    { background:linear-gradient(90deg,#00ffcc,#00c899); }
.sc.pending::before  { background:linear-gradient(90deg,#fbbf24,#f59e0b); }
.sc.cancel::before   { background:linear-gradient(90deg,#f43f5e,#e11d48); }
/* glow on hover */
.sc.total:hover   { border-color:var(--border2); }
.sc.valid:hover   { border-color:rgba(0,255,204,.35); }
.sc.pending:hover { border-color:rgba(251,191,36,.35); }
.sc.cancel:hover  { border-color:rgba(244,63,94,.35); }

.sc-icon { font-size:26px; margin-bottom:14px; display:block; }
.sc-label { font-size:10px; text-transform:uppercase; letter-spacing:1.3px; color:var(--muted); font-weight:700; margin-bottom:8px; }
.sc-count { font-family:'Bebas Neue',sans-serif; font-size:42px; letter-spacing:.5px; line-height:1; margin-bottom:12px; }
.sc.total.sc-count,
.sc.total   .sc-count { color:var(--accent); }
.sc.valid   .sc-count { color:var(--green); }
.sc.pending .sc-count { color:var(--yellow); }
.sc.cancel  .sc-count { color:var(--red); }

.sc-divider { height:1px; background:var(--border); margin-bottom:12px; }
.sc-amount-label { font-size:10px; color:var(--muted); text-transform:uppercase; letter-spacing:.8px; margin-bottom:4px; }
.sc-amount { font-size:14px; font-weight:700; }
.sc.total   .sc-amount { color:var(--muted2); }
.sc.valid   .sc-amount { color:var(--green); }
.sc.pending .sc-amount { color:var(--yellow); }
.sc.cancel  .sc-amount { color:var(--muted); }

/* ═══════════ ORDER CARDS ═══════════ */
.empty { text-align:center; padding:80px 20px; background:var(--surface); border:1px solid var(--border); border-radius:16px; }
.empty-icon { font-size:56px; margin-bottom:16px; opacity:0.5; }
.empty p { font-size:15px; color:var(--muted); margin-bottom:24px; }
.shop-link { display:inline-block; padding:13px 28px; background:linear-gradient(135deg,var(--accent),var(--accent2)); color:#020b14; border-radius:10px; text-decoration:none; font-weight:700; font-size:13px; box-shadow:0 0 24px rgba(0,212,245,0.2); transition:all .25s; }
.shop-link:hover { box-shadow:0 0 40px rgba(0,212,245,0.4); transform:translateY(-2px); }

.order-card { background:var(--surface); border:1px solid var(--border); border-radius:16px; overflow:hidden; margin-bottom:16px; transition:all .3s; animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both; position:relative; }
@keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
.order-card::before { content:''; position:absolute; top:0; left:0; right:0; height:2px; background:linear-gradient(90deg,var(--accent),var(--accent3)); transform:scaleX(0); transform-origin:left; transition:transform .4s; }
.order-card:hover::before { transform:scaleX(1); }
.order-card:hover { border-color:var(--border2); background:var(--surface2); }

.order-header { display:flex; align-items:center; justify-content:space-between; padding:20px 24px; border-bottom:1px solid transparent; cursor:pointer; gap:12px; transition:border-color .3s; user-select:none; }
.order-card.open .order-header { border-color:var(--border); }
.order-id { font-family:'Bebas Neue',sans-serif; font-size:20px; letter-spacing:0.5px; }
.order-id span { color:var(--accent); }
.order-meta { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.order-date { font-size:12px; color:var(--muted); }
.badge { display:inline-flex; align-items:center; gap:5px; padding:4px 12px; border-radius:100px; font-size:11px; font-weight:700; }
.badge-green  { background:rgba(0,255,204,0.1);  color:var(--green);  border:1px solid rgba(0,255,204,0.25); }
.badge-yellow { background:rgba(251,191,36,0.1); color:var(--yellow); border:1px solid rgba(251,191,36,0.25); }
.badge-red    { background:rgba(244,63,94,0.1);  color:var(--red);    border:1px solid rgba(244,63,94,0.25); }
.badge-blue   { background:rgba(0,212,245,0.08); color:var(--accent); border:1px solid var(--border2); }
.order-total { font-family:'Bebas Neue',sans-serif; font-size:20px; color:var(--accent); letter-spacing:0.5px; }
.toggle-btn { font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; color:var(--muted); padding:6px 12px; border-radius:7px; border:1px solid var(--border); background:var(--surface); transition:all .25s; white-space:nowrap; flex-shrink:0; }
.order-card.open .toggle-btn { color:var(--accent); border-color:var(--border2); background:var(--surface2); }

.order-body { padding:0 24px; max-height:0; overflow:hidden; transition:max-height .4s ease,padding .3s; }
.order-body.open { max-height:800px; padding:20px 24px; }

.lines-table { width:100%; border-collapse:collapse; margin-bottom:18px; }
.lines-table th { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:var(--muted); padding:10px 14px; text-align:left; background:rgba(0,212,245,0.04); border-bottom:1px solid var(--border); font-weight:700; }
.lines-table td { padding:12px 14px; border-bottom:1px solid rgba(0,212,245,0.05); font-size:13px; color:var(--muted2); }
.lines-table tr:last-child td { border:none; }
.lines-table td:first-child { color:var(--text); font-weight:500; }
.lines-table td:last-child  { color:var(--accent); font-weight:700; }
.lines-table tr:hover td { background:rgba(0,212,245,0.03); }

.totals-box { background:rgba(0,0,0,0.25); border:1px solid var(--border); border-radius:12px; padding:18px 22px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px; }
.total-item { font-size:12px; color:var(--muted); line-height:1.6; }
.total-item .val { display:block; font-size:14px; font-weight:700; color:var(--text); margin-top:2px; }
.total-ttc .val { font-family:'Bebas Neue',sans-serif; font-size:22px; color:var(--accent); letter-spacing:0.5px; }
.pay-info { font-size:12px; color:var(--muted); margin-top:12px; padding:10px 14px; background:var(--surface); border-radius:8px; border:1px solid var(--border); }
.pay-info span { color:var(--text); font-weight:600; }
.no-invoice { font-size:13px; color:var(--muted); font-style:italic; padding:8px 0; }

.orders-section-title { font-family:'Bebas Neue',sans-serif; font-size:18px; letter-spacing:.5px; color:var(--muted2); margin-bottom:16px; display:flex; align-items:center; gap:8px; }
.orders-section-title::after { content:''; flex:1; height:1px; background:var(--border); }

@media(max-width:900px){ .summary-grid { grid-template-columns:1fr 1fr; } }
@media(max-width:768px){ nav { padding:0 20px; } .welcome { display:none; } main { padding:32px 20px; } .order-header { flex-wrap:wrap; } }
@media(max-width:480px){ .summary-grid { grid-template-columns:1fr; } }
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>

<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">💧</div>
    AquaStock
  </a>
  <div class="nav-right">
    <div class="welcome">Bonjour, <strong><?= htmlspecialchars($_SESSION['client_name']) ?></strong></div>
    <a href="home.php"      class="nav-btn">🛒 Boutique</a>
    <a href="payment.php"   class="nav-btn cart-btn">🛒 Panier</a>
    <a href="my_orders.php" class="nav-btn active">📋 Mes commandes</a>
    <a href="../auth/logout.php" class="nav-btn logout-btn">↩ Déconnexion</a>
  </div>
</nav>

<main>
  <div class="page-header">
    <div class="page-label">Historique</div>
    <h1 class="page-title">Mes <span>Commandes</span></h1>
    <p class="page-sub">Vue d'ensemble complète de vos achats — confirmés, en attente et annulés.</p>
  </div>

  <!-- ════════════════ SUMMARY STATS ════════════════ -->
  <div class="summary-grid">

    <div class="sc total" style="animation-delay:.00s">
      <span class="sc-icon">📦</span>
      <div class="sc-label">Total commandes</div>
      <div class="sc-count" style="color:var(--accent)"><?= (int)$s['total_cmd'] ?></div>
      <div class="sc-divider"></div>
      <div class="sc-amount-label">Montant total TTC</div>
      <div class="sc-amount"><?= number_format((float)$s['ttc_total'], 2) ?> DZD</div>
    </div>

    <div class="sc valid" style="animation-delay:.08s">
      <span class="sc-icon">✅</span>
      <div class="sc-label">Commandes confirmées</div>
      <div class="sc-count" style="color:var(--green)"><?= (int)$s['nb_validees'] ?></div>
      <div class="sc-divider"></div>
      <div class="sc-amount-label">Montant confirmé TTC</div>
      <div class="sc-amount"><?= number_format((float)$s['ttc_validees'], 2) ?> DZD</div>
    </div>

    <div class="sc pending" style="animation-delay:.16s">
      <span class="sc-icon">⏳</span>
      <div class="sc-label">En cours / non confirmées</div>
      <div class="sc-count" style="color:var(--yellow)"><?= (int)$s['nb_en_cours'] ?></div>
      <div class="sc-divider"></div>
      <div class="sc-amount-label">Montant en attente TTC</div>
      <div class="sc-amount"><?= number_format((float)$s['ttc_en_cours'], 2) ?> DZD</div>
    </div>

    <div class="sc cancel" style="animation-delay:.24s">
      <span class="sc-icon">❌</span>
      <div class="sc-label">Commandes annulées</div>
      <div class="sc-count" style="color:var(--red)"><?= (int)$s['nb_annulees'] ?></div>
      <div class="sc-divider"></div>
      <div class="sc-amount-label">&nbsp;</div>
      <div class="sc-amount" style="color:var(--muted)">—</div>
    </div>

  </div>

  <!-- ════════════════ ORDER LIST ════════════════ -->
  <?php if($orders->num_rows === 0): ?>
  <div class="empty">
    <div class="empty-icon">📋</div>
    <p>Vous n'avez encore passé aucune commande.</p>
    <a href="home.php" class="shop-link">Commencer mes achats →</a>
  </div>
  <?php else: ?>

  <div class="orders-section-title">📋 Détail des commandes</div>

  <?php
  $delay = 0;
  while($order = $orders->fetch_assoc()):
    $statusMap = [
      'en_cours' => ['yellow','⏳ En cours'],
      'validee'  => ['green', '✅ Validée'],
      'annulee'  => ['red',   '❌ Annulée']
    ];
    [$sCls, $sLbl] = $statusMap[$order['etatCommande']] ?? ['yellow','⏳ En cours'];

    $modeLabels = [
      'espece'   => '💵 Espèces',
      'especes'  => '💵 Espèces',
      'cheque'   => '📝 Chèque',
      'virement' => '🏦 Virement',
      'card'     => '💳 Carte / Edahabia',
      'ccp'      => '📮 CCP / Baridimob',
      'cash'     => '💵 Cash à la livraison',
    ];
    $modeLabel = $modeLabels[$order['modePaiement']] ?? ($order['modePaiement'] ?: '—');

    $lStmt = $conn->prepare("
        SELECT lp.quantite, lp.sousTotal, pr.nomProduit, pr.volume
        FROM ligne_produit lp
        JOIN produit pr ON pr.idProduit = lp.idProduit
        WHERE lp.idCommande = ?
    ");
    $lStmt->bind_param("i", $order['idCommande']);
    $lStmt->execute();
    $lines = $lStmt->get_result();
    $delay++;
  ?>
  <div class="order-card" id="card-<?= $order['idCommande'] ?>" style="animation-delay:<?= (.28 + $delay * 0.07) ?>s">

    <div class="order-header" onclick="toggleOrder(<?= $order['idCommande'] ?>)">
      <div class="order-id">Commande <span>#<?= $order['idCommande'] ?></span></div>
      <div class="order-meta">
        <span class="order-date">📅 <?= $order['dateCommande'] ?></span>
        <span class="badge badge-<?= $sCls ?>"><?= $sLbl ?></span>
        <?php if($order['idFacture']): ?>
        <span class="badge badge-blue">🧾 Facture #<?= $order['idFacture'] ?></span>
        <?php endif; ?>
        <?php if($order['montantTC']): ?>
        <span class="order-total"><?= number_format($order['montantTC'], 2) ?> DZD</span>
        <?php endif; ?>
      </div>
      <span class="toggle-btn" id="toggle-<?= $order['idCommande'] ?>">▼ Détails</span>
    </div>

    <div class="order-body" id="body-<?= $order['idCommande'] ?>">
      <?php if($lines->num_rows > 0): ?>
      <table class="lines-table">
        <thead>
          <tr><th>Produit</th><th>Volume</th><th>Fardeaux</th><th>Prix / fardeau</th><th>Sous-total</th></tr>
        </thead>
        <tbody>
        <?php while($line = $lines->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($line['nomProduit']) ?></td>
          <td><?= htmlspecialchars($line['volume']) ?></td>
          <td><?= $line['quantite'] ?> fardeau(x)</td>
          <td><?= number_format($line['sousTotal'] / max(1, $line['quantite']), 2) ?> DZD</td>
          <td><?= number_format($line['sousTotal'], 2) ?> DZD</td>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
      <?php else: ?>
      <p class="no-invoice">Aucun produit enregistré pour cette commande.</p>
      <?php endif; ?>

      <?php if($order['idFacture']): ?>
      <div class="totals-box">
        <div class="total-item">Sous-total HT<span class="val"><?= number_format($order['montantTotal'], 2) ?> DZD</span></div>
        <div class="total-item">TVA (19%)<span class="val"><?= number_format($order['tva'], 2) ?> DZD</span></div>
        <div class="total-item">Timbre fiscal<span class="val"><?= number_format($order['timbre'], 2) ?> DZD</span></div>
        <div class="total-item total-ttc">Total TTC<span class="val"><?= number_format($order['montantTC'], 2) ?> DZD</span></div>
      </div>
      <p class="pay-info">Mode de paiement : <span><?= $modeLabel ?></span></p>
      <?php else: ?>
      <p class="no-invoice">⚠️ Facture non encore générée pour cette commande.</p>
      <?php endif; ?>
    </div>

  </div>
  <?php endwhile; ?>
  <?php endif; ?>

</main>

<script>
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40 ? 'rgba(2,11,20,0.97)' : 'rgba(2,11,20,0.85)';
}, { passive:true });

function toggleOrder(id) {
  const card = document.getElementById('card-' + id);
  const body = document.getElementById('body-' + id);
  const btn  = document.getElementById('toggle-' + id);
  const open = body.classList.toggle('open');
  card.classList.toggle('open', open);
  btn.textContent = open ? '▲ Masquer' : '▼ Détails';
}
</script>
</body>
</html>
