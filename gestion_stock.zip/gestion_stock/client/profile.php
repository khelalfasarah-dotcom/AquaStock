<?php
require_once __DIR__ . '/../config/session.php';
include "../config/db.php";

if (!isset($_SESSION['client_name']) || !isset($_SESSION['client_id'])) {
    header("Location: ../auth/login.php"); exit();
}
$idClient = (int)$_SESSION['client_id'];

$success = "";
$error   = "";

// ── Safe POST reader ──────────────────────────────────────────────────
function post(string $key): string {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : '';
}

// ── Fetch full client data ────────────────────────────────────────────
$stmt = $conn->prepare(
    "SELECT nom, adresse, willaya, telephone, login, email, dateNaissance, sexe
     FROM client WHERE idClient = ?"
);
$stmt->bind_param("i", $idClient);
$stmt->execute();
$client = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ── Algerian wilayas ─────────────────────────────────────────────────
$wilayas = [
    "01 - Adrar","02 - Chlef","03 - Laghouat","04 - Oum El Bouaghi","05 - Batna",
    "06 - Béjaïa","07 - Biskra","08 - Béchar","09 - Blida","10 - Bouira",
    "11 - Tamanrasset","12 - Tébessa","13 - Tlemcen","14 - Tiaret","15 - Tizi Ouzou",
    "16 - Alger","17 - Djelfa","18 - Jijel","19 - Sétif","20 - Saïda",
    "21 - Skikda","22 - Sidi Bel Abbès","23 - Annaba","24 - Guelma","25 - Constantine",
    "26 - Médéa","27 - Mostaganem","28 - M'Sila","29 - Mascara","30 - Ouargla",
    "31 - Oran","32 - El Bayadh","33 - Illizi","34 - Bordj Bou Arréridj","35 - Boumerdès",
    "36 - El Tarf","37 - Tindouf","38 - Tissemsilt","39 - El Oued","40 - Khenchela",
    "41 - Souk Ahras","42 - Tipaza","43 - Mila","44 - Aïn Defla","45 - Naâma",
    "46 - Aïn Témouchent","47 - Ghardaïa","48 - Relizane","49 - El M'Ghair",
    "50 - El Menia","51 - Ouled Djellal","52 - Bordj Baji Mokhtar","53 - Béni Abbès",
    "54 - Timimoun","55 - Touggourt","56 - Djanet","57 - In Salah","58 - In Guezzam"
];

// Use dedicated willaya column; fallback: parse old concatenated adresse for existing data
$stored_adresse = $client['adresse'] ?? '';
$stored_wilaya  = $client['willaya'] ?? '';
if (empty($stored_wilaya)) {
    foreach ($wilayas as $w) {
        if (str_ends_with($stored_adresse, ', ' . $w)) {
            $stored_wilaya  = $w;
            $stored_adresse = substr($stored_adresse, 0, strlen($stored_adresse) - strlen(', ' . $w));
            break;
        }
    }
}

// ── Handle profile update ─────────────────────────────────────────────
if (isset($_POST['update_profile'])) {
    $nom           = post('nom');
    $login         = post('login');
    $email         = post('email');
    $telephone     = post('telephone');
    $adresse       = post('adresse');
    $wilaya        = post('wilaya');
    $dateNaissance = post('dob');
    $sexe          = post('sexe');

    if (mb_strlen($nom) < 6) {
        $error = "Le nom complet doit contenir au moins 6 caractères.";
    } elseif (mb_strlen($login) < 3) {
        $error = "Le nom d'utilisateur doit contenir au moins 3 caractères.";
    } elseif (!preg_match('/^[a-zA-Z0-9._-]+$/', $login)) {
        $error = "Le nom d'utilisateur ne peut contenir que des lettres, chiffres, points, tirets et underscores.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Adresse e-mail invalide.";
    } elseif (!preg_match('/^0[5-7][0-9]{8}$/', $telephone)) {
        $error = "Numéro invalide — 10 chiffres commençant par 05, 06 ou 07.";
    } elseif (empty($adresse)) {
        $error = "L'adresse de livraison est obligatoire.";
    } elseif (empty($wilaya)) {
        $error = "Veuillez sélectionner votre wilaya.";
    } elseif (empty($dateNaissance)) {
        $error = "La date de naissance est obligatoire.";
    } elseif ((new DateTime())->diff(new DateTime($dateNaissance))->y < 13) {
        $error = "Vous devez avoir au moins 13 ans.";
    } elseif (!in_array($sexe, ['homme', 'femme'], true)) {
        $error = "Veuillez sélectionner votre sexe.";
    } else {
        // Check login uniqueness (exclude self)
        $chk_login = $conn->prepare("SELECT idClient FROM client WHERE login = ? AND idClient != ? LIMIT 1");
        if ($chk_login) {
            $chk_login->bind_param("si", $login, $idClient);
            $chk_login->execute();
            $chk_login->store_result();
            $login_taken = ($chk_login->num_rows > 0);
            $chk_login->close();
        } else { $login_taken = false; }

        // Check email uniqueness (exclude self)
        $chk = $conn->prepare("SELECT idClient FROM client WHERE email = ? AND idClient != ? LIMIT 1");
        if ($chk) {
            $chk->bind_param("si", $email, $idClient);
            $chk->execute();
            $chk->store_result();
            $email_taken = ($chk->num_rows > 0);
            $chk->close();
        } else { $email_taken = false; }

        if ($login_taken) {
            $error = "Ce nom d'utilisateur est déjà utilisé par un autre compte.";
        } elseif ($email_taken) {
            $error = "Cette adresse e-mail est déjà utilisée par un autre compte.";
        } else {
            $upd = $conn->prepare(
                "UPDATE client SET nom=?, login=?, email=?, telephone=?, adresse=?, willaya=?, dateNaissance=?, sexe=?
                 WHERE idClient=?"
            );
            if (!$upd) {
                $error = "Erreur SQL : " . $conn->error;
            } else {
                $upd->bind_param("ssssssssi", $nom, $login, $email, $telephone, $adresse, $wilaya, $dateNaissance, $sexe, $idClient);
                if ($upd->execute()) {
                    $success = "Profil mis à jour avec succès !";
                    $_SESSION['client_name'] = $nom;
                    $_SESSION['client_login'] = $login;
                    // Re-fetch updated data
                    $stmt2 = $conn->prepare(
                        "SELECT nom, adresse, willaya, telephone, login, email, dateNaissance, sexe
                         FROM client WHERE idClient = ?"
                    );
                    $stmt2->bind_param("i", $idClient);
                    $stmt2->execute();
                    $client = $stmt2->get_result()->fetch_assoc();
                    $stmt2->close();
                    $stored_adresse = $client['adresse'] ?? '';
                    $stored_wilaya  = $client['willaya'] ?? '';
                } else {
                    $error = "Erreur lors de la mise à jour : " . $upd->error;
                }
                $upd->close();
            }
        }
    }
}

// ── Handle password change ────────────────────────────────────────────
if (isset($_POST['change_password'])) {
    $current = post('current_password');
    $new     = post('new_password');
    $confirm = post('confirm_password');

    $pstmt = $conn->prepare("SELECT motdepasse FROM client WHERE idClient=?");
    $pstmt->bind_param("i", $idClient);
    $pstmt->execute();
    $row    = $pstmt->get_result()->fetch_assoc();
    $pstmt->close();
    $stored = $row['motdepasse'];

    $currentOk = password_verify($current, $stored) || ($current === $stored);

    if (!$currentOk) {
        $error = "Mot de passe actuel incorrect.";
    } elseif (strlen($new) < 6) {
        $error = "Le nouveau mot de passe doit contenir au moins 6 caractères.";
    } elseif ($new !== $confirm) {
        $error = "Les nouveaux mots de passe ne correspondent pas.";
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE client SET motdepasse=? WHERE idClient=?");
        $upd->bind_param("si", $hashed, $idClient);
        if ($upd->execute()) {
            $success = "Mot de passe modifié avec succès !";
        } else {
            $error = "Erreur lors de la mise à jour. Réessayez.";
        }
        $upd->close();
    }
}

// ── Handle delete error from redirect ────────────────────────────────
if (isset($_SESSION['delete_error'])) {
    $error = $_SESSION['delete_error'];
    unset($_SESSION['delete_error']);
}

// ── Order count ───────────────────────────────────────────────────────
$ostmt = $conn->prepare("SELECT COUNT(*) as total FROM commande WHERE idClient=? AND modePaiement IS NOT NULL");
$ostmt->bind_param("i", $idClient);
$ostmt->execute();
$orderCount = $ostmt->get_result()->fetch_assoc()['total'];
$ostmt->close();

// ── Helpers ───────────────────────────────────────────────────────────
function val(array $client, string $key, string $fallback = ''): string {
    return htmlspecialchars($client[$key] ?? $fallback);
}
$sexe_icon  = ($client['sexe'] ?? '') === 'femme' ? '👩' : '👨';
$dob_fmt    = !empty($client['dateNaissance'])
              ? (new DateTime($client['dateNaissance']))->format('d/m/Y')
              : 'Non renseignée';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mon Profil — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --yellow:  #fbbf24;
  --red:     #f43f5e;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:'Outfit',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;overflow-x:hidden}

/* ── SCROLLBAR ── */
::-webkit-scrollbar{width:6px}
::-webkit-scrollbar-track{background:rgba(0,212,245,0.04)}
::-webkit-scrollbar-thumb{background:linear-gradient(to bottom,var(--accent2),var(--accent),var(--accent3));border-radius:10px;box-shadow:0 0 8px rgba(0,212,245,0.5)}
*{scrollbar-width:thin;scrollbar-color:var(--accent) rgba(0,212,245,0.04)}

/* ── SCROLL LINE ── */
.scroll-line{position:fixed;top:0;left:0;z-index:999;pointer-events:none;height:3px;width:0%;background:linear-gradient(90deg,var(--accent2),var(--accent),var(--accent3));box-shadow:0 0 20px var(--accent);border-radius:0 2px 2px 0;transition:width .1s linear}

/* ── AMBIENT & GRID ── */
.ambient{position:fixed;inset:0;z-index:0;pointer-events:none;background:radial-gradient(ellipse 80% 50% at 50% 0%,rgba(0,119,168,0.2) 0%,transparent 60%),radial-gradient(ellipse 40% 40% at 90% 80%,rgba(0,212,245,0.06) 0%,transparent 50%)}
.grid-bg{position:fixed;inset:0;z-index:0;pointer-events:none;background-image:linear-gradient(rgba(0,212,245,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,245,0.025) 1px,transparent 1px);background-size:60px 60px}
body::before{content:'';position:fixed;inset:0;z-index:1;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");opacity:.35}

/* ── NAV ── */
nav{position:sticky;top:0;z-index:500;display:flex;align-items:center;justify-content:space-between;padding:0 56px;height:70px;background:rgba(2,11,20,0.85);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);transition:background .3s}
.nav-brand{display:flex;align-items:center;gap:10px;font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:2px;color:var(--text);text-decoration:none}
.nav-brand-icon{width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 0 20px rgba(0,212,245,0.4)}
.nav-right{display:flex;align-items:center;gap:10px}
.welcome{font-size:13px;color:var(--muted2);margin-right:6px}
.welcome strong{color:var(--text);font-weight:600}
.nav-btn{display:flex;align-items:center;gap:7px;padding:9px 16px;border-radius:9px;text-decoration:none;font-weight:600;font-size:12px;transition:all .25s;border:1px solid var(--border);color:var(--muted2);background:var(--surface)}
.nav-btn:hover{border-color:var(--border2);color:var(--text);background:var(--surface2);transform:translateY(-1px)}
.orders-btn{border-color:rgba(0,255,204,0.2);color:var(--green) !important;background:rgba(0,255,204,0.05)}
.orders-btn:hover{background:rgba(0,255,204,0.1) !important;border-color:rgba(0,255,204,0.4) !important}
.logout-btn:hover{color:var(--red) !important;border-color:rgba(244,63,94,0.3) !important}

/* ── MAIN ── */
main{position:relative;z-index:10;padding:52px 56px;max-width:1100px;margin:0 auto}

/* ── PAGE HEADER ── */
.page-header{margin-bottom:36px}
.page-label{font-size:10px;text-transform:uppercase;letter-spacing:3px;color:var(--accent);font-weight:600;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.page-label::before{content:'';width:24px;height:1px;background:var(--accent)}
.page-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(40px,5vw,64px);letter-spacing:1px;line-height:.95;margin-bottom:12px}
.page-title span{color:var(--accent)}
.page-sub{font-size:14px;color:var(--muted2);font-weight:300;line-height:1.7}

/* ── HERO ── */
.profile-hero{display:flex;align-items:center;gap:32px;background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:28px 36px;margin-bottom:28px;animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both;position:relative;overflow:hidden}
.profile-hero::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--accent),var(--accent3))}
.avatar{width:84px;height:84px;border-radius:50%;flex-shrink:0;background:linear-gradient(135deg,var(--accent2),var(--accent));display:flex;align-items:center;justify-content:center;font-size:36px;box-shadow:0 0 0 4px rgba(0,212,245,0.15),0 0 40px rgba(0,212,245,0.25)}
.hero-info{flex:1}
.hero-name{font-family:'Bebas Neue',sans-serif;font-size:28px;letter-spacing:1px;margin-bottom:3px}
.hero-login{font-size:13px;color:var(--muted2);margin-bottom:14px}
.hero-login span{color:var(--accent);font-weight:600}
.stats-row{display:flex;gap:12px;flex-wrap:wrap}
.stat-chip{display:flex;align-items:center;gap:8px;background:rgba(0,212,245,0.06);border:1px solid rgba(0,212,245,0.15);border-radius:10px;padding:7px 14px;font-size:12px;color:var(--muted2)}
.stat-chip strong{color:var(--accent);font-size:15px;font-family:'Bebas Neue',sans-serif;letter-spacing:.5px}
.stat-chip.green{background:rgba(0,255,204,0.05);border-color:rgba(0,255,204,0.15)}
.stat-chip.green strong{color:var(--green)}
.stat-chip.pink{background:rgba(244,114,182,0.05);border-color:rgba(244,114,182,0.15)}
.stat-chip.pink strong{color:#f472b6}

/* ── TABS ── */
.tabs{display:flex;gap:4px;margin-bottom:24px;background:rgba(0,0,0,0.3);border:1px solid var(--border);border-radius:13px;padding:5px}
.tab-btn{flex:1;padding:10px 16px;border:none;border-radius:9px;background:transparent;color:var(--muted2);font-family:'Outfit',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:all .25s;display:flex;align-items:center;justify-content:center;gap:8px}
.tab-btn:hover{color:var(--text);background:var(--surface2)}
.tab-btn.active{background:linear-gradient(135deg,rgba(0,212,245,0.15),rgba(0,119,168,0.1));color:var(--accent);border:1px solid rgba(0,212,245,0.2);box-shadow:0 0 20px rgba(0,212,245,0.1)}

/* ── PANELS ── */
.tab-panel{display:none;animation:fadeUp .35s cubic-bezier(.22,1,.36,1) both}
.tab-panel.active{display:block}

/* ── CARD ── */
.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:30px;position:relative;overflow:hidden;animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--accent),var(--accent3));transform:scaleX(0);transform-origin:left;transition:transform .5s}
.card:hover::before{transform:scaleX(1)}
.card-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px;margin-bottom:24px;display:flex;align-items:center;gap:10px}
.card-title-icon{width:32px;height:32px;border-radius:8px;background:rgba(0,212,245,0.1);border:1px solid rgba(0,212,245,0.2);display:flex;align-items:center;justify-content:center;font-size:15px}

/* ── SECTION LABEL ── */
.section-label{display:flex;align-items:center;gap:10px;font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--accent2);margin:22px 0 14px}
.section-label::after{content:'';flex:1;height:1px;background:var(--border)}

/* ── GRID LAYOUT ── */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.three-col{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}

/* ── INFO FIELDS (read-only view) ── */
.info-field{margin-bottom:16px}
.info-field:last-child{margin-bottom:0}
.field-label{font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);font-weight:700;margin-bottom:7px}
.field-value{background:rgba(0,0,0,0.3);border:1.5px solid var(--border);border-radius:10px;padding:11px 14px;font-size:13.5px;color:var(--text);font-weight:500;display:flex;align-items:center;gap:10px}
.field-value .fv-icon{font-size:15px;color:var(--muted2);flex-shrink:0}
.field-empty{color:var(--muted);font-style:italic}

/* ── FORM ── */
.form-group{margin-bottom:16px}
.form-group label{display:flex;align-items:center;gap:5px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:8px}
.label-req{color:rgba(244,63,94,0.8);font-size:12px;line-height:1}
.input-wrap{position:relative}
.input-wrap .i-icon{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:14px;pointer-events:none;opacity:.5}
.form-group input,.form-group select{width:100%;padding:12px 13px 12px 38px;border-radius:10px;border:1.5px solid var(--border);background:rgba(0,0,0,0.35);color:var(--text);font-size:13.5px;font-family:'Outfit',sans-serif;outline:none;transition:all .25s;appearance:none}
.form-group input:not(.has-icon),.form-group select:not(.has-icon){padding-left:13px}
.form-group input:focus,.form-group select:focus{border-color:var(--accent);background:rgba(0,212,245,0.04);box-shadow:0 0 0 3px rgba(0,212,245,0.08)}
.form-group input::placeholder{color:rgba(90,128,152,0.5)}
.form-group select option{background:#081420;color:var(--text)}
.form-group input.valid{border-color:rgba(0,212,245,0.5)}
.form-group input.invalid{border-color:rgba(244,63,94,0.5)}
.field-hint{font-size:10.5px;color:var(--muted);margin-top:5px;padding-left:2px}

/* select arrow */
.sel-wrap{position:relative}
.sel-wrap::after{content:'▾';position:absolute;right:12px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:12px;pointer-events:none}

/* pw eye */
.pw-wrap input{padding-right:42px !important}
.pw-eye{position:absolute;right:12px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:14px;color:var(--muted);transition:color .2s;user-select:none}
.pw-eye:hover{color:var(--accent)}

/* gender toggle */
.gender-toggle{display:flex;gap:10px}
.gender-btn{flex:1;padding:11px;border:1.5px solid var(--border);border-radius:10px;background:rgba(0,0,0,.35);color:var(--muted2);font-family:'Outfit',sans-serif;font-size:13px;font-weight:500;cursor:pointer;transition:all .25s;display:flex;align-items:center;justify-content:center;gap:7px}
.gender-btn:hover{border-color:var(--border2);background:var(--surface2)}
.gender-btn.active{border-color:var(--accent);background:rgba(0,212,245,0.08);color:var(--accent);box-shadow:0 0 0 3px rgba(0,212,245,0.08)}
.gender-btn.active-f{border-color:#f472b6;background:rgba(244,114,182,0.06);color:#f472b6;box-shadow:0 0 0 3px rgba(244,114,182,0.06)}

/* strength bar */
.strength-bar{height:3px;border-radius:10px;margin-top:6px;background:var(--border);overflow:hidden;display:none}
.strength-fill{height:100%;width:0%;border-radius:10px;transition:width .35s,background .35s}

/* ── ALERT ── */
.alert{border-radius:11px;padding:13px 16px;font-size:13px;font-weight:500;margin-bottom:20px;display:flex;align-items:flex-start;gap:10px;animation:alertIn .35s cubic-bezier(.22,1,.36,1);line-height:1.5}
@keyframes alertIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.alert-success{background:rgba(0,255,204,0.08);border:1px solid rgba(0,255,204,0.25);color:var(--green)}
.alert-error{background:rgba(244,63,94,0.08);border:1px solid rgba(244,63,94,0.25);color:#fca5a5}

/* ── BTNS ── */
.btn-primary{width:100%;margin-top:6px;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#020b14;border:none;padding:13px 20px;border-radius:10px;font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1.5px;cursor:pointer;transition:all .25s;box-shadow:0 0 20px rgba(0,212,245,0.15);position:relative;overflow:hidden}
.btn-primary::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,rgba(255,255,255,0.15),transparent);opacity:0;transition:opacity .25s}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 0 35px rgba(0,212,245,0.35)}
.btn-primary:hover::before{opacity:1}
.btn-primary:active{transform:translateY(0)}

/* ── DANGER ZONE ── */
.danger-zone{background:rgba(244,63,94,0.04);border:1px solid rgba(244,63,94,0.2);border-radius:18px;padding:30px;margin-top:0;animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both}
.danger-zone .card-title{color:#f43f5e}
.danger-zone .card-title-icon{background:rgba(244,63,94,0.1);border-color:rgba(244,63,94,0.2)}
.danger-warning{background:rgba(244,63,94,0.07);border:1px solid rgba(244,63,94,0.2);border-radius:12px;padding:16px;margin-bottom:22px;font-size:13px;color:#fca5a5;line-height:1.7}
.danger-warning strong{color:#f43f5e;display:block;margin-bottom:6px;font-size:14px}
.danger-list{list-style:none;padding:0;margin:8px 0 0}
.danger-list li::before{content:'✗ ';color:#f43f5e;font-weight:700}
.btn-danger{width:100%;margin-top:6px;background:linear-gradient(135deg,#f43f5e,#be123c);color:#fff;border:none;padding:13px 20px;border-radius:10px;font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1.5px;cursor:pointer;transition:all .25s;box-shadow:0 0 20px rgba(244,63,94,0.15)}
.btn-danger:hover{transform:translateY(-2px);box-shadow:0 0 35px rgba(244,63,94,0.4)}
.btn-danger:active{transform:translateY(0)}
/* modal */
.modal-overlay{display:none;position:fixed;inset:0;z-index:9000;background:rgba(2,11,20,0.85);backdrop-filter:blur(8px);align-items:center;justify-content:center}
.modal-overlay.open{display:flex;animation:fadeUp .3s cubic-bezier(.22,1,.36,1)}
.modal-box{background:#07151f;border:1px solid rgba(244,63,94,0.3);border-radius:20px;padding:36px;max-width:440px;width:90%;position:relative;box-shadow:0 0 60px rgba(244,63,94,0.15)}
.modal-box::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,#f43f5e,#be123c);border-radius:20px 20px 0 0}
.modal-icon{font-size:48px;text-align:center;margin-bottom:16px}
.modal-title{font-family:'Bebas Neue',sans-serif;font-size:26px;color:#f43f5e;text-align:center;margin-bottom:8px;letter-spacing:1px}
.modal-sub{font-size:13px;color:var(--muted2);text-align:center;margin-bottom:22px;line-height:1.6}
.modal-actions{display:flex;gap:10px;margin-top:20px}
.btn-cancel{flex:1;padding:12px;border:1px solid var(--border);border-radius:10px;background:var(--surface);color:var(--muted2);font-family:'Outfit',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:all .25s}
.btn-cancel:hover{border-color:var(--border2);color:var(--text)}


/* ── ANIMATIONS ── */
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}

/* ── MOBILE ── */
@media(max-width:768px){
  nav{padding:0 20px}
  .welcome{display:none}
  main{padding:32px 20px}
  .two-col,.three-col{grid-template-columns:1fr}
  .profile-hero{flex-direction:column;text-align:center}
  .stats-row{justify-content:center}
  .tabs{flex-direction:column}
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>

<!-- ══ NAV ══ -->
<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">💧</div>
    AquaStock
  </a>
  <div class="nav-right">
    <div class="welcome">Bonjour, <strong><?= htmlspecialchars($_SESSION['client_name']) ?></strong></div>
    <a href="my_orders.php" class="nav-btn orders-btn">📋 Mes commandes</a>
    <a href="home.php" class="nav-btn">🛒 Boutique</a>
    <a href="../auth/logout.php" class="nav-btn logout-btn">↩ Déconnexion</a>
  </div>
</nav>

<main>

  <!-- Page Header -->
  <div class="page-header">
    <div class="page-label">Paramètres du compte</div>
    <h1 class="page-title">Mon <span>Profil</span></h1>
    <p class="page-sub">Consultez et modifiez vos informations personnelles, ou changez votre mot de passe.</p>
  </div>

  <!-- ── HERO CARD ── -->
  <div class="profile-hero">
    <div class="avatar"><?= $sexe_icon ?></div>
    <div class="hero-info">
      <div class="hero-name"><?= val($client, 'nom') ?></div>
      <div class="hero-login">
        Identifiant : <span>@<?= val($client, 'login') ?></span>
      </div>
      <div class="stats-row">
        <div class="stat-chip">
          <strong><?= $orderCount ?></strong>
          commande<?= $orderCount != 1 ? 's' : '' ?> passée<?= $orderCount != 1 ? 's' : '' ?>
        </div>
        <div class="stat-chip green">
          <strong>✓</strong> Compte actif
        </div>
        <?php if (!empty($client['sexe'])): ?>
        <div class="stat-chip pink">
          <strong><?= $sexe_icon ?></strong>
          <?= ucfirst(htmlspecialchars($client['sexe'])) ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($client['dateNaissance'])): ?>
        <div class="stat-chip">
          <strong>🎂</strong> <?= $dob_fmt ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- ── GLOBAL ALERT ── -->
  <?php if ($success): ?>
  <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- ── TABS ── -->
  <div class="tabs">
    <button class="tab-btn active" onclick="switchTab('info', this)">📋 Informations personnelles</button>
    <button class="tab-btn" onclick="switchTab('edit', this)">✏️ Modifier le profil</button>
    <button class="tab-btn" onclick="switchTab('password', this)">🔒 Mot de passe</button>
    <button class="tab-btn" onclick="switchTab('danger', this)" style="color:#f43f5e">🗑️ Supprimer le compte</button>
  </div>

  <!-- ═══════════════════════════════════════
       TAB 1 — Informations (read-only)
  ═══════════════════════════════════════ -->
  <div class="tab-panel active" id="panel-info">
    <div class="card">
      <div class="card-title"><div class="card-title-icon">📋</div> Informations personnelles</div>

      <div class="section-label">👤 Identité</div>
      <div class="two-col">
        <div class="info-field">
          <div class="field-label">Nom complet</div>
          <div class="field-value"><span class="fv-icon">👤</span><?= val($client, 'nom') ?></div>
        </div>
        <div class="info-field">
          <div class="field-label">Identifiant de connexion</div>
          <div class="field-value"><span class="fv-icon">🪪</span><?= val($client, 'login') ?></div>
        </div>
        <div class="info-field">
          <div class="field-label">Date de naissance</div>
          <div class="field-value"><span class="fv-icon">🎂</span>
            <?= !empty($client['dateNaissance']) ? $dob_fmt : '<span class="field-empty">Non renseignée</span>' ?>
          </div>
        </div>
        <div class="info-field">
          <div class="field-label">Sexe</div>
          <div class="field-value"><span class="fv-icon"><?= $sexe_icon ?></span>
            <?= !empty($client['sexe']) ? ucfirst(val($client, 'sexe')) : '<span class="field-empty">Non renseigné</span>' ?>
          </div>
        </div>
      </div>

      <div class="section-label">📞 Contact</div>
      <div class="two-col">
        <div class="info-field">
          <div class="field-label">Adresse e-mail</div>
          <div class="field-value"><span class="fv-icon">📧</span>
            <?= !empty($client['email']) ? val($client, 'email') : '<span class="field-empty">Non renseignée</span>' ?>
          </div>
        </div>
        <div class="info-field">
          <div class="field-label">Téléphone</div>
          <div class="field-value"><span class="fv-icon">📱</span>
            <?= !empty($client['telephone']) ? val($client, 'telephone') : '<span class="field-empty">Non renseigné</span>' ?>
          </div>
        </div>
      </div>

      <div class="section-label">📍 Adresse de livraison</div>
      <div class="two-col">
        <div class="info-field">
          <div class="field-label">Rue / Quartier</div>
          <div class="field-value" style="align-items:flex-start"><span class="fv-icon" style="margin-top:2px">🏠</span>
            <?= !empty($stored_adresse) ? htmlspecialchars($stored_adresse) : '<span class="field-empty">Non renseignée</span>' ?>
          </div>
        </div>
        <div class="info-field">
          <div class="field-label">Wilaya</div>
          <div class="field-value"><span class="fv-icon">📌</span>
            <?= !empty($stored_wilaya) ? htmlspecialchars($stored_wilaya) : '<span class="field-empty">Non renseignée</span>' ?>
          </div>
        </div>
      </div>

      <hr class="divider">
      <div style="font-size:12px;color:var(--muted);display:flex;align-items:center;gap:6px;">
        <span style="color:var(--accent)">ℹ</span>
        Cliquez sur l'onglet <strong style="color:var(--accent)">Modifier le profil</strong> pour mettre à jour vos informations.
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════
       TAB 2 — Edit profile
  ═══════════════════════════════════════ -->
  <div class="tab-panel" id="panel-edit">
    <div class="card">
      <div class="card-title"><div class="card-title-icon">✏️</div> Modifier le profil</div>

      <form method="POST" action="profile.php" novalidate>

        <div class="section-label">👤 Identité</div>
        <div class="two-col">
          <div class="form-group">
            <label>Nom complet <span class="label-req">*</span></label>
            <div class="input-wrap">
              <span class="i-icon">👤</span>
              <input type="text" name="nom" class="has-icon" placeholder="ex. Ahmed Benali"
                     minlength="6" required
                     value="<?= val($client, 'nom') ?>">
            </div>
            <div class="field-hint">Minimum 6 caractères</div>
          </div>
          <div class="form-group">
            <label>Nom d'utilisateur <span class="label-req">*</span></label>
            <div class="input-wrap">
              <span class="i-icon">🪪</span>
              <input type="text" name="login" id="editLogin" class="has-icon"
                     placeholder="ex. ahmed_benali" minlength="3" required
                     value="<?= val($client, 'login') ?>"
                     oninput="checkLogin(this.value)">
            </div>
            <div class="field-hint" id="loginHint">Lettres, chiffres, points, tirets, underscores</div>
          </div>
          <div class="form-group">
            <label>Date de naissance <span class="label-req">*</span></label>
            <input type="date" name="dob"
                   max="<?= date('Y-m-d', strtotime('-13 years')) ?>"
                   required
                   value="<?= val($client, 'dateNaissance') ?>">
          </div>
        </div>

        <div class="form-group">
          <label>Sexe <span class="label-req">*</span></label>
          <div class="gender-toggle">
            <button type="button"
              class="gender-btn <?= ($client['sexe'] ?? '') === 'homme' ? 'active' : '' ?>"
              onclick="selectGender('homme',this)">👨 Homme</button>
            <button type="button"
              class="gender-btn <?= ($client['sexe'] ?? '') === 'femme' ? 'active-f' : '' ?>"
              onclick="selectGender('femme',this)">👩 Femme</button>
          </div>
          <input type="hidden" name="sexe" id="editSexe" value="<?= val($client, 'sexe') ?>">
        </div>

        <div class="section-label">📞 Contact</div>
        <div class="two-col">
          <div class="form-group">
            <label>Adresse e-mail <span class="label-req">*</span></label>
            <div class="input-wrap">
              <span class="i-icon">📧</span>
              <input type="email" name="email" class="has-icon"
                     placeholder="nom@domaine.com" required
                     value="<?= val($client, 'email') ?>">
            </div>
          </div>
          <div class="form-group">
            <label>Téléphone <span class="label-req">*</span></label>
            <div class="input-wrap">
              <span class="i-icon">📱</span>
              <input type="tel" name="telephone" id="editTel" class="has-icon"
                     placeholder="0555 000 000" maxlength="10"
                     pattern="0[5-7][0-9]{8}" required
                     value="<?= val($client, 'telephone') ?>">
            </div>
            <div class="field-hint" id="telHint">10 chiffres — 05, 06 ou 07</div>
          </div>
        </div>

        <div class="section-label">📍 Adresse de livraison</div>
        <div class="two-col">
          <div class="form-group">
            <label>Rue / Quartier <span class="label-req">*</span></label>
            <div class="input-wrap">
              <span class="i-icon">🏠</span>
              <input type="text" name="adresse" class="has-icon"
                     placeholder="N° rue, cité, quartier…" required
                     value="<?= htmlspecialchars($stored_adresse) ?>">
            </div>
          </div>
          <div class="form-group">
            <label>Wilaya <span class="label-req">*</span></label>
            <div class="sel-wrap">
              <select name="wilaya" required>
                <option value="" disabled <?= empty($stored_wilaya) ? 'selected' : '' ?>>— Sélectionnez —</option>
                <?php foreach ($wilayas as $w): ?>
                <option value="<?= htmlspecialchars($w) ?>"
                  <?= ($stored_wilaya === $w) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($w) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>

        <button type="submit" name="update_profile" class="btn-primary">
          💾 Enregistrer les modifications
        </button>
      </form>
    </div>
  </div>

  <!-- ═══════════════════════════════════════
       TAB 3 — Password
  ═══════════════════════════════════════ -->
  <div class="tab-panel" id="panel-password">
    <div class="card">
      <div class="card-title"><div class="card-title-icon">🔒</div> Changer le mot de passe</div>

      <form method="POST" action="profile.php" id="pwdForm">
        <div class="form-group">
          <label>Mot de passe actuel <span class="label-req">*</span></label>
          <div class="input-wrap pw-wrap">
            <span class="i-icon">🔑</span>
            <input type="password" name="current_password" id="curPwd" class="has-icon"
                   placeholder="Votre mot de passe actuel" required autocomplete="current-password">
            <span class="pw-eye" onclick="togglePw('curPwd',this)">👁</span>
          </div>
        </div>

        <div class="form-group">
          <label>Nouveau mot de passe <span class="label-req">*</span></label>
          <div class="input-wrap pw-wrap">
            <span class="i-icon">🔑</span>
            <input type="password" name="new_password" id="newPwd" class="has-icon"
                   placeholder="Minimum 6 caractères" required autocomplete="new-password"
                   oninput="checkStrength(this.value)">
            <span class="pw-eye" onclick="togglePw('newPwd',this)">👁</span>
          </div>
          <div class="strength-bar" id="strengthBar"><div class="strength-fill" id="strengthFill"></div></div>
          <div class="field-hint" id="strengthLabel">Force du mot de passe</div>
        </div>

        <div class="form-group">
          <label>Confirmer le nouveau mot de passe <span class="label-req">*</span></label>
          <div class="input-wrap pw-wrap">
            <span class="i-icon">🔑</span>
            <input type="password" name="confirm_password" id="confirmPwd" class="has-icon"
                   placeholder="Répétez le nouveau mot de passe" required autocomplete="new-password"
                   oninput="checkMatch()">
            <span class="pw-eye" onclick="togglePw('confirmPwd',this)">👁</span>
          </div>
          <div class="field-hint" id="matchHint"></div>
        </div>

        <button type="submit" name="change_password" class="btn-primary">
          🔐 Mettre à jour le mot de passe
        </button>
      </form>

      <hr class="divider">
      <div style="font-size:12px;color:var(--muted);line-height:1.6">
        <span style="color:var(--yellow)">💡</span>
        Choisissez un mot de passe d'au moins 6 caractères mélangeant lettres, chiffres et symboles.
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════
       TAB 4 — Danger Zone
  ═══════════════════════════════════════ -->
  <div class="tab-panel" id="panel-danger">
    <div class="danger-zone">
      <div class="card-title"><div class="card-title-icon">🗑️</div> Supprimer mon compte</div>

      <div class="danger-warning">
        <strong>⚠️ Cette action est irréversible !</strong>
        En supprimant votre compte, vous perdrez définitivement :
        <ul class="danger-list">
          <li>Toutes vos commandes passées</li>
          <li>Toutes vos factures</li>
          <li>Vos informations personnelles</li>
          <li>Votre historique d'achats</li>
        </ul>
      </div>

      <div class="form-group">
        <label>Confirmez votre identité</label>
        <div class="field-value" style="margin-bottom:0;border-color:rgba(244,63,94,0.2)">
          <span class="fv-icon">👤</span>
          <?= val($client, 'nom') ?> — <?= val($client, 'email') ?>
        </div>
      </div>

      <button type="button" class="btn-danger" onclick="openDeleteModal()">
        🗑️ Supprimer définitivement mon compte
      </button>
    </div>
  </div>

</main>

<!-- ══ DELETE MODAL ══ -->
<div class="modal-overlay" id="deleteModal">
  <div class="modal-box">
    <div class="modal-icon">⚠️</div>
    <div class="modal-title">Confirmer la suppression</div>
    <div class="modal-sub">
      Cette action supprimera votre compte, toutes vos commandes et factures.<br>
      Entrez votre mot de passe pour confirmer.
    </div>

    <form method="POST" action="<?= htmlspecialchars(dirname(dirname($_SERVER['PHP_SELF']))) ?>/actions/delete_account_client.php">
      <div class="form-group">
        <label>Mot de passe <span class="label-req">*</span></label>
        <div class="input-wrap pw-wrap">
          <span class="i-icon">🔑</span>
          <input type="password" name="confirm_password_delete" id="delPwd"
                 class="has-icon" placeholder="Votre mot de passe actuel" required autocomplete="current-password">
          <span class="pw-eye" onclick="togglePw('delPwd',this)">👁</span>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeDeleteModal()">Annuler</button>
        <button type="submit" class="btn-danger" style="flex:1;margin-top:0">🗑️ Confirmer</button>
      </div>
    </form>
  </div>
</div>


<script>
// ── Open/close delete modal
function openDeleteModal()  { document.getElementById('deleteModal').classList.add('open'); }
function closeDeleteModal() { document.getElementById('deleteModal').classList.remove('open'); }
document.getElementById('deleteModal').addEventListener('click', function(e) {
  if (e.target === this) closeDeleteModal();
});

// ── Auto-open danger tab if delete error
<?php if ($error && isset($_SESSION['delete_error_tab'])): unset($_SESSION['delete_error_tab']); ?>
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn')[3].click();
});
<?php endif; ?>

// ── Scroll line
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? window.scrollY / h * 100 : 100) + '%';
}, { passive: true });

// ── Nav bg
const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40 ? 'rgba(2,11,20,0.97)' : 'rgba(2,11,20,0.85)';
}, { passive: true });

// ── Tabs
function switchTab(id, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('panel-' + id).classList.add('active');
}

// ── Open edit/password tab automatically if form had an error on that tab
<?php if ($error && isset($_POST['update_profile'])): ?>
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn')[1].click();
});
<?php elseif ($error && isset($_POST['change_password'])): ?>
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn')[2].click();
});
<?php endif; ?>

// ── Gender selector
function selectGender(val, btn) {
  document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('active', 'active-f'));
  btn.classList.add(val === 'homme' ? 'active' : 'active-f');
  document.getElementById('editSexe').value = val;
}

// ── Login validator
function checkLogin(val) {
  const input = document.getElementById('editLogin');
  const hint  = document.getElementById('loginHint');
  const ok    = /^[a-zA-Z0-9._-]{3,}$/.test(val);
  input.classList.toggle('valid',   val.length >= 3 && ok);
  input.classList.toggle('invalid', val.length > 0 && !ok);
  hint.textContent = val.length === 0
    ? 'Lettres, chiffres, points, tirets, underscores'
    : ok
      ? '✓ Nom d\'utilisateur valide'
      : val.length < 3
        ? 'Minimum 3 caractères'
        : 'Caractères non autorisés';
  hint.style.color = (val.length >= 3 && ok) ? '#00ffcc' : (val.length > 0 ? '#fca5a5' : 'var(--muted)');
}

// ── Phone: digits only
document.getElementById('editTel').addEventListener('input', function () {
  this.value = this.value.replace(/\D/g, '').slice(0, 10);
  const ok = /^0[5-7][0-9]{8}$/.test(this.value);
  const h  = document.getElementById('telHint');
  this.classList.toggle('valid', ok);
  this.classList.toggle('invalid', this.value.length > 0 && !ok);
  h.textContent  = ok ? '✓ Numéro valide' : '10 chiffres — commence par 05, 06 ou 07';
  h.style.color  = ok ? '#00ffcc' : (this.value.length > 0 ? '#fca5a5' : 'var(--muted)');
});

// ── Password toggle
function togglePw(id, btn) {
  const f = document.getElementById(id);
  f.type = f.type === 'password' ? 'text' : 'password';
  if (btn) btn.textContent = f.type === 'password' ? '👁' : '🙈';
}

// ── Password strength
function checkStrength(val) {
  const bar   = document.getElementById('strengthBar');
  const fill  = document.getElementById('strengthFill');
  const label = document.getElementById('strengthLabel');
  bar.style.display = val.length > 0 ? 'block' : 'none';
  let score = 0;
  if (val.length >= 6)           score++;
  if (val.length >= 10)          score++;
  if (/[A-Z]/.test(val))         score++;
  if (/[0-9]/.test(val))         score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const levels = [
    { w: '20%', c: '#f43f5e', t: 'Très faible' },
    { w: '40%', c: '#f97316', t: 'Faible'      },
    { w: '60%', c: '#fbbf24', t: 'Moyen'       },
    { w: '80%', c: '#00d4f5', t: 'Fort'        },
    { w: '100%',c: '#00ffcc', t: 'Très fort'   },
  ];
  const l = levels[Math.min(score, 4)];
  fill.style.width      = l.w;
  fill.style.background = l.c;
  label.textContent     = l.t;
  label.style.color     = l.c;
  checkMatch();
}

// ── Password match
function checkMatch() {
  const np = document.getElementById('newPwd');
  const cp = document.getElementById('confirmPwd');
  const h  = document.getElementById('matchHint');
  if (!cp.value) { h.textContent = ''; cp.classList.remove('valid','invalid'); return; }
  const ok = np.value === cp.value && cp.value.length >= 6;
  cp.classList.toggle('valid',   ok);
  cp.classList.toggle('invalid', !ok);
  h.textContent = ok ? '✓ Les mots de passe correspondent' : '✗ Ne correspondent pas';
  h.style.color = ok ? '#00ffcc' : '#fca5a5';
}
</script>
</body>
</html>