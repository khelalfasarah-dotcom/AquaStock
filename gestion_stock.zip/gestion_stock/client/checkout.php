<?php
// checkout.php — validates session + cart, stores pending order in session
// The actual order/invoice/stock creation happens ONLY in final_confirm.php
session_start();

if (!isset($_SESSION['client_name'])) { header("Location: ../auth/login_client.php"); exit(); }
if (!isset($_SESSION['client_id'])) {
    session_destroy();
    header("Location: ../auth/login_client.php?error=session_expired"); exit();
}
if (empty($_SESSION['cart'])) {
    header("Location: payment.php"); exit();
}

// Store cart snapshot in session for payment_methods.php to display total
$cart = $_SESSION['cart'];
$totalTTC = 0;
foreach ($cart as $item) { $totalTTC += $item['qty_fardeaux'] * $item['prix_fardeau']; }
$timbre  = 25.00;
$totalHT = round(($totalTTC - $timbre) / 1.19, 2);
$tva     = round($totalTTC - $timbre - $totalHT, 2);

$_SESSION['pending_order'] = [
    'cart'    => $cart,
    'totalHT' => $totalHT,
    'tva'     => $tva,
    'timbre'  => $timbre,
    'ttc'     => $totalTTC,
];

// Clear any stale order id from a previous incomplete session
unset($_SESSION['active_order_id']);

header("Location: payment_methods.php"); exit();
?>
