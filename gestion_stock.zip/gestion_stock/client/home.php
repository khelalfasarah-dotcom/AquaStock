<?php
session_start();
include "../config/db.php";
if (!isset($_SESSION['client_name'])) { header("Location: ../auth/login_client.php"); exit(); }
$result = $conn->query("SELECT * FROM produit ORDER BY idProduit");
if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }
$cartCount = array_sum(array_column($_SESSION['cart'], 'qty_fardeaux'));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Boutique — NAQAA</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --yellow:  #fbbf24;
  --red:     #f43f5e;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
}

/* ─── SCROLLBAR ─── */
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom, var(--accent2), var(--accent), var(--accent3));
  border-radius:10px; box-shadow:0 0 8px rgba(0,212,245,0.5);
}
::-webkit-scrollbar-thumb:hover {
  background:linear-gradient(to bottom, var(--accent), var(--accent3));
  box-shadow:0 0 14px rgba(0,212,245,0.8);
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

/* ─── SCROLL LINE ─── */
.scroll-line {
  position:fixed; top:0; left:0; z-index:999; pointer-events:none;
  height:3px; width:0%;
  background:linear-gradient(90deg, var(--accent2), var(--accent), var(--accent3));
  box-shadow:0 0 20px var(--accent), 0 0 40px rgba(0,212,245,0.4);
  border-radius:0 2px 2px 0;
  transition:width 0.1s linear;
}

/* ─── AMBIENT ─── */
.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 50% at 50% 0%, rgba(0,119,168,0.2) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 90% 80%, rgba(0,212,245,0.06) 0%, transparent 50%);
}

/* ─── GRID BG ─── */
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}

/* ─── NOISE ─── */
body::before {
  content:''; position:fixed; inset:0; z-index:1; pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");
  opacity:0.35;
}

/* ─── NAV ─── */
nav {
  position:sticky; top:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px; height:70px;
  background:rgba(2,11,20,0.85);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  transition:background 0.3s;
}
.nav-brand {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px; color:var(--text);
  text-decoration:none;
}
.nav-brand-icon {
  width:38px; height:38px; border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center; font-size:18px;
  box-shadow:0 0 20px rgba(0,212,245,0.4);
}
.nav-right { display:flex; align-items:center; gap:10px; }
.welcome { font-size:13px; color:var(--muted2); margin-right:6px; }
.welcome strong { color:var(--text); font-weight:600; }

.nav-btn {
  display:flex; align-items:center; gap:7px;
  padding:9px 16px; border-radius:9px; text-decoration:none;
  font-weight:600; font-size:12px; transition:all .25s;
  border:1px solid var(--border); color:var(--muted2);
  background:var(--surface);
}
.nav-btn:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-1px); }

.cart-btn {
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  border-color:transparent; color:#020b14 !important; font-weight:700 !important;
  position:relative;
  box-shadow:0 0 20px rgba(0,212,245,0.2);
}
.cart-btn:hover { box-shadow:0 0 35px rgba(0,212,245,0.4) !important; transform:translateY(-2px) !important; }
.cart-badge {
  position:absolute; top:-8px; right:-8px;
  background:var(--red); color:#fff; border-radius:50%;
  width:20px; height:20px; display:flex; align-items:center; justify-content:center;
  font-size:10px; font-weight:700; border:2px solid var(--bg);
  animation:badgePop .3s cubic-bezier(.22,1,.36,1);
}
@keyframes badgePop { from{transform:scale(0)} to{transform:scale(1)} }

.orders-btn { border-color:rgba(0,255,204,0.2); color:var(--green) !important; background:rgba(0,255,204,0.05); }
.orders-btn:hover { background:rgba(0,255,204,0.1) !important; border-color:rgba(0,255,204,0.4) !important; }

.profile-btn { border-color:rgba(0,212,245,0.3); color:var(--accent) !important; background:rgba(0,212,245,0.07); }
.profile-btn:hover { background:rgba(0,212,245,0.12) !important; border-color:var(--accent) !important; }

.logout-btn:hover { color:var(--red) !important; border-color:rgba(244,63,94,0.3) !important; }

/* ─── MAIN ─── */
main { position:relative; z-index:10; padding:52px 56px; }

/* ─── PAGE HEADER ─── */
.page-header { margin-bottom:48px; }
.page-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:14px;
  display:flex; align-items:center; gap:8px;
}
.page-label::before { content:''; width:24px; height:1px; background:var(--accent); }
.page-title {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(40px,5vw,64px); letter-spacing:1px; line-height:0.95;
  margin-bottom:14px;
}
.page-title span { color:var(--accent); }
.page-sub { font-size:14px; color:var(--muted2); font-weight:300; line-height:1.7; max-width:520px; }

/* ─── GRID ─── */
.products-grid {
  display:grid;
  grid-template-columns:repeat(auto-fill, minmax(290px,1fr));
  gap:20px;
}

/* ─── PRODUCT CARD ─── */
.product-card {
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:16px; overflow:hidden;
  transition:all .35s;
  position:relative;
  animation:fadeUp .6s cubic-bezier(.22,1,.36,1) both;
}
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

.product-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:2px;
  background:linear-gradient(90deg, var(--accent), var(--accent3));
  transform:scaleX(0); transform-origin:left; transition:transform .4s;
}
.product-card:hover::before { transform:scaleX(1); }
.product-card:hover {
  border-color:var(--border2);
  background:var(--surface2);
  transform:translateY(-5px);
  box-shadow:0 24px 50px rgba(0,0,0,0.4), 0 0 30px rgba(0,212,245,0.08);
}

.product-top {
  background:
    radial-gradient(ellipse 80% 60% at 50% 100%, rgba(0,119,168,0.18) 0%, transparent 70%),
    linear-gradient(160deg, rgba(0,212,245,0.06), rgba(0,119,168,0.03));
  padding:40px 24px 32px;
  text-align:center;
  border-bottom:1px solid var(--border);
  position:relative;
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  min-height:160px;
}

.product-body { padding:22px; }

.product-name {
  font-family:'Bebas Neue',sans-serif;
  font-size:22px; letter-spacing:0.5px; margin-bottom:6px;
}
.product-vol {
  display:inline-block;
  background:rgba(0,212,245,0.08); color:var(--accent);
  padding:3px 12px; border-radius:100px; font-size:11px;
  border:1px solid rgba(0,212,245,0.2); margin-bottom:14px;
  font-weight:600; letter-spacing:0.5px;
}

.fardeau-info {
  background:rgba(0,212,245,0.04);
  border:1px solid rgba(0,212,245,0.1);
  border-radius:9px; padding:10px 14px;
  margin-bottom:16px; font-size:12px; color:var(--muted);
}
.fardeau-info span { color:var(--text); font-weight:600; }

.price-row {
  display:flex; justify-content:space-between;
  align-items:flex-end; margin-bottom:18px;
}
.price {
  font-family:'Bebas Neue',sans-serif;
  font-size:26px; letter-spacing:0.5px; color:var(--accent); line-height:1;
}
.price small {
  font-family:'Outfit',sans-serif;
  font-size:11px; color:var(--muted); display:block;
  font-weight:400; margin-top:3px; letter-spacing:0;
}


.qty-label {
  font-size:10px; color:var(--muted); text-transform:uppercase;
  letter-spacing:1.2px; font-weight:700; margin-bottom:8px;
}
.qty-row { display:flex; gap:8px; }
.qty-input {
  flex:1; background:rgba(0,0,0,0.35);
  border:1.5px solid var(--border); border-radius:9px;
  padding:10px 12px; color:var(--text);
  font-size:14px; font-family:'Outfit',sans-serif;
  outline:none; transition:all .25s;
}
.qty-input:focus {
  border-color:var(--accent);
  box-shadow:0 0 0 3px rgba(0,212,245,0.1);
  background:rgba(0,212,245,0.03);
}
.add-btn {
  background:linear-gradient(135deg, var(--accent), var(--accent2));
  color:#020b14; border:none; padding:10px 16px; border-radius:9px;
  font-weight:700; cursor:pointer; font-size:13px;
  font-family:'Outfit',sans-serif; transition:all .25s;
  white-space:nowrap;
  box-shadow:0 0 16px rgba(0,212,245,0.15);
}
.add-btn:hover { transform:translateY(-2px); box-shadow:0 0 28px rgba(0,212,245,0.35); }
.add-btn:disabled { opacity:.35; cursor:not-allowed; transform:none; box-shadow:none; }

/* ─── EMPTY STATE ─── */
.empty {
  grid-column:1/-1; text-align:center;
  padding:80px 20px; color:var(--muted);
}
.empty-icon { font-size:48px; margin-bottom:16px; }
.empty p { font-size:15px; }

/* ─── MOBILE ─── */
@media(max-width:768px){
  nav { padding:0 20px; }
  .welcome { display:none; }
  main { padding:32px 20px; }
}
</style>
</head>
<body>

<div class="scroll-line" id="scrollLine"></div>
<div class="ambient"></div>
<div class="grid-bg"></div>

<nav id="mainNav">
  <a href="home.php" class="nav-brand">
    <div class="nav-brand-icon">
      <svg width="26" height="26" viewBox="0 0 120 150" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="navDrop" cx="35%" cy="25%" r="65%">
            <stop offset="0%" stop-color="#5dd8f0"/><stop offset="60%" stop-color="#0e90c4"/><stop offset="100%" stop-color="#003d6b"/>
          </radialGradient>
        </defs>
        <path d="M60,6 C92,40 100,66 100,82 C100,104 82,118 60,118 C38,118 20,104 20,82 C20,66 28,40 60,6 Z" fill="url(#navDrop)"/>
        <path d="M40,28 C44,44 45,66 43,82 C41,92 36,100 31,96 C26,90 27,72 33,54 Z" fill="white" opacity="0.22"/>
        <text x="60" y="96" text-anchor="middle" font-family="Georgia,serif" font-size="52" font-weight="700" fill="white" opacity="0.97">N</text>
      </svg>
    </div>
    NAQAA
  </a>
  <div class="nav-right">
    <div class="welcome">Bonjour, <strong><?= htmlspecialchars($_SESSION['client_name']) ?></strong></div>
    <a href="profile.php" class="nav-btn profile-btn">👤 Mon profil</a>
    <a href="my_orders.php"   class="nav-btn orders-btn">📋 Mes commandes</a>
    <a href="payment.php" class="nav-btn cart-btn">
      🛒 Panier
      <?php if($cartCount > 0): ?>
        <span class="cart-badge"><?= $cartCount ?></span>
      <?php endif; ?>
    </a>
    <a href="../auth/index.php" class="nav-btn logout-btn">↩ Déconnexion</a>
  </div>
</nav>

<main>
  <div class="page-header">
    <div class="page-label">Boutique en ligne</div>
    <h1 class="page-title">Nos <span>Produits</span></h1>
    <p class="page-sub">Commandez par fardeau — choisissez votre produit et la quantité de fardeaux souhaités.</p>
  </div>

  <div class="products-grid">
  <?php
  $i = 0;
  while($row = $result->fetch_assoc()):
    $bpf         = (int)$row['btParFardeau'];
    $prixFardeau = $row['prixFardeau'];
    $i++;
  ?>
  <div class="product-card" style="animation-delay:<?= $i * 0.08 ?>s">
    <div class="product-top">

      <?php
        $pid = $row['idProduit'];
        $vol = strtolower(trim($row['volume']));
        $vol = str_replace(',', '.', $vol);
        if (strpos($vol,'19') !== false) {
          // ── BONBONNE 19L ──
          echo '<svg width="80" height="110" viewBox="0 0 80 110" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg19b_'.$pid.'" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#9dd4ea"/>
                <stop offset="32%" stop-color="#ddf3fc"/>
                <stop offset="100%" stop-color="#7abdd8"/>
              </linearGradient>
              <linearGradient id="label19b_'.$pid.'" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0077a8"/>
                <stop offset="100%" stop-color="#002f54"/>
              </linearGradient>
              <linearGradient id="cap19b_'.$pid.'" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#00ffcc"/>
                <stop offset="100%" stop-color="#00c8a0"/>
              </linearGradient>
              <clipPath id="cp19b_'.$pid.'">
                <path d="M9,34 Q9,25 14,21 L14,12 Q14,7 19,7 L35,7 Q40,7 40,12 L40,21 Q45,25 45,34 L45,84 Q45,100 27,102 Q9,100 9,84 Z"/>
              </clipPath>
            </defs>
            <ellipse cx="27" cy="108" rx="22" ry="4" fill="#000" opacity="0.12"/>
            <path d="M9,34 Q9,25 14,21 L14,12 Q14,7 19,7 L35,7 Q40,7 40,12 L40,21 Q45,25 45,34 L45,84 Q45,100 27,102 Q9,100 9,84 Z" fill="url(#bg19b_'.$pid.')" stroke="#6ecef0" stroke-width="0.6"/>
            <rect x="9" y="63" width="36" height="39" fill="#29aedb" opacity="0.42" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="43" width="36" height="26" fill="url(#label19b_'.$pid.')" opacity="0.95" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="43" width="36" height="7" fill="white" opacity="0.08" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="43" width="36" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="68" width="36" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="43" width="6" height="26" fill="white" opacity="0.06" clip-path="url(#cp19b_'.$pid.')"/>
            <g clip-path="url(#cp19b_'.$pid.')">
              <defs>
                <radialGradient id="lgBon_'.$pid.'" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="dsBon_'.$pid.'" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <path d="M27,45.5 C31.8,50.5 33.5,54 33.5,56.5 C33.5,60.2 30.6,62.8 27,62.8 C23.4,62.8 20.5,60.2 20.5,56.5 C20.5,54 22.2,50.5 27,45.5 Z" fill="url(#lgBon_'.$pid.')" filter="url(#dsBon_'.$pid.')"/>
              <path d="M23.8,48.5 C24.5,51.2 24.6,54.5 24.3,56.8 C24,58.3 23.2,59.4 22.5,59.1 C21.6,58.5 21.7,56 22.7,53.3 Z" fill="white" opacity="0.30"/>
              <text x="27" y="60.5" text-anchor="middle" font-family="Georgia,serif" font-size="10" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <text x="27" y="65" text-anchor="middle" font-family="Bebas Neue,Arial Narrow,sans-serif" font-size="6.5" fill="white" letter-spacing="2" opacity="0.97" clip-path="url(#cp19b_'.$pid.')">NAQAA</text>
            <text x="27" y="67.5" text-anchor="middle" font-family="Amiri,Traditional Arabic,Arial Unicode MS,serif" font-size="5" fill="#7ad4ef" opacity="0.90" clip-path="url(#cp19b_'.$pid.')">نقاء</text>
            <rect x="9" y="38" width="36" height="2.5" rx="1.25" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="9" y="41" width="36" height="1.5" rx="0.75" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp19b_'.$pid.')"/>
            <rect x="14" y="27" width="4" height="70" rx="2" fill="white" opacity="0.24"/>
            <rect x="20" y="27" width="1.5" height="38" rx="0.75" fill="white" opacity="0.1"/>
            <rect x="12" y="20" width="30" height="5" rx="2.5" fill="#00d4f5" opacity="0.45"/>
            <path d="M9,86 Q9,100 27,102 Q45,100 45,86 L45,93 Q45,107 27,109 Q9,107 9,93 Z" fill="#005f87" opacity="0.28"/>
            <circle cx="40" cy="94" r="7" fill="#00d4f5" opacity="0.18" stroke="#00d4f5" stroke-width="0.8"/>
            <text x="40" y="97" text-anchor="middle" font-family="sans-serif" font-size="8" fill="#00d4f5">♻</text>
            <rect x="17" y="1" width="20" height="9" rx="4.5" fill="url(#cap19b_'.$pid.')"/>
            <rect x="17" y="7" width="20" height="3" fill="#00a87a"/>
            <rect x="18.5" y="1.5" width="5" height="4" rx="2" fill="white" opacity="0.35"/>
          </svg>';
        } elseif (strpos($vol,'1.5') !== false) {
          // ── 1.5L (exact from index.php: 28x74) ──
          echo '<svg width="28" height="74" viewBox="0 0 28 74" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg15_'.$pid.'" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#b8e4f6"/>
                <stop offset="38%" stop-color="#e0f5fd"/>
                <stop offset="100%" stop-color="#8fcfe8"/>
              </linearGradient>
              <linearGradient id="label15_'.$pid.'" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#003f6b"/>
              </linearGradient>
              <clipPath id="cp15_'.$pid.'">
                <path d="M3,15 Q3,11 7,9 L7,4.5 Q7,2 10,2 L18,2 Q21,2 21,4.5 L21,9 Q25,11 25,15 L25,63 Q25,67 21,67 L7,67 Q3,67 3,63 Z"/>
              </clipPath>
            </defs>
            <ellipse cx="14" cy="72" rx="10" ry="2" fill="#000" opacity="0.11"/>
            <path d="M3,15 Q3,11 7,9 L7,4.5 Q7,2 10,2 L18,2 Q21,2 21,4.5 L21,9 Q25,11 25,15 L25,63 Q25,67 21,67 L7,67 Q3,67 3,63 Z" fill="url(#bg15_'.$pid.')" stroke="#6ecef0" stroke-width="0.45"/>
            <rect x="3" y="43" width="22" height="24" fill="#29aedb" opacity="0.4" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="27" width="22" height="20" fill="url(#label15_'.$pid.')" opacity="0.95" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="27" width="22" height="5" fill="white" opacity="0.08" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="27" width="22" height="1" fill="#00d4f5" opacity="0.9" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="46" width="22" height="1" fill="#00d4f5" opacity="0.9" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="27" width="3.5" height="20" fill="white" opacity="0.06" clip-path="url(#cp15_'.$pid.')"/>
            <g clip-path="url(#cp15_'.$pid.')">
              <defs>
                <radialGradient id="lg15_'.$pid.'" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds15_'.$pid.'" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="0.8" stdDeviation="1" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <path d="M14,29.5 C17.5,33.2 18.8,35.8 18.8,37.4 C18.8,39.7 16.7,41.3 14,41.3 C11.3,41.3 9.2,39.7 9.2,37.4 C9.2,35.8 10.5,33.2 14,29.5 Z" fill="url(#lg15_'.$pid.')" filter="url(#ds15_'.$pid.')"/>
              <path d="M11.8,31.2 C12.3,33 12.4,35.2 12.1,37 C11.9,38.1 11.3,38.9 10.8,38.6 C10.2,38.2 10.2,36.5 10.8,34.7 Z" fill="white" opacity="0.28"/>
              <text x="14" y="39.5" text-anchor="middle" font-family="Georgia,serif" font-size="6.5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <text x="14" y="43.8" text-anchor="middle" font-family="Bebas Neue,Arial Narrow,sans-serif" font-size="4.8" fill="white" letter-spacing="1.5" opacity="0.97" clip-path="url(#cp15_'.$pid.')">NAQAA</text>
            <text x="14" y="46" text-anchor="middle" font-family="Amiri,Traditional Arabic,Arial Unicode MS,serif" font-size="3.6" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp15_'.$pid.')">نقاء</text>
            <rect x="3" y="23" width="22" height="1.5" rx="0.75" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="3" y="25.5" width="22" height="1" rx="0.5" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="6" y="12" width="2.5" height="48" rx="1.25" fill="white" opacity="0.28"/>
            <rect x="9.5" y="12" width="1" height="26" rx="0.5" fill="white" opacity="0.11"/>
            <rect x="3" y="62" width="22" height="5" fill="#005f87" opacity="0.28" clip-path="url(#cp15_'.$pid.')"/>
            <rect x="8.5" y="0" width="11" height="5.5" rx="2.2" fill="#00d4f5"/>
            <rect x="8.5" y="3.5" width="11" height="2" fill="#0099bb"/>
            <rect x="9.5" y="0.8" width="3" height="2.2" rx="1" fill="white" opacity="0.35"/>
          </svg>';
        } elseif (preg_match('/^5/', $vol) && strpos($vol,'0.5') === false && strpos($vol,'1.5') === false) {
          // ── 5L (exact from index.php: 44x88) ──
          echo '<svg width="44" height="88" viewBox="0 0 44 88" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg5L_'.$pid.'" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#aaddf0"/>
                <stop offset="35%" stop-color="#dff4fc"/>
                <stop offset="100%" stop-color="#85c8e3"/>
              </linearGradient>
              <linearGradient id="label5L_'.$pid.'" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0077a8"/>
                <stop offset="100%" stop-color="#003356"/>
              </linearGradient>
              <linearGradient id="handle5L_'.$pid.'" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#00d4f5"/>
              </linearGradient>
              <clipPath id="cp5L_'.$pid.'">
                <path d="M4,21 Q4,15 10,12 L10,6 Q10,3 14,3 L26,3 Q30,3 30,6 L30,12 Q36,15 36,21 L36,76 Q36,82 30,82 L10,82 Q4,82 4,76 Z"/>
              </clipPath>
            </defs>
            <ellipse cx="20" cy="86" rx="16" ry="2.5" fill="#000" opacity="0.11"/>
            <path d="M4,21 Q4,15 10,12 L10,6 Q10,3 14,3 L26,3 Q30,3 30,6 L30,12 Q36,15 36,21 L36,76 Q36,82 30,82 L10,82 Q4,82 4,76 Z" fill="url(#bg5L_'.$pid.')" stroke="#6ecef0" stroke-width="0.5"/>
            <rect x="4" y="53" width="32" height="29" fill="#29aedb" opacity="0.4" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="33" width="32" height="24" fill="url(#label5L_'.$pid.')" opacity="0.95" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="33" width="32" height="6" fill="white" opacity="0.08" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="33" width="32" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="55.8" width="32" height="1.2" fill="#00d4f5" opacity="0.9" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="33" width="5" height="24" fill="white" opacity="0.06" clip-path="url(#cp5L_'.$pid.')"/>
            <g clip-path="url(#cp5L_'.$pid.')">
              <defs>
                <radialGradient id="lg5L_'.$pid.'" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds5L_'.$pid.'" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <path d="M20,35.5 C24.5,40 26.2,43.2 26.2,45.2 C26.2,48.3 23.4,50.5 20,50.5 C16.6,50.5 13.8,48.3 13.8,45.2 C13.8,43.2 15.5,40 20,35.5 Z" fill="url(#lg5L_'.$pid.')" filter="url(#ds5L_'.$pid.')"/>
              <path d="M17,38 C17.6,40.3 17.7,43 17.4,45.2 C17.1,46.6 16.3,47.6 15.7,47.3 C14.9,46.8 14.9,44.6 15.8,42.3 Z" fill="white" opacity="0.28"/>
              <text x="20" y="48" text-anchor="middle" font-family="Georgia,serif" font-size="8.5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <text x="20" y="53.5" text-anchor="middle" font-family="Bebas Neue,Arial Narrow,sans-serif" font-size="6" fill="white" letter-spacing="2" opacity="0.97" clip-path="url(#cp5L_'.$pid.')">NAQAA</text>
            <text x="20" y="55.5" text-anchor="middle" font-family="Amiri,Traditional Arabic,Arial Unicode MS,serif" font-size="4.5" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp5L_'.$pid.')">نقاء</text>
            <rect x="4" y="28" width="32" height="2" rx="1" fill="#7ad4ef" opacity="0.28" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="4" y="31" width="32" height="1.2" rx="0.6" fill="#7ad4ef" opacity="0.18" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="8" y="16" width="3.5" height="60" rx="1.75" fill="white" opacity="0.26"/>
            <rect x="13" y="16" width="1.5" height="32" rx="0.75" fill="white" opacity="0.1"/>
            <path d="M36,32 Q44,32 44,42 Q44,52 36,52" fill="none" stroke="url(#handle5L_'.$pid.')" stroke-width="3" stroke-linecap="round"/>
            <rect x="4" y="77" width="32" height="5" fill="#005f87" opacity="0.28" clip-path="url(#cp5L_'.$pid.')"/>
            <rect x="12" y="0" width="16" height="7" rx="2.8" fill="#00d4f5"/>
            <rect x="12" y="4.5" width="16" height="2.5" fill="#0099bb"/>
            <rect x="13.5" y="1" width="4" height="3" rx="1.5" fill="white" opacity="0.35"/>
          </svg>';
        } else {
          // ── 0.5L (exact from index.php: 22x58) ──
          echo '<svg width="22" height="58" viewBox="0 0 22 58" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="bg05_'.$pid.'" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#c8ecf8"/>
                <stop offset="40%" stop-color="#e8f7fd"/>
                <stop offset="100%" stop-color="#9fd8ef"/>
              </linearGradient>
              <linearGradient id="label05_'.$pid.'" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stop-color="#0088bb"/>
                <stop offset="100%" stop-color="#003f6b"/>
              </linearGradient>
              <clipPath id="cp05_'.$pid.'">
                <path d="M4,11 Q4,8 7,7 L7,3.5 Q7,1.5 9,1.5 L13,1.5 Q15,1.5 15,3.5 L15,7 Q18,8 18,11 L18,49 Q18,52 15,52 L7,52 Q4,52 4,49 Z"/>
              </clipPath>
            </defs>
            <ellipse cx="11" cy="56.5" rx="6.5" ry="1.5" fill="#000" opacity="0.12"/>
            <path d="M4,11 Q4,8 7,7 L7,3.5 Q7,1.5 9,1.5 L13,1.5 Q15,1.5 15,3.5 L15,7 Q18,8 18,11 L18,49 Q18,52 15,52 L7,52 Q4,52 4,49 Z" fill="url(#bg05_'.$pid.')" stroke="#6ecef0" stroke-width="0.4"/>
            <rect x="4" y="33" width="14" height="19" fill="#29aedb" opacity="0.42" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="22" width="14" height="16" fill="url(#label05_'.$pid.')" opacity="0.95" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="22" width="14" height="4" fill="white" opacity="0.08" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="22" width="14" height="0.8" fill="#00d4f5" opacity="0.9" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="37.2" width="14" height="0.8" fill="#00d4f5" opacity="0.9" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="22" width="2.5" height="16" fill="white" opacity="0.06" clip-path="url(#cp05_'.$pid.')"/>
            <g clip-path="url(#cp05_'.$pid.')">
              <defs>
                <radialGradient id="lg05_'.$pid.'" cx="35%" cy="25%" r="65%">
                  <stop offset="0%" stop-color="#5dd8f0"/>
                  <stop offset="60%" stop-color="#0e90c4"/>
                  <stop offset="100%" stop-color="#003d6b"/>
                </radialGradient>
                <filter id="ds05_'.$pid.'" x="-40%" y="-40%" width="180%" height="180%">
                  <feDropShadow dx="0" dy="0.5" stdDeviation="0.8" flood-color="#003d6b" flood-opacity="0.6"/>
                </filter>
              </defs>
              <path d="M11,24.2 C13.8,26.8 14.8,28.5 14.8,29.6 C14.8,31.2 13.1,32.3 11,32.3 C8.9,32.3 7.2,31.2 7.2,29.6 C7.2,28.5 8.2,26.8 11,24.2 Z" fill="url(#lg05_'.$pid.')" filter="url(#ds05_'.$pid.')"/>
              <path d="M9.5,25.5 C9.9,26.8 10,28.2 9.8,29.3 C9.6,30 9.1,30.6 8.7,30.4 C8.2,30 8.2,28.8 8.7,27.5 Z" fill="white" opacity="0.28"/>
              <text x="11" y="31" text-anchor="middle" font-family="Georgia,serif" font-size="5" font-weight="700" fill="white" opacity="0.97">N</text>
            </g>
            <text x="11" y="34.8" text-anchor="middle" font-family="Bebas Neue,Arial Narrow,sans-serif" font-size="3.8" fill="white" letter-spacing="1.2" opacity="0.97" clip-path="url(#cp05_'.$pid.')">NAQAA</text>
            <text x="11" y="37" text-anchor="middle" font-family="Amiri,Traditional Arabic,Arial Unicode MS,serif" font-size="3" fill="#7ad4ef" opacity="0.88" clip-path="url(#cp05_'.$pid.')">نقاء</text>
            <rect x="6" y="9" width="2" height="38" rx="1" fill="white" opacity="0.3"/>
            <rect x="8.5" y="9" width="1" height="20" rx="0.5" fill="white" opacity="0.12"/>
            <rect x="4" y="19" width="14" height="1.2" rx="0.6" fill="#7ad4ef" opacity="0.3" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="4" y="48" width="14" height="4" fill="#005f87" opacity="0.3" clip-path="url(#cp05_'.$pid.')"/>
            <rect x="7.5" y="0" width="7" height="4.5" rx="1.8" fill="#00d4f5"/>
            <rect x="7.5" y="3" width="7" height="1.5" fill="#0099bb"/>
            <rect x="8" y="0.5" width="2" height="2" rx="1" fill="white" opacity="0.35"/>
          </svg>';
        }
      ?>
    </div>
    <div class="product-body">
      <div class="product-name"><?= htmlspecialchars($row['nomProduit']) ?></div>
      <span class="product-vol"><?= htmlspecialchars($row['volume']) ?></span>

      <div class="fardeau-info">
        <svg width="13" height="13" viewBox="0 0 120 150" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;margin-right:5px;"><defs><radialGradient id="iDrop" cx="35%" cy="25%" r="65%"><stop offset="0%" stop-color="#5dd8f0"/><stop offset="60%" stop-color="#0e90c4"/><stop offset="100%" stop-color="#003d6b"/></radialGradient></defs><path d="M60,6 C92,40 100,66 100,82 C100,104 82,118 60,118 C38,118 20,104 20,82 C20,66 28,40 60,6 Z" fill="url(#iDrop)"/><path d="M40,28 C44,44 45,66 43,82 C41,92 36,100 31,96 C26,90 27,72 33,54 Z" fill="white" opacity="0.22"/><text x="60" y="96" text-anchor="middle" font-family="Georgia,serif" font-size="52" font-weight="700" fill="white">N</text></svg>
        1 fardeau = <span><?= $bpf ?> bouteilles</span>
      </div>

      <div class="price-row">
        <div class="price">
          <?= number_format($prixFardeau, 0) ?> DZD
          <small>/ fardeau · <?= $bpf ?> bt × <?= number_format($row['prixUnitaire'],0) ?> DZD</small>
        </div>
      </div>

      <form action="add_cart.php" method="POST">
        <input type="hidden" name="id"           value="<?= $row['idProduit'] ?>">
        <input type="hidden" name="name"         value="<?= htmlspecialchars($row['nomProduit']) ?> (<?= $row['volume'] ?>)">
        <input type="hidden" name="prix_fardeau" value="<?= $prixFardeau ?>">
        <input type="hidden" name="bpf"          value="<?= $bpf ?>">
        <div class="qty-label">Nombre de fardeaux :</div>
        <div class="qty-row">
          <input type="number" class="qty-input" name="qty_fardeaux" min="1" value="1" required
>
          <button type="submit" name="add_to_cart" class="add-btn">
            🛒 Ajouter
          </button>
        </div>
      </form>
    </div>
  </div>
  <?php endwhile; ?>

  <?php if($i === 0): ?>
  <div class="empty">
    <div class="empty-icon">📦</div>
    <p>Aucun produit disponible pour le moment.</p>
  </div>
  <?php endif; ?>

  </div>
</main>

<script>
// Scroll progress
const line = document.getElementById('scrollLine');
window.addEventListener('scroll', () => {
  const h = document.documentElement.scrollHeight - window.innerHeight;
  line.style.width = (h > 0 ? (window.scrollY / h * 100) : 100) + '%';
}, { passive:true });

// Nav background on scroll
const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.background = window.scrollY > 40
    ? 'rgba(2,11,20,0.97)'
    : 'rgba(2,11,20,0.85)';
}, { passive:true });

// Input glow on type
document.querySelectorAll('.qty-input').forEach(inp => {
  inp.addEventListener('input', () => {
    inp.style.borderColor = inp.value > 0 ? 'rgba(0,212,245,0.5)' : '';
  });
});
</script>
</body>
</html>