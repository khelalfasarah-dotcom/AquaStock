<?php
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin'){
    if(isset($_SESSION['user']) && $_SESSION['role'] === 'responsable_clients'){
        header("Location: ../views/clients.php"); exit();
    }
    header("Location: ../auth/login.php"); exit();
}
require_once "../config/db.php";

// ── Stats principales ─────────────────────────────────────────────────────────
$clients   = $conn->query("SELECT COUNT(*) as c FROM client")->fetch_assoc()['c'];
$produits  = $conn->query("SELECT COUNT(*) as c FROM produit")->fetch_assoc()['c'];
$commandes = $conn->query("SELECT COUNT(*) as c FROM commande")->fetch_assoc()['c'];
$factures  = $conn->query("SELECT COUNT(*) as c FROM facture")->fetch_assoc()['c'];

$totalCA = $conn->query("
    SELECT COALESCE(SUM(montantTC), 0) as s
    FROM facture WHERE etatFacture = 'confirmee'
")->fetch_assoc()['s'];

// ── Statuts commandes ─────────────────────────────────────────────────────────
$enCours  = $conn->query("SELECT COUNT(*) as c FROM commande WHERE etatCommande='en_cours'")->fetch_assoc()['c'];
$validees = $conn->query("SELECT COUNT(*) as c FROM commande WHERE etatCommande='validee'")->fetch_assoc()['c'];
$annulees = $conn->query("SELECT COUNT(*) as c FROM commande WHERE etatCommande='annulee'")->fetch_assoc()['c'];

// ── Stock bas ─────────────────────────────────────────────────────────────────
$lowStock = $conn->query("
    SELECT COUNT(*) as c FROM produit
    WHERE FLOOR(quantiteStock / btParFardeau) < 5
")->fetch_assoc()['c'];

// ── Alertes stock ─────────────────────────────────────────────────────────────
$stockAlerts = $conn->query("
    SELECT nomProduit, volume, quantiteStock, btParFardeau,
           FLOOR(quantiteStock / btParFardeau) AS fardeaux
    FROM produit
    WHERE FLOOR(quantiteStock / btParFardeau) < 5
    ORDER BY fardeaux ASC
");
$alertRows = [];
while($a = $stockAlerts->fetch_assoc()) $alertRows[] = $a;

// ── Stock par produit ─────────────────────────────────────────────────────────
$stockProduits = $conn->query("
    SELECT idProduit, nomProduit, volume, btParFardeau, quantiteStock, prixUnitaire,
           FLOOR(quantiteStock / btParFardeau) AS fardeaux,
           ROUND(quantiteStock * prixUnitaire)  AS valeurDA
    FROM produit ORDER BY fardeaux ASC
");

// ── Top 5 clients ─────────────────────────────────────────────────────────────
$topClientsRes = $conn->query("
    SELECT cl.nom,
           COUNT(DISTINCT c.idCommande) as nbCommandes,
           COALESCE(SUM(f.montantTC), 0) as totalDA
    FROM client cl
    LEFT JOIN commande c ON c.idClient   = cl.idClient
    LEFT JOIN facture  f ON f.idCommande = c.idCommande AND f.etatFacture = 'confirmee'
    GROUP BY cl.idClient, cl.nom
    ORDER BY totalDA DESC
    LIMIT 5
");
$topClientsArr = [];
while($r = $topClientsRes->fetch_assoc()) $topClientsArr[] = $r;

// ── 5 dernières commandes ─────────────────────────────────────────────────────
$recentOrders = $conn->query("
    SELECT c.idCommande, c.dateCommande, c.etatCommande,
           cl.nom as client_nom,
           COALESCE(SUM(lp.sousTotal), 0) as totalCommande
    FROM commande c
    LEFT JOIN client cl        ON c.idClient   = cl.idClient
    LEFT JOIN ligne_produit lp ON lp.idCommande = c.idCommande
    GROUP BY c.idCommande, c.dateCommande, c.etatCommande, cl.nom
    ORDER BY c.idCommande DESC
    LIMIT 5
");

// ── Commandes mensuelles — bar chart (6 derniers mois) ───────────────────────
$monthlyOrders = $conn->query("
    SELECT DATE_FORMAT(dateCommande,'%b %Y') as mois,
           MONTH(dateCommande) as mnum,
           YEAR(dateCommande)  as yr,
           COUNT(*) as total,
           SUM(CASE WHEN etatCommande='validee'  THEN 1 ELSE 0 END) as validees,
           SUM(CASE WHEN etatCommande='annulee'  THEN 1 ELSE 0 END) as annulees
    FROM commande
    WHERE dateCommande >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY YEAR(dateCommande), MONTH(dateCommande), DATE_FORMAT(dateCommande,'%b %Y')
    ORDER BY yr ASC, mnum ASC
");
$chartLabels = []; $chartTotal = []; $chartValidees = []; $chartAnnulees = [];
while($m = $monthlyOrders->fetch_assoc()){
    $chartLabels[]   = $m['mois'];
    $chartTotal[]    = (int)$m['total'];
    $chartValidees[] = (int)$m['validees'];
    $chartAnnulees[] = (int)$m['annulees'];
}

// ── CA par produit — horizontal bar ──────────────────────────────────────────
$revenueByProduct = $conn->query("
    SELECT p.nomProduit, p.volume,
           COALESCE(SUM(lp.sousTotal), 0) as ca
    FROM produit p
    LEFT JOIN ligne_produit lp ON lp.idProduit  = p.idProduit
    LEFT JOIN commande c       ON c.idCommande  = lp.idCommande
    LEFT JOIN facture  f       ON f.idCommande  = c.idCommande AND f.etatFacture = 'confirmee'
    GROUP BY p.idProduit, p.nomProduit, p.volume
    ORDER BY ca DESC
");
$barProdLabels = []; $barProdData = [];
while($r = $revenueByProduct->fetch_assoc()){
    $barProdLabels[] = $r['nomProduit'] . ' ' . $r['volume'];
    $barProdData[]   = (int)$r['ca'];
}

// ── Marques ───────────────────────────────────────────────────────────────────
$brandsRes = $conn->query("
    SELECT nomProduit as marque,
           COUNT(*) as nbProduits,
           SUM(quantiteStock) as totalUnits,
           ROUND(SUM(quantiteStock * prixUnitaire)) as valeurStock
    FROM produit GROUP BY nomProduit ORDER BY valeurStock DESC
");
$brandRows = [];
while($b = $brandsRes->fetch_assoc()) $brandRows[] = $b;

$pageTitle = "Tableau de bord";
include_once "../components/header.php";
?>

<style>
/* ══════════════════════════════════════════════════════
   Dashboard Professional Styles
   ══════════════════════════════════════════════════════ */
:root {
  --c1: #00d4f5;
  --c2: #00ffcc;
  --c3: #a78bfa;
  --c4: #fbbf24;
  --c5: #f97316;
  --card-bg: rgba(6,16,34,0.88);
  --card-border: rgba(0,212,245,0.1);
  --card-border-hover: rgba(0,212,245,0.28);
  --muted-text: #5a8098;
  --bright-text: #ddeefa;
  --grid-line: rgba(0,212,245,0.05);
}

/* ── KPI Grid ─────────────────────────────────────── */
.db-kpi-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 14px;
  margin-bottom: 20px;
}
.db-kpi-card {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 16px;
  padding: 20px 18px 16px;
  position: relative;
  overflow: hidden;
  transition: border-color .2s, transform .2s, box-shadow .2s;
  cursor: default;
}
.db-kpi-card:hover {
  border-color: var(--card-border-hover);
  transform: translateY(-2px);
  box-shadow: 0 12px 36px rgba(0,0,0,0.35);
}
.db-kpi-card::after {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse 80% 60% at 50% -20%, rgba(0,212,245,0.04) 0%, transparent 70%);
  pointer-events: none;
}
.db-kpi-accent {
  position: absolute;
  top: 0; left: 20px; right: 20px;
  height: 2px;
  border-radius: 0 0 2px 2px;
  background: linear-gradient(90deg, var(--c1), var(--c2));
  opacity: 0.6;
}
.db-kpi-icon {
  width: 38px; height: 38px;
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 17px;
  margin-bottom: 13px;
  position: relative; z-index: 1;
}
.db-kpi-value {
  font-family: 'Bebas Neue', sans-serif;
  font-size: 30px;
  letter-spacing: 0.5px;
  color: #e4f4ff;
  line-height: 1;
  margin-bottom: 4px;
  position: relative; z-index: 1;
}
.db-kpi-value small {
  font-family: 'Outfit', sans-serif;
  font-size: 12px;
  color: var(--muted-text);
  font-weight: 400;
  margin-left: 2px;
}
.db-kpi-label {
  font-size: 10.5px;
  color: var(--muted-text);
  text-transform: uppercase;
  letter-spacing: .7px;
  font-weight: 600;
  position: relative; z-index: 1;
}
.db-kpi-sub {
  font-size: 10.5px;
  color: rgba(90,128,152,0.7);
  margin-top: 5px;
  position: relative; z-index: 1;
}

/* ── Status Strip ─────────────────────────────────── */
.db-status-strip {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin-bottom: 20px;
}
.db-status-pill {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 12px;
  padding: 13px 18px;
  display: flex;
  align-items: center;
  gap: 14px;
  transition: border-color .2s;
}
.db-status-pill:hover { border-color: var(--card-border-hover); }
.db-status-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}
.db-status-num {
  font-family: 'Bebas Neue', sans-serif;
  font-size: 26px;
  line-height: 1;
  color: #e4f4ff;
}
.db-status-lbl {
  font-size: 10.5px;
  color: var(--muted-text);
  text-transform: uppercase;
  letter-spacing: .6px;
  font-weight: 600;
  margin-top: 2px;
}

/* ── Charts Row ───────────────────────────────────── */
.db-charts-row {
  display: grid;
  grid-template-columns: 1.5fr 1fr;
  gap: 16px;
  margin-bottom: 20px;
}

/* ── Data Row ─────────────────────────────────────── */
.db-data-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 20px;
}

/* ── Card ─────────────────────────────────────────── */
.db-card {
  background: var(--card-bg);
  border: 1px solid var(--card-border);
  border-radius: 16px;
  padding: 22px 22px 20px;
  position: relative;
  overflow: hidden;
}
.db-card-hd {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 18px;
}
.db-card-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--muted-text);
  display: flex;
  align-items: center;
  gap: 8px;
}
.db-card-title::before {
  content: '';
  display: inline-block;
  width: 3px; height: 13px;
  background: linear-gradient(180deg, var(--c1), var(--c2));
  border-radius: 2px;
  flex-shrink: 0;
}
.db-btn-ghost {
  font-size: 11px;
  font-weight: 700;
  padding: 5px 13px;
  border-radius: 8px;
  text-decoration: none;
  background: rgba(0,212,245,0.07);
  color: var(--c1);
  border: 1px solid rgba(0,212,245,0.15);
  transition: background .2s;
  white-space: nowrap;
}
.db-btn-ghost:hover { background: rgba(0,212,245,0.13); }

/* ── Alerts ───────────────────────────────────────── */
.db-alerts { margin-bottom: 18px; }
.db-alert-row {
  display: flex;
  align-items: center;
  gap: 13px;
  border-radius: 11px;
  padding: 12px 16px;
  margin-bottom: 7px;
  font-size: 13px;
}
.db-alert-danger {
  background: rgba(244,63,94,0.07);
  border: 1px solid rgba(244,63,94,0.2);
}
.db-alert-warn {
  background: rgba(251,191,36,0.07);
  border: 1px solid rgba(251,191,36,0.16);
}
.db-alert-row a.db-alert-btn {
  margin-left: auto;
  font-size: 11px;
  font-weight: 700;
  padding: 5px 12px;
  border-radius: 7px;
  text-decoration: none;
  white-space: nowrap;
}
.db-alert-danger a.db-alert-btn {
  background: #f43f5e;
  color: #fff;
}
.db-alert-warn a.db-alert-btn {
  background: rgba(251,191,36,0.12);
  color: #fbbf24;
  border: 1px solid rgba(251,191,36,0.25);
}

/* ── Table ────────────────────────────────────────── */
.db-table-wrap { overflow-x: auto; }
.db-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.db-table th {
  text-align: left;
  padding: 7px 10px;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: .65px;
  color: var(--muted-text);
  font-weight: 700;
  border-bottom: 1px solid rgba(0,212,245,0.08);
}
.db-table td {
  padding: 11px 10px;
  border-bottom: 1px solid rgba(0,212,245,0.04);
  color: #bdd6e8;
  vertical-align: middle;
}
.db-table tr:last-child td { border-bottom: none; }
.db-table tr:hover td { background: rgba(0,212,245,0.015); }

/* ── Top Client Bars ──────────────────────────────── */
.tc-row { margin-bottom: 13px; }
.tc-row:last-child { margin-bottom: 0; }
.tc-meta { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 6px; }
.tc-name { font-size: 13px; color: var(--bright-text); font-weight: 500; }
.tc-info { font-size: 11px; color: var(--muted-text); }
.tc-track { height: 5px; background: rgba(0,212,245,0.06); border-radius: 3px; overflow: hidden; }
.tc-fill  { height: 100%; border-radius: 3px; transition: width 1.3s cubic-bezier(.4,0,.2,1); }

/* ── Responsive ───────────────────────────────────── */
@media (max-width: 1200px) {
  .db-kpi-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 900px) {
  .db-charts-row, .db-data-row { grid-template-columns: 1fr; }
}
@media (max-width: 650px) {
  .db-kpi-grid { grid-template-columns: repeat(2, 1fr); }
  .db-status-strip { grid-template-columns: 1fr; }
}
</style>

<!-- ══ Alertes ══════════════════════════════════════════════════════════════ -->
<?php if(!empty($alertRows)): ?>
<div class="db-alerts stagger">
    <?php foreach($alertRows as $a):
        $fard = (int)$a['fardeaux'];
        $isDanger = $fard === 0;
    ?>
    <div class="db-alert-row <?= $isDanger ? 'db-alert-danger' : 'db-alert-warn' ?>">
        <span style="font-size:17px;"><?= $isDanger ? '🚨' : '⚠️' ?></span>
        <div>
            <strong style="color:<?= $isDanger ? '#f43f5e' : '#fbbf24' ?>;font-size:13px;">
                <?= htmlspecialchars($a['nomProduit']) ?> <?= htmlspecialchars($a['volume']) ?>
            </strong>
            <span style="color:var(--muted-text);font-size:12px;margin-left:8px;">
                <?= $isDanger
                    ? 'Stock épuisé — 0 fardeau disponible'
                    : "Stock bas — {$fard} fardeau" . ($fard>1?'x':'') . " restant" . ($fard>1?'s':'')
                ?>
            </span>
        </div>
        <a href="produits.php" class="db-alert-btn">
            <?= $isDanger ? 'Réapprovisionner' : 'Voir stock' ?>
        </a>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ══ KPI Cards ════════════════════════════════════════════════════════════ -->
<div class="db-kpi-grid stagger">
    <!-- CA -->
    <div class="db-kpi-card">
        <div class="db-kpi-accent"></div>
        <div class="db-kpi-icon" style="background:rgba(0,212,245,0.1);">💰</div>
        <div class="db-kpi-value">
            <?= number_format($totalCA, 0, ',', ' ') ?><small> DA</small>
        </div>
        <div class="db-kpi-label">Chiffre d'affaires</div>
        <div class="db-kpi-sub">Factures confirmées</div>
    </div>
    <!-- Commandes -->
    <div class="db-kpi-card">
        <div class="db-kpi-accent" style="background:linear-gradient(90deg,var(--c2),#00c8a0);"></div>
        <div class="db-kpi-icon" style="background:rgba(0,255,204,0.1);">📦</div>
        <div class="db-kpi-value"><?= $commandes ?></div>
        <div class="db-kpi-label">Total commandes</div>
    </div>
    <!-- Clients -->
    <div class="db-kpi-card">
        <div class="db-kpi-accent" style="background:linear-gradient(90deg,var(--c3),#c4b5fd);"></div>
        <div class="db-kpi-icon" style="background:rgba(167,139,250,0.1);">👥</div>
        <div class="db-kpi-value"><?= $clients ?></div>
        <div class="db-kpi-label">Clients</div>
    </div>
    <!-- Produits -->
    <div class="db-kpi-card">
        <div class="db-kpi-accent" style="background:linear-gradient(90deg,var(--c4),#f59e0b);"></div>
        <div class="db-kpi-icon" style="background:rgba(251,191,36,0.1);">🍶</div>
        <div class="db-kpi-value"><?= $produits ?></div>
        <div class="db-kpi-label">Produits</div>
    </div>
    <!-- Factures or Stock alert -->
    <?php if($lowStock > 0): ?>
    <div class="db-kpi-card" style="border-color:rgba(244,63,94,0.25);">
        <div class="db-kpi-accent" style="background:linear-gradient(90deg,#f43f5e,#fb7185);"></div>
        <div class="db-kpi-icon" style="background:rgba(244,63,94,0.1);">⚠️</div>
        <div class="db-kpi-value" style="color:#f43f5e;"><?= $lowStock ?></div>
        <div class="db-kpi-label" style="color:rgba(244,63,94,0.7);">Stock bas</div>
        <div class="db-kpi-sub">&lt; 5 fardeaux</div>
    </div>
    <?php else: ?>
    <div class="db-kpi-card">
        <div class="db-kpi-accent" style="background:linear-gradient(90deg,var(--c5),#fb923c);"></div>
        <div class="db-kpi-icon" style="background:rgba(249,115,22,0.1);">🧾</div>
        <div class="db-kpi-value"><?= $factures ?></div>
        <div class="db-kpi-label">Factures émises</div>
    </div>
    <?php endif; ?>
</div>

<!-- ══ Status strip ══════════════════════════════════════════════════════════ -->
<div class="db-status-strip stagger">
    <div class="db-status-pill">
        <div class="db-status-dot" style="background:#fbbf24;box-shadow:0 0 8px rgba(251,191,36,0.5);"></div>
        <div>
            <div class="db-status-num"><?= $enCours ?></div>
            <div class="db-status-lbl">En cours</div>
        </div>
    </div>
    <div class="db-status-pill">
        <div class="db-status-dot" style="background:#00ffcc;box-shadow:0 0 8px rgba(0,255,204,0.5);"></div>
        <div>
            <div class="db-status-num"><?= $validees ?></div>
            <div class="db-status-lbl">Validées</div>
        </div>
    </div>
    <div class="db-status-pill">
        <div class="db-status-dot" style="background:#f43f5e;box-shadow:0 0 8px rgba(244,63,94,0.5);"></div>
        <div>
            <div class="db-status-num"><?= $annulees ?></div>
            <div class="db-status-lbl">Annulées</div>
        </div>
    </div>
</div>

<!-- ══ Charts ════════════════════════════════════════════════════════════════ -->
<div class="db-charts-row stagger">

    <!-- Commandes mensuelles grouped bar -->
    <div class="db-card">
        <div class="db-card-hd">
            <div class="db-card-title">Commandes des 6 derniers mois</div>
        </div>
        <div style="position:relative;width:100%;height:220px;">
            <canvas id="ordersChart"></canvas>
        </div>
    </div>

    <!-- CA par produit horizontal bar -->
    <div class="db-card">
        <div class="db-card-hd">
            <div class="db-card-title">CA par produit</div>
        </div>
        <?php $caChartHeight = max(220, count($barProdLabels) * 38); ?>
        <div style="position:relative;width:100%;height:<?= $caChartHeight ?>px;">
            <canvas id="caBarChart"></canvas>
        </div>
    </div>

</div>

<!-- ══ Data Row ══════════════════════════════════════════════════════════════ -->
<div class="db-data-row stagger">

    <!-- Stock par produit -->
    <div class="db-card">
        <div class="db-card-hd">
            <div class="db-card-title">Stock par produit</div>
            <a href="produits.php" class="db-btn-ghost">Gérer →</a>
        </div>
        <div class="db-table-wrap">
        <table class="db-table">
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Volume</th>
                    <th>Fardeaux</th>
                    <th>Valeur</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>
            <?php while($r = $stockProduits->fetch_assoc()):
                $fard = $r['fardeaux'];
                $cls  = $fard < 5  ? 'red'    : ($fard < 10 ? 'yellow' : 'green');
                $lbl  = $fard < 5  ? 'Bas'    : ($fard < 10 ? 'Moyen'  : 'OK');
            ?>
            <tr>
                <td style="font-weight:500;color:var(--bright-text);"><?= htmlspecialchars($r['nomProduit']) ?></td>
                <td><span class="badge badge-blue"><?= htmlspecialchars($r['volume']) ?></span></td>
                <td style="font-weight:600;color:var(--bright-text);"><?= $fard ?></td>
                <td style="color:var(--c1);font-weight:600;"><?= number_format($r['valeurDA'],0,',',' ') ?> DA</td>
                <td><span class="badge badge-<?= $cls ?>"><?= $lbl ?></span></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- Top clients + Marques -->
    <div class="db-card">
        <div class="db-card-hd">
            <div class="db-card-title">Meilleurs clients</div>
            <a href="clients.php" class="db-btn-ghost">Voir tous →</a>
        </div>

        <?php
        $barPalette = ['#00d4f5','#00ffcc','#a78bfa','#fbbf24','#f97316'];
        $maxDA = max(1, ...array_column($topClientsArr, 'totalDA'));
        foreach($topClientsArr as $i => $row):
            $pct   = round($row['totalDA'] / $maxDA * 100);
            $color = $barPalette[$i % count($barPalette)];
        ?>
        <div class="tc-row">
            <div class="tc-meta">
                <span class="tc-name"><?= htmlspecialchars($row['nom']) ?></span>
                <span class="tc-info">
                    <?= $row['nbCommandes'] ?> cmd &nbsp;·&nbsp;
                    <strong style="color:<?= $color ?>;"><?= number_format($row['totalDA'],0,',',' ') ?> DA</strong>
                </span>
            </div>
            <div class="tc-track">
                <div class="tc-fill" style="width:<?= $pct ?>%;background:<?= $color ?>;"></div>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if(!empty($brandRows)): ?>
        <div style="margin-top:20px;padding-top:16px;border-top:1px solid rgba(0,212,245,0.07);">
            <div class="db-card-title" style="margin-bottom:12px;">Marques en stock</div>
            <?php foreach($brandRows as $b): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(0,212,245,0.04);">
                <span style="font-size:12.5px;color:var(--bright-text);font-weight:500;"><?= htmlspecialchars($b['marque']) ?></span>
                <span style="font-size:11.5px;color:var(--muted-text);">
                    <?= $b['nbProduits'] ?> format<?= $b['nbProduits']>1?'s':'' ?>
                    &nbsp;·&nbsp;
                    <span style="color:var(--c1);font-weight:600;"><?= number_format($b['valeurStock'],0,',',' ') ?> DA</span>
                </span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

</div>

<!-- ══ Dernières commandes ════════════════════════════════════════════════════ -->
<div class="db-card stagger" style="margin-bottom:28px;">
    <div class="db-card-hd">
        <div class="db-card-title">Dernières commandes</div>
        <a href="commandes.php" class="db-btn-ghost">Tout voir →</a>
    </div>
    <div class="db-table-wrap">
    <table class="db-table">
        <thead>
            <tr>
                <th>N°</th>
                <th>Client</th>
                <th>Date</th>
                <th>Montant</th>
                <th>Statut</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php while($r = $recentOrders->fetch_assoc()):
            $map = [
                'en_cours' => ['yellow','⏳ En cours'],
                'validee'  => ['green',  '✅ Validée'],
                'annulee'  => ['red',    '❌ Annulée'],
            ];
            [$cls,$lbl] = $map[$r['etatCommande']] ?? ['blue',$r['etatCommande']];
        ?>
        <tr>
            <td style="font-size:11.5px;color:var(--muted-text);font-weight:600;">#<?= $r['idCommande'] ?></td>
            <td style="font-weight:500;color:var(--bright-text);"><?= htmlspecialchars($r['client_nom'] ?? '—') ?></td>
            <td style="color:var(--muted-text);"><?= date('d/m/Y', strtotime($r['dateCommande'])) ?></td>
            <td style="font-weight:700;color:var(--c1);"><?= number_format($r['totalCommande'],0,',',' ') ?> DA</td>
            <td><span class="badge badge-<?= $cls ?>"><?= $lbl ?></span></td>
            <td><a href="commandes.php" class="db-btn-ghost" style="font-size:10.5px;padding:4px 10px;">Voir →</a></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<!-- ══ Chart.js ══════════════════════════════════════════════════════════════ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
// Shared defaults
Chart.defaults.font.family = "'Outfit', sans-serif";
Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(3,10,22,0.96)';
Chart.defaults.plugins.tooltip.titleColor      = '#e4f4ff';
Chart.defaults.plugins.tooltip.bodyColor       = '#5a8098';
Chart.defaults.plugins.tooltip.borderColor     = 'rgba(0,212,245,0.2)';
Chart.defaults.plugins.tooltip.borderWidth     = 1;
Chart.defaults.plugins.tooltip.padding         = 12;
Chart.defaults.plugins.tooltip.cornerRadius    = 10;

const gridCol = 'rgba(0,212,245,0.05)';
const tickCol = '#4a6a7a';

// ── Chart 1 : Commandes mensuelles — grouped bar ─────────────────────────────
const monthLabels   = <?= json_encode($chartLabels) ?>;
const monthTotal    = <?= json_encode($chartTotal) ?>;
const monthValidees = <?= json_encode($chartValidees) ?>;
const monthAnnulees = <?= json_encode($chartAnnulees) ?>;

new Chart(document.getElementById('ordersChart'), {
    type: 'bar',
    data: {
        labels: monthLabels,
        datasets: [
            {
                label: 'Total',
                data: monthTotal,
                backgroundColor: 'rgba(0,212,245,0.13)',
                borderColor: 'rgba(0,212,245,0.4)',
                borderWidth: 1.5,
                borderRadius: 7,
                borderSkipped: false
            },
            {
                label: 'Validées',
                data: monthValidees,
                backgroundColor: 'rgba(0,255,204,0.6)',
                borderColor: '#00ffcc',
                borderWidth: 1.5,
                borderRadius: 7,
                borderSkipped: false
            },
            {
                label: 'Annulées',
                data: monthAnnulees,
                backgroundColor: 'rgba(244,63,94,0.5)',
                borderColor: '#f43f5e',
                borderWidth: 1.5,
                borderRadius: 7,
                borderSkipped: false
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                align: 'end',
                labels: {
                    color: tickCol,
                    font: { size: 10.5 },
                    boxWidth: 10, boxHeight: 10,
                    useBorderRadius: true, borderRadius: 3,
                    padding: 14
                }
            },
            tooltip: {
                callbacks: {
                    label: ctx => ` ${ctx.dataset.label}: ${ctx.parsed.y}`
                }
            }
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: tickCol, font: { size: 10.5 } },
                border: { display: false }
            },
            y: {
                grid: { color: gridCol, drawTicks: false },
                ticks: { color: tickCol, font: { size: 10.5 }, padding: 8 },
                border: { display: false }
            }
        },
        animation: { duration: 850, easing: 'easeOutQuart' }
    }
});

// ── Chart 2 : CA par produit — horizontal bar ────────────────────────────────
const barProdLabels = <?= json_encode($barProdLabels) ?>;
const barProdData   = <?= json_encode($barProdData) ?>;
const palette = ['#00d4f5','#00ffcc','#a78bfa','#fbbf24','#f97316','#fb7185','#38bdf8','#84cc16'];

new Chart(document.getElementById('caBarChart'), {
    type: 'bar',
    data: {
        labels: barProdLabels,
        datasets: [{
            label: 'CA (DA)',
            data: barProdData,
            backgroundColor: barProdLabels.map((_, i) => palette[i % palette.length] + 'aa'),
            borderColor:     barProdLabels.map((_, i) => palette[i % palette.length]),
            borderWidth: 1.5,
            borderRadius: 5,
            borderSkipped: false,
            barThickness: 22
        }]
    },
    options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { right: 10 } },
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: ctx => ` ${ctx.parsed.x.toLocaleString('fr-DZ')} DA`
                }
            }
        },
        scales: {
            x: {
                grid: { color: gridCol, drawTicks: false },
                ticks: {
                    color: tickCol,
                    font: { size: 10 },
                    padding: 6,
                    callback: v => v >= 1000000 ? (v/1000000).toFixed(1)+'M' : v >= 1000 ? (v/1000).toFixed(0)+'k' : v
                },
                border: { display: false }
            },
            y: {
                grid: { display: false },
                ticks: {
                    color: '#6a90a8',
                    font: { size: 10.5 },
                    crossAlign: 'far'
                },
                border: { display: false }
            }
        },
        animation: { duration: 900, easing: 'easeOutQuart' }
    }
});
</script>

<?php include_once "../components/footer.php"; ?>
