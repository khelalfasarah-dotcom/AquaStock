<?php
session_start();
if(!isset($_SESSION['user']) || !in_array($_SESSION['role'], ['admin','responsable_clients'])){
    header("Location: ../auth/login.php"); exit();
}
require_once "../config/db.php";

$idFacture = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$idFacture){ header("Location: factures.php"); exit(); }

// ── Full facture + commande + client
$stmt = $conn->prepare("
    SELECT f.*,
           c.idCommande, c.dateCommande, c.etatCommande, c.modePaiement,
           cl.idClient, cl.nom AS client_nom, cl.telephone, cl.adresse, cl.login
    FROM facture f
    JOIN commande c  ON c.idCommande = f.idCommande
    JOIN client   cl ON cl.idClient  = c.idClient
    WHERE f.idFacture = ?
");
$stmt->bind_param("i", $idFacture);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
if(!$data){ header("Location: factures.php"); exit(); }

// ── Order lines
$lStmt = $conn->prepare("
    SELECT lp.quantite, lp.sousTotal,
           pr.nomProduit, pr.volume, pr.prixUnitaire, pr.prixFardeau, pr.btParFardeau
    FROM ligne_produit lp
    JOIN produit pr ON pr.idProduit = lp.idProduit
    WHERE lp.idCommande = ?
    ORDER BY pr.nomProduit
");
$lStmt->bind_param("i", $data['idCommande']);
$lStmt->execute();
$lines = $lStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ── Labels
$payModeLabels = [
    'cash'     => 'Espèces à la livraison',
    'espece'   => 'Espèces',
    'especes'  => 'Espèces',
    'carte'    => 'Edahabia / Carte bancaire',
    'card'     => 'Edahabia / Carte bancaire',
    'ccp'      => 'CCP / Baridimob',
    'cheque'   => 'Chèque',
    'virement' => 'Virement bancaire',
];
$rawMode  = trim(strtolower($data['modePaiement'] ?? ''));
$payLabel = $payModeLabels[$rawMode] ?? ucfirst($rawMode ?: '—');

$etatMap = [
    'en_cours' => ['#f59e0b','En cours'],
    'validee'  => ['#00ffcc','Validée'],
    'annulee'  => ['#f43f5e','Annulée'],
];
[$etatColor, $etatLabel] = $etatMap[$data['etatCommande']] ?? ['#8ab0c8','—'];

$etatFacMap = [
    'en_attente' => ['#f59e0b','En attente'],
    'confirmee'  => ['#00ffcc','Confirmée'],
    'annulee'    => ['#f43f5e','Annulée'],
];
[$etatFColor, $etatFLabel] = $etatFacMap[$data['etatFacture'] ?? 'en_attente'] ?? ['#f59e0b','En attente'];

$printDate = date('d/m/Y à H:i');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Facture #<?= $idFacture ?> — AquaStock</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════════════════
   SCREEN STYLES  —  dark AquaStock theme
═══════════════════════════════════════════ */
:root {
  --accent:  #00d4f5;
  --accent2: #0077a8;
  --accent3: #00ffcc;
  --bg:      #020b14;
  --surface: rgba(0,212,245,0.04);
  --surface2:rgba(0,212,245,0.08);
  --border:  rgba(0,212,245,0.12);
  --border2: rgba(0,212,245,0.28);
  --text:    #e4f4ff;
  --muted:   #5a8098;
  --muted2:  #8ab0c8;
  --green:   #00ffcc;
  --red:     #f43f5e;
  --yellow:  #fbbf24;
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
  font-family:'Outfit',sans-serif;
  background:var(--bg); color:var(--text);
  min-height:100vh; overflow-x:hidden;
}
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-track { background:rgba(0,212,245,0.04); }
::-webkit-scrollbar-thumb {
  background:linear-gradient(to bottom,var(--accent2),var(--accent),var(--accent3));
  border-radius:10px;
}
* { scrollbar-width:thin; scrollbar-color:var(--accent) rgba(0,212,245,0.04); }

.ambient {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background:
    radial-gradient(ellipse 80% 50% at 50% 0%, rgba(0,119,168,0.2) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 90% 80%, rgba(0,212,245,0.06) 0%, transparent 50%);
}
.grid-bg {
  position:fixed; inset:0; z-index:0; pointer-events:none;
  background-image:
    linear-gradient(rgba(0,212,245,0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,212,245,0.025) 1px, transparent 1px);
  background-size:60px 60px;
}

/* ── NAV ── */
nav {
  position:sticky; top:0; z-index:500;
  display:flex; align-items:center; justify-content:space-between;
  padding:0 56px; height:70px;
  background:rgba(2,11,20,0.92);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.nav-brand {
  display:flex; align-items:center; gap:10px;
  font-family:'Bebas Neue',sans-serif; font-size:22px; letter-spacing:2px;
  color:var(--text); text-decoration:none;
}
.nav-brand-icon {
  width:38px; height:38px; border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  display:flex; align-items:center; justify-content:center; font-size:18px;
  box-shadow:0 0 20px rgba(0,212,245,0.4);
}
.nav-right { display:flex; align-items:center; gap:10px; }
.nav-btn {
  display:flex; align-items:center; gap:7px;
  padding:9px 18px; border-radius:9px; text-decoration:none;
  font-weight:600; font-size:12px; transition:all .25s;
  border:1px solid var(--border); color:var(--muted2);
  background:var(--surface); cursor:pointer; font-family:'Outfit',sans-serif;
}
.nav-btn:hover { border-color:var(--border2); color:var(--text); background:var(--surface2); transform:translateY(-1px); }
.btn-print {
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-color:transparent; color:#020b14 !important; font-weight:700 !important;
  box-shadow:0 0 20px rgba(0,212,245,0.2);
}
.btn-print:hover { box-shadow:0 0 35px rgba(0,212,245,0.45) !important; transform:translateY(-2px) !important; }

/* ── MAIN ── */
main {
  position:relative; z-index:10;
  padding:52px 56px 80px;
  max-width:980px; margin:0 auto;
}

/* ── PAGE HEADER ── */
.page-header { margin-bottom:40px; animation:fadeUp .5s cubic-bezier(.22,1,.36,1) both; }
.page-label {
  font-size:10px; text-transform:uppercase; letter-spacing:3px;
  color:var(--accent); font-weight:600; margin-bottom:12px;
  display:flex; align-items:center; gap:8px;
}
.page-label::before { content:''; width:24px; height:1px; background:var(--accent); }
.page-title {
  font-family:'Bebas Neue',sans-serif;
  font-size:clamp(38px,5vw,60px); letter-spacing:1px; line-height:.95;
  margin-bottom:14px;
}
.page-title span { color:var(--accent); }
.badges-row { display:flex; gap:10px; flex-wrap:wrap; }
.badge-pill {
  display:inline-flex; align-items:center; gap:6px;
  padding:5px 14px; border-radius:100px; font-size:12px; font-weight:600;
  background:var(--surface); border:1px solid var(--border2);
}

/* ── GRID ── */
.two-col { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
.one-col { margin-bottom:20px; }

/* ── CARD ── */
.card {
  background:rgba(8,20,40,0.75);
  border:1px solid var(--border);
  border-radius:18px; overflow:hidden;
  backdrop-filter:blur(12px);
  animation:fadeUp .55s cubic-bezier(.22,1,.36,1) both;
  transition:border-color .3s;
}
.card:hover { border-color:var(--border2); }
.card-header {
  display:flex; align-items:center; gap:12px;
  padding:16px 22px;
  border-bottom:1px solid var(--border);
  background:rgba(0,212,245,0.03);
}
.card-header-icon {
  width:32px; height:32px; border-radius:8px;
  background:rgba(0,212,245,0.1); border:1px solid var(--border2);
  display:flex; align-items:center; justify-content:center; font-size:15px;
}
.card-header-title {
  font-size:12px; font-weight:700; text-transform:uppercase;
  letter-spacing:0.6px; color:var(--muted2);
}
.card-body { padding:20px 22px; }
.info-row {
  display:flex; justify-content:space-between; align-items:center;
  padding:9px 0; border-bottom:1px solid rgba(0,212,245,0.06);
}
.info-row:last-child { border:none; }
.info-row .k { font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px; }
.info-row .v { font-size:14px; font-weight:600; color:var(--text); text-align:right; max-width:58%; }
.info-row .v.accent { color:var(--accent); }
.info-row .v.big {
  font-family:'Bebas Neue',sans-serif; font-size:22px;
  letter-spacing:.5px; color:var(--accent);
}

/* ── TABLE ── */
.lines-table { width:100%; border-collapse:collapse; }
.lines-table thead tr {
  background:rgba(0,212,245,0.04);
  border-bottom:1px solid var(--border);
}
.lines-table th {
  padding:12px 20px;
  font-size:10px; font-weight:700; letter-spacing:1.2px;
  text-transform:uppercase; color:var(--muted);
}
.lines-table td {
  padding:13px 20px;
  font-size:13px; color:var(--muted2);
  border-bottom:1px solid rgba(0,212,245,0.05);
}
.lines-table td:first-child { color:var(--text); font-weight:500; }
.lines-table td:last-child  { color:var(--text); font-weight:700; }
.lines-table tr:last-child td { border:none; }
.lines-table tr:hover td { background:rgba(0,212,245,0.025); }
.qty-badge {
  display:inline-flex; align-items:center; justify-content:center;
  width:28px; height:28px; border-radius:7px;
  background:rgba(0,212,245,0.08); border:1px solid var(--border2);
  font-size:12px; font-weight:700; color:var(--accent);
}

/* ── TOTALS ── */
.totals-strip {
  display:flex; justify-content:flex-end;
  padding:16px 22px;
  border-top:1px solid var(--border);
  background:rgba(0,0,0,0.15);
  flex-wrap:wrap; gap:24px;
}
.tot-item { text-align:right; }
.tot-item .t-label { font-size:10px; color:var(--muted); text-transform:uppercase; letter-spacing:1px; margin-bottom:3px; }
.tot-item .t-val   { font-size:14px; font-weight:700; color:var(--text); }
.tot-item.ttc .t-val {
  font-family:'Bebas Neue',sans-serif; font-size:26px;
  letter-spacing:.5px; color:var(--accent);
}

/* ── EMPTY ── */
.empty-lines {
  padding:40px; text-align:center; color:var(--muted);
  font-size:14px;
}

@keyframes fadeUp { from{opacity:0;transform:translateY(18px)} to{opacity:1;transform:translateY(0)} }
.card:nth-child(1){animation-delay:.04s}
.card:nth-child(2){animation-delay:.1s}
.one-col{animation-delay:.16s}

@media(max-width:768px){
  nav { padding:0 20px; }
  main { padding:32px 20px 60px; }
  .two-col { grid-template-columns:1fr; }
}

/* ══════════════════════════════════════════
   PRINT STYLES  —  clean white paper
═══════════════════════════════════════════ */
@media print {
  .ambient,.grid-bg,nav,.no-print { display:none !important; }
  body { background:#fff !important; color:#111 !important; }
  main { padding:0 !important; max-width:100% !important; }

  .card {
    background:#fff !important; border:1px solid #e2e8f0 !important;
    border-radius:8px !important; backdrop-filter:none !important;
    break-inside:avoid;
  }
  .card:hover { border-color:#e2e8f0 !important; }
  .card-header { background:#f8fafc !important; border-bottom:1px solid #e2e8f0 !important; }
  .card-header-icon { background:#e0f2fe !important; border-color:#bae6fd !important; }
  .card-header-title { color:#475569 !important; }
  .info-row { border-bottom-color:#f1f5f9 !important; }
  .info-row .k { color:#64748b !important; }
  .info-row .v { color:#0f172a !important; }
  .info-row .v.accent { color:#0077a8 !important; }
  .info-row .v.big { color:#0077a8 !important; }

  .lines-table thead tr { background:#f8fafc !important; border-bottom:2px solid #e2e8f0 !important; }
  .lines-table th { color:#64748b !important; }
  .lines-table td { color:#334155 !important; border-bottom-color:#f1f5f9 !important; }
  .lines-table td:first-child { color:#0f172a !important; }
  .lines-table td:last-child  { color:#0f172a !important; }
  .qty-badge { background:#e0f2fe !important; border-color:#bae6fd !important; color:#0077a8 !important; }

  .totals-strip { background:#f8fafc !important; border-top-color:#e2e8f0 !important; }
  .tot-item .t-label { color:#64748b !important; }
  .tot-item .t-val   { color:#0f172a !important; }
  .tot-item.ttc .t-val { color:#0077a8 !important; }

  .page-label { color:#0077a8 !important; }
  .page-label::before { background:#0077a8 !important; }
  .page-title span { color:#0077a8 !important; }
  .page-title { color:#0f172a !important; }
  .badge-pill { background:#f1f5f9 !important; border-color:#e2e8f0 !important; color:#334155 !important; }

  /* Print header watermark */
  .print-header {
    display:flex !important;
    align-items:center; justify-content:space-between;
    padding-bottom:20px; margin-bottom:30px;
    border-bottom:3px solid #00d4f5;
  }
  .print-logo { font-size:28px; font-weight:700; color:#0077a8; letter-spacing:2px; }
  .print-logo-sub { font-size:12px; color:#64748b; margin-top:2px; }
  .print-meta { text-align:right; font-size:11px; color:#64748b; line-height:1.6; }
  .print-meta strong { color:#0f172a; }

  .two-col { page-break-inside:avoid; }
}

/* Hide print header on screen */
.print-header { display:none; }
</style>
</head>
<body>

<div class="ambient"></div>
<div class="grid-bg"></div>

<nav class="no-print">
  <a href="factures.php" class="nav-brand">
    <div class="nav-brand-icon">💧</div>
    AquaStock
  </a>
  <div class="nav-right">
    <a href="factures.php" class="nav-btn">← Retour aux factures</a>
    <button class="nav-btn btn-print" onclick="window.print()">🖨 Imprimer la facture</button>
  </div>
</nav>

<main>

  <!-- Print-only letterhead (hidden on screen) -->
  <div class="print-header">
    <div>
      <div class="print-logo">💧 AquaStock</div>
      <div class="print-logo-sub">Usine d'Eau Minérale — Document Officiel</div>
    </div>
    <div class="print-meta">
      <div>Facture <strong>#<?= $idFacture ?></strong></div>
      <div>Commande <strong>#<?= $data['idCommande'] ?></strong></div>
      <div>Imprimé le <strong><?= $printDate ?></strong></div>
    </div>
  </div>

  <!-- Page header -->
  <div class="page-header no-print">
    <div class="page-label">Document officiel</div>
    <h1 class="page-title">Facture <span>#<?= $idFacture ?></span></h1>
    <div class="badges-row">
      <div class="badge-pill">📦 Commande #<?= $data['idCommande'] ?></div>
      <div class="badge-pill" style="color:<?= $etatFColor ?>; border-color:<?= $etatFColor ?>33;">
        🧾 Facture : <?= $etatFLabel ?>
      </div>
      <div class="badge-pill" style="color:<?= $etatColor ?>; border-color:<?= $etatColor ?>33;">
        📋 Commande : <?= $etatLabel ?>
      </div>
      <div class="badge-pill">📅 <?= htmlspecialchars($data['dateFacture']) ?></div>
    </div>
  </div>

  <!-- ROW 1: Client + Commande -->
  <div class="two-col">

    <!-- Client -->
    <div class="card">
      <div class="card-header">
        <div class="card-header-icon">👤</div>
        <div class="card-header-title">Informations client</div>
      </div>
      <div class="card-body">
        <div class="info-row">
          <span class="k">Nom</span>
          <span class="v"><?= htmlspecialchars($data['client_nom']) ?></span>
        </div>
        <div class="info-row">
          <span class="k">Identifiant</span>
          <span class="v accent"><?= htmlspecialchars($data['login'] ?? '—') ?></span>
        </div>
        <div class="info-row">
          <span class="k">Téléphone</span>
          <span class="v"><?= htmlspecialchars($data['telephone'] ?: '—') ?></span>
        </div>
        <div class="info-row">
          <span class="k">Adresse</span>
          <span class="v"><?= htmlspecialchars($data['adresse'] ?: '—') ?></span>
        </div>
        <div class="info-row">
          <span class="k">Réf. client</span>
          <span class="v" style="color:var(--muted2);">#<?= $data['idClient'] ?></span>
        </div>
      </div>
    </div>

    <!-- Commande & Paiement -->
    <div class="card">
      <div class="card-header">
        <div class="card-header-icon">💳</div>
        <div class="card-header-title">Commande &amp; Paiement</div>
      </div>
      <div class="card-body">
        <div class="info-row">
          <span class="k">N° Commande</span>
          <span class="v accent">#<?= $data['idCommande'] ?></span>
        </div>
        <div class="info-row">
          <span class="k">Date commande</span>
          <span class="v"><?= htmlspecialchars($data['dateCommande'] ?? $data['dateFacture']) ?></span>
        </div>
        <div class="info-row">
          <span class="k">Date facture</span>
          <span class="v"><?= htmlspecialchars($data['dateFacture']) ?></span>
        </div>
        <div class="info-row">
          <span class="k">Mode de paiement</span>
          <span class="v accent"><?= htmlspecialchars($payLabel) ?></span>
        </div>
        <div class="info-row">
          <span class="k">Statut facture</span>
          <span class="v" style="color:<?= $etatFColor ?>;"><?= $etatFLabel ?></span>
        </div>
        <div class="info-row">
          <span class="k">Total TTC</span>
          <span class="v big"><?= number_format($data['montantTC'],2) ?> DZD</span>
        </div>
      </div>
    </div>

  </div><!-- /two-col -->

  <!-- ROW 2: Produits commandés (full width) -->
  <div class="card one-col">
    <div class="card-header">
      <div class="card-header-icon">🛒</div>
      <div class="card-header-title">Produits commandés</div>
    </div>

    <?php if(empty($lines)): ?>
    <div class="empty-lines">Aucune ligne de produit trouvée pour cette commande.</div>
    <?php else: ?>
    <div style="overflow-x:auto;">
      <table class="lines-table">
        <thead>
          <tr>
            <th style="text-align:left;">Produit</th>
            <th style="text-align:center;">Volume</th>
            <th style="text-align:center;">Qté (fardeaux)</th>
            <th style="text-align:right;">Prix / fardeau</th>
            <th style="text-align:right;">Prix unitaire</th>
            <th style="text-align:right;">Sous-total HT</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($lines as $l): ?>
          <tr>
            <td><?= htmlspecialchars($l['nomProduit']) ?></td>
            <td style="text-align:center; color:var(--accent);"><?= htmlspecialchars($l['volume'] ?? '—') ?></td>
            <td style="text-align:center;"><span class="qty-badge"><?= (int)$l['quantite'] ?></span></td>
            <td style="text-align:right;"><?= number_format($l['prixFardeau'],2) ?> DZD</td>
            <td style="text-align:right; color:var(--muted2);"><?= number_format($l['prixUnitaire'],2) ?> DZD</td>
            <td style="text-align:right;"><?= number_format($l['sousTotal'],2) ?> DZD</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>

    <!-- Totals strip -->
    <div class="totals-strip">
      <div class="tot-item">
        <div class="t-label">Sous-total HT</div>
        <div class="t-val"><?= number_format($data['montantTotal'],2) ?> DZD</div>
      </div>
      <div class="tot-item">
        <div class="t-label">TVA (19%)</div>
        <div class="t-val"><?= number_format($data['tva'],2) ?> DZD</div>
      </div>
      <div class="tot-item">
        <div class="t-label">Timbre fiscal</div>
        <div class="t-val"><?= number_format($data['timbre'],2) ?> DZD</div>
      </div>
      <div class="tot-item ttc">
        <div class="t-label">Total TTC</div>
        <div class="t-val"><?= number_format($data['montantTC'],2) ?> DZD</div>
      </div>
    </div>
  </div><!-- /card -->

  <!-- Signature / legal footer (visible in print) -->
  <div style="margin-top:10px; padding:18px 22px; border:1px solid var(--border); border-radius:14px; font-size:12px; color:var(--muted); line-height:1.8; animation:fadeUp .6s cubic-bezier(.22,1,.36,1) both .22s;">
    <span style="color:var(--accent); font-weight:700;">AquaStock</span>
    — Usine d'Eau Minérale &nbsp;·&nbsp;
    Facture générée le <?= $printDate ?>  &nbsp;·&nbsp;
    Commande #<?= $data['idCommande'] ?> &nbsp;·&nbsp;
    Facture #<?= $idFacture ?>
    <span style="float:right; color:var(--muted2);">Document interne — confidentiel</span>
  </div>

</main>

<script>
// Auto-print if ?print=1 in URL
if(new URLSearchParams(location.search).get('print')==='1'){
  window.addEventListener('load', ()=>{ setTimeout(()=>window.print(), 600); });
}
</script>
</body>
</html>
