<?php
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin'){
    header("Location: ../auth/login.php"); exit();
}
$isAdmin = $_SESSION['role'] === 'admin';
require_once "../config/db.php";

$msg = "";
$msgType = "ok";

// ── ADD ───────────────────────────────────────────────────────────────────────
if(isset($_POST['action']) && $_POST['action'] === 'add'){
    $full_name = trim($_POST['full_name']);
    $login     = trim($_POST['login']);
    $motdepasse= trim($_POST['motdepasse']);
    $telephone = trim($_POST['telephone']);
    $email     = trim($_POST['email']);
    $ville     = trim($_POST['ville']);
    $poste     = trim($_POST['poste']);
    $role      = trim($_POST['role']);
    $nom            = explode(' ', $full_name)[0];
    $date_naissance  = trim($_POST['date_naissance'] ?? '');
    $sexe            = trim($_POST['sexe'] ?? '');
    $adresse_membre  = trim($_POST['adresse_membre'] ?? '');
    $wilaya          = trim($_POST['wilaya'] ?? '');
    $localisation    = ($adresse_membre !== '' && $wilaya !== '')
                       ? $adresse_membre . ', ' . $wilaya
                       : ($adresse_membre ?: $wilaya);

    // check login unique
    $chk = $conn->prepare("SELECT idResponsable FROM responsable WHERE login=?");
    $chk->bind_param("s", $login); $chk->execute();
    $chk->store_result();
    if($chk->num_rows > 0){
        $msg = "L'identifiant « $login » est déjà utilisé."; $msgType = "err";
    } elseif(empty($full_name) || empty($login) || empty($motdepasse)){
        $msg = "Nom complet, identifiant et mot de passe sont obligatoires."; $msgType = "err";
    } else {
        $hashedPw = password_hash($motdepasse, PASSWORD_DEFAULT);
        // Responsable ne peut pas créer un admin
        if(!$isAdmin && $role === 'admin') $role = 'responsable_clients';
        $stmt = $conn->prepare("INSERT INTO responsable (nom,full_name,login,motdepasse,telephone,email,ville,poste,role,date_naissance,sexe,localisation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("ssssssssssss",$nom,$full_name,$login,$hashedPw,$telephone,$email,$ville,$poste,$role,$date_naissance,$sexe,$localisation);
        if($stmt->execute()){ $msg = "Membre « $full_name » ajouté avec succès."; }
        else { $msg = "Erreur lors de l'ajout."; $msgType = "err"; }
    }
}

// ── EDIT ──────────────────────────────────────────────────────────────────────
if(isset($_POST['action']) && $_POST['action'] === 'edit'){
    $id        = (int)$_POST['id'];
    $full_name = trim($_POST['full_name']);
    $telephone = trim($_POST['telephone']);
    $email     = trim($_POST['email']);
    $ville     = trim($_POST['ville']);
    $poste     = trim($_POST['poste']);
    $role      = trim($_POST['role']);
    $nom            = explode(' ', $full_name)[0];
    $date_naissance  = trim($_POST['date_naissance'] ?? '');
    $sexe            = trim($_POST['sexe'] ?? '');
    $adresse_membre  = trim($_POST['adresse_membre'] ?? '');
    $wilaya          = trim($_POST['wilaya'] ?? '');
    $localisation    = ($adresse_membre !== '' && $wilaya !== '')
                       ? $adresse_membre . ', ' . $wilaya
                       : ($adresse_membre ?: $wilaya);
    // Responsable ne peut pas promouvoir en admin
    if(!$isAdmin && $role === 'admin') $role = 'responsable_clients';
    $np              = trim($_POST['new_password']);

    if($np !== ''){
        $hashedNp = password_hash($np, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE responsable SET nom=?,full_name=?,telephone=?,email=?,ville=?,poste=?,role=?,motdepasse=?,date_naissance=?,sexe=?,localisation=? WHERE idResponsable=?");
        $stmt->bind_param("sssssssssssi",$nom,$full_name,$telephone,$email,$ville,$poste,$role,$hashedNp,$date_naissance,$sexe,$localisation,$id);
    } else {
        $stmt = $conn->prepare("UPDATE responsable SET nom=?,full_name=?,telephone=?,email=?,ville=?,poste=?,role=?,date_naissance=?,sexe=?,localisation=? WHERE idResponsable=?");
        $stmt->bind_param("ssssssssssi",$nom,$full_name,$telephone,$email,$ville,$poste,$role,$date_naissance,$sexe,$localisation,$id);
    }
    if($stmt->execute()){ $msg = "Informations mises à jour."; }
    else { $msg = "Erreur lors de la mise à jour."; $msgType = "err"; }
}

// ── DELETE ────────────────────────────────────────────────────────────────────
if(isset($_POST['action']) && $_POST['action'] === 'delete'){
    $id = (int)$_POST['id'];
    // prevent deleting own account
    $me = $conn->prepare("SELECT login FROM responsable WHERE idResponsable=?");
    $me->bind_param("i",$id); $me->execute();
    $meRes = $me->get_result()->fetch_assoc();
    if($meRes && $meRes['login'] === $_SESSION['user']){
        $msg = "Vous ne pouvez pas supprimer votre propre compte."; $msgType = "err";
    } else {
        $stmt = $conn->prepare("DELETE FROM responsable WHERE idResponsable=?");
        $stmt->bind_param("i",$id);
        if($stmt->execute()){ $msg = "Membre supprimé."; }
        else { $msg = "Erreur lors de la suppression."; $msgType = "err"; }
    }
}

// ── FETCH ALL ─────────────────────────────────────────────────────────────────
$teamRes = $conn->query("
    SELECT idResponsable,
           COALESCE(NULLIF(full_name,''), nom)          AS full_name,
           nom,
           COALESCE(NULLIF(login,''),'—')               AS login,
           COALESCE(NULLIF(telephone,''),'—')           AS telephone,
           COALESCE(NULLIF(email,''),'—')               AS email,
           COALESCE(NULLIF(ville,''),'—')               AS ville,
           COALESCE(NULLIF(poste,''),'Responsable')     AS poste,
           COALESCE(NULLIF(role,''),'responsable_clients') AS role,
           COALESCE(NULLIF(date_naissance,''),'')         AS date_naissance,
           COALESCE(NULLIF(sexe,''),'')                   AS sexe,
           COALESCE(NULLIF(localisation,''),'—')          AS localisation
    FROM responsable
    ORDER BY FIELD(role,'admin','responsable_clients'), full_name ASC
");
$team = [];
while($r = $teamRes->fetch_assoc()) $team[] = $r;

$admins = array_filter($team, fn($r) => $r['role'] === 'admin');
$resps  = array_filter($team, fn($r) => $r['role'] !== 'admin');

$pageTitle = "Équipe";
include_once "../components/header.php";
?>

<style>
/* ── Page layout ─────────────────────────────────── */
.tm-wrap{max-width:1200px;margin:0 auto;padding:0 4px;}
.tm-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;flex-wrap:wrap;gap:14px;}
.tm-heading{font-family:'Space Grotesk',sans-serif;font-size:24px;font-weight:700;color:var(--text);}
.tm-heading span{color:var(--accent);}

/* ── Alert banner ────────────────────────────────── */
.tm-alert{display:flex;align-items:center;gap:12px;padding:14px 20px;border-radius:12px;font-size:14px;margin-bottom:28px;animation:fadeUp .4s ease;}
.tm-alert.ok {background:rgba(34,211,160,.08);border:1px solid rgba(34,211,160,.3);color:#6ee7b7;}
.tm-alert.err{background:rgba(244,63,94,.08); border:1px solid rgba(244,63,94,.3); color:#fca5a5;}

/* ── Section label ───────────────────────────────── */
.tm-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:var(--muted);margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.tm-label::after{content:'';flex:1;height:1px;background:var(--border);}

/* ── Cards grid ──────────────────────────────────── */
.tm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:18px;margin-bottom:36px;}

/* ── Member card ─────────────────────────────────── */
.tm-card{background:rgba(8,20,40,.7);border:1px solid rgba(255,255,255,.07);border-radius:16px;padding:22px;position:relative;transition:border-color .2s,transform .2s,box-shadow .2s;overflow:hidden;}
.tm-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;border-radius:16px 16px 0 0;}
.tm-card.is-admin::before{background:linear-gradient(90deg,#f43f5e,#fb7185);}
.tm-card.is-resp ::before{background:linear-gradient(90deg,#a78bfa,#c4b5fd);}
.tm-card:hover{transform:translateY(-3px);box-shadow:0 12px 40px rgba(0,0,0,.4);}
.tm-card.is-admin:hover{border-color:rgba(244,63,94,.35);}
.tm-card.is-resp:hover {border-color:rgba(167,139,250,.35);}

/* avatar */
.tm-avatar{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:800;flex-shrink:0;letter-spacing:-1px;}
.is-admin .tm-avatar{background:linear-gradient(135deg,#f43f5e,#fb7185);color:#fff;}
.is-resp  .tm-avatar{background:linear-gradient(135deg,#a78bfa,#c4b5fd);color:#050d1a;}

/* badge */
.tm-badge{padding:3px 10px;border-radius:20px;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.8px;}
.is-admin .tm-badge{background:rgba(244,63,94,.12);border:1px solid rgba(244,63,94,.3);color:#f43f5e;}
.is-resp  .tm-badge{background:rgba(167,139,250,.12);border:1px solid rgba(167,139,250,.3);color:#a78bfa;}

/* info rows */
.tm-info{display:flex;flex-direction:column;gap:7px;border-top:1px solid rgba(255,255,255,.05);padding-top:14px;margin-top:14px;}
.tm-row{display:flex;align-items:center;gap:10px;font-size:13px;}
.tm-row .ico{width:20px;text-align:center;font-size:13px;opacity:.55;flex-shrink:0;}
.tm-row .lbl{font-size:10px;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);width:54px;flex-shrink:0;}
.tm-row .val{color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.tm-row .val.mono{font-family:monospace;font-size:12px;}

/* card actions */
.tm-actions{display:flex;gap:8px;margin-top:16px;}
.btn-edit{flex:1;padding:8px;border-radius:9px;border:1px solid rgba(0,180,216,.3);background:rgba(0,180,216,.06);color:var(--accent);font-size:12px;font-weight:600;cursor:pointer;font-family:'Outfit',sans-serif;transition:all .2s;}
.btn-edit:hover{background:rgba(0,180,216,.15);border-color:var(--accent);}
.btn-del{padding:8px 14px;border-radius:9px;border:1px solid rgba(244,63,94,.25);background:rgba(244,63,94,.06);color:#f43f5e;font-size:12px;font-weight:600;cursor:pointer;font-family:'Outfit',sans-serif;transition:all .2s;}
.btn-del:hover{background:rgba(244,63,94,.15);border-color:#f43f5e;}

/* ── Add member button ───────────────────────────── */
.btn-add{display:inline-flex;align-items:center;gap:10px;padding:11px 22px;border-radius:11px;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#050d1a;font-family:'Space Grotesk',sans-serif;font-size:14px;font-weight:700;border:none;cursor:pointer;transition:all .2s;text-decoration:none;}
.btn-add:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(0,180,216,.35);}

/* ── Modal overlay ───────────────────────────────── */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(6px);z-index:1000;display:none;overflow-y:auto;padding:40px 20px;}
.modal-overlay.open{display:block;}
.modal{background:#0a1628;border:1px solid rgba(0,180,216,.2);border-radius:20px;width:100%;max-width:560px;padding:32px;position:relative;animation:fadeUp .35s ease;margin:0 auto;}
.modal-title{font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:700;color:white;margin-bottom:6px;}
.modal-sub{font-size:13px;color:var(--muted);margin-bottom:28px;}
.modal-close{position:absolute;top:20px;right:20px;width:32px;height:32px;border-radius:8px;border:1px solid rgba(255,255,255,.1);background:#0a1628;color:var(--muted);cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all .2s;z-index:10;}
.modal-close:hover{color:white;background:rgba(255,255,255,.1);}
.modal-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.fg{display:flex;flex-direction:column;gap:6px;}
.fg.full{grid-column:1/-1;}
.fg label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);}
.fg input,.fg select{padding:11px 14px;border-radius:10px;border:1px solid var(--border);background:rgba(0,0,0,.3);color:var(--text);font-size:13px;font-family:'Outfit',sans-serif;outline:none;transition:all .2s;width:100%;}
.fg input:focus,.fg select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(0,180,216,.1);}
.fg select option{background:#0a1628;}
.fg .hint{font-size:11px;color:var(--muted);margin-top:2px;}
.modal-footer{display:flex;gap:10px;margin-top:24px;}
.btn-submit{flex:1;padding:12px;border-radius:10px;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#050d1a;font-family:'Space Grotesk',sans-serif;font-size:14px;font-weight:700;border:none;cursor:pointer;transition:all .2s;}
.btn-submit:hover{transform:translateY(-1px);box-shadow:0 8px 24px rgba(0,180,216,.3);}
.btn-cancel{padding:12px 20px;border-radius:10px;border:1px solid var(--border);background:transparent;color:var(--muted);font-family:'Outfit',sans-serif;font-size:13px;cursor:pointer;transition:all .2s;}
.btn-cancel:hover{color:var(--text);border-color:rgba(255,255,255,.2);}

/* ── Delete confirm modal ────────────────────────── */
.del-modal{background:#0a1628;border:1px solid rgba(244,63,94,.25);border-radius:20px;width:100%;max-width:400px;padding:32px;text-align:center;animation:fadeUp .35s ease;margin:0 auto;}
.del-icon{font-size:48px;margin-bottom:16px;}
.del-title{font-family:'Space Grotesk',sans-serif;font-size:18px;font-weight:700;color:white;margin-bottom:8px;}
.del-sub{font-size:13px;color:var(--muted);margin-bottom:28px;line-height:1.6;}
.btn-confirm-del{width:100%;padding:12px;border-radius:10px;background:#f43f5e;color:white;font-family:'Space Grotesk',sans-serif;font-size:14px;font-weight:700;border:none;cursor:pointer;margin-bottom:10px;transition:all .2s;}
.btn-confirm-del:hover{background:#e11d48;}

/* ── Stats row ───────────────────────────────────── */
.tm-stats{display:flex;gap:16px;margin-bottom:28px;flex-wrap:wrap;}
.tm-stat{flex:1;min-width:140px;background:rgba(8,20,40,.6);border:1px solid var(--border);border-radius:12px;padding:16px 20px;}
.tm-stat .snum{font-family:'Space Grotesk',sans-serif;font-size:28px;font-weight:800;color:var(--accent);}
.tm-stat .slbl{font-size:12px;color:var(--muted);margin-top:2px;}

/* ── Password field ──────────────────────────────── */
.pw-wrap{position:relative;}
.pw-wrap input{padding-right:42px!important;}
.pw-eye{position:absolute;right:13px;top:50%;transform:translateY(-50%);cursor:pointer;font-size:15px;color:var(--muted);user-select:none;transition:color .2s;line-height:1;}
.pw-eye:hover{color:var(--accent);}
.pw-strength{height:4px;border-radius:4px;background:rgba(255,255,255,.07);margin-top:6px;overflow:hidden;}
.pw-bar{height:100%;width:0%;border-radius:4px;transition:width .3s,background .3s;}

.modal-overlay::-webkit-scrollbar{width:5px;}
.modal-overlay::-webkit-scrollbar-track{background:transparent;}
.modal-overlay::-webkit-scrollbar-thumb{background:rgba(0,180,216,.3);border-radius:4px;}

@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:600px){.modal-grid{grid-template-columns:1fr;}.tm-grid{grid-template-columns:1fr;}}
</style>

<?php
function initials($name){
    $parts = array_filter(explode(' ', strtoupper(trim($name))));
    $i = '';
    foreach(array_slice($parts,0,2) as $p) $i .= $p[0];
    return $i ?: '?';
}
?>

<div class="tm-wrap">

<!-- ── Top bar ──────────────────────────────────────────────────────────── -->
<div class="tm-topbar">
    <div>
        <div class="tm-heading">Gestion de l'<span>Équipe</span></div>
        <div style="font-size:13px;color:var(--muted);margin-top:4px;">Admins &amp; responsables — informations &amp; accès</div>
    </div>
    <button class="btn-add" onclick="openAdd()">
        <span style="font-size:18px;">＋</span> Ajouter un membre
    </button>
</div>

<!-- ── Alert ────────────────────────────────────────────────────────────── -->
<?php if($msg): ?>
<div class="tm-alert <?= $msgType ?>">
    <?= $msgType==='ok' ? '✅' : '⚠️' ?> <?= htmlspecialchars($msg) ?>
</div>
<?php endif; ?>

<!-- ── Stats row ────────────────────────────────────────────────────────── -->
<div class="tm-stats">
    <div class="tm-stat">
        <div class="snum"><?= count($team) ?></div>
        <div class="slbl">Total membres</div>
    </div>
    <div class="tm-stat" style="border-color:rgba(244,63,94,.25);">
        <div class="snum" style="color:#f43f5e;"><?= count($admins) ?></div>
        <div class="slbl">Admins</div>
    </div>
    <div class="tm-stat" style="border-color:rgba(167,139,250,.25);">
        <div class="snum" style="color:#a78bfa;"><?= count($resps) ?></div>
        <div class="slbl">Responsables</div>
    </div>
</div>

<!-- ── Admins ────────────────────────────────────────────────────────────── -->
<?php if(!empty($admins)): ?>
<div class="tm-label">⚡ Administrateurs</div>
<div class="tm-grid">
<?php foreach($admins as $m): ?>
    <div class="tm-card is-admin">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:14px;">
            <div style="display:flex;align-items:center;gap:14px;">
                <div class="tm-avatar"><?= initials($m['full_name']) ?></div>
                <div>
                    <div style="font-family:'Space Grotesk',sans-serif;font-size:15px;font-weight:700;color:var(--text);line-height:1.2;"><?= htmlspecialchars($m['full_name']) ?></div>
                    <div style="font-size:12px;color:#f43f5e;margin-top:3px;"><?= htmlspecialchars($m['poste']) ?></div>
                </div>
            </div>
            <span class="tm-badge">Admin</span>
        </div>
        <div class="tm-info">
            <div class="tm-row"><span class="ico">👤</span><span class="lbl">Login</span><span class="val mono"><?= htmlspecialchars($m['login']) ?></span></div>
            <div class="tm-row"><span class="ico">📱</span><span class="lbl">Tél</span><span class="val"><?= htmlspecialchars($m['telephone']) ?></span></div>
            <div class="tm-row"><span class="ico">📍</span><span class="lbl">Ville</span><span class="val"><?= htmlspecialchars($m['ville']) ?></span></div>
            <?php if($m['email'] !== '—'): ?>
            <div class="tm-row"><span class="ico">✉️</span><span class="lbl">Email</span><span class="val"><?= htmlspecialchars($m['email']) ?></span></div>
            <?php endif; ?>
            <?php if($m['date_naissance'] !== ''): ?>
            <div class="tm-row"><span class="ico">🎂</span><span class="lbl">Naissance</span><span class="val"><?= htmlspecialchars(date('d/m/Y', strtotime($m['date_naissance']))) ?></span></div>
            <?php endif; ?>
            <?php if($m['sexe'] !== ''): ?>
            <div class="tm-row"><span class="ico"><?= $m['sexe']==='homme' ? '♂️' : '♀️' ?></span><span class="lbl">Sexe</span><span class="val"><?= ucfirst(htmlspecialchars($m['sexe'])) ?></span></div>
            <?php endif; ?>
            <?php if($m['localisation'] !== '—'): ?>
            <div class="tm-row"><span class="ico">🗺️</span><span class="lbl">Localité</span><span class="val"><?= htmlspecialchars($m['localisation']) ?></span></div>
            <?php endif; ?>
        </div>
        <div class="tm-actions">
            <button class="btn-edit" onclick='openEdit(<?= json_encode($m) ?>)'>✏️ Modifier</button>
            <button class="btn-del"  onclick='openDelete(<?= $m['idResponsable'] ?>, <?= json_encode($m['full_name']) ?>)'>🗑</button>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ── Responsables ──────────────────────────────────────────────────────── -->
<?php if(!empty($resps)): ?>
<div class="tm-label">🛡️ Responsables</div>
<div class="tm-grid">
<?php foreach($resps as $m): ?>
    <div class="tm-card is-resp">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:14px;">
            <div style="display:flex;align-items:center;gap:14px;">
                <div class="tm-avatar"><?= initials($m['full_name']) ?></div>
                <div>
                    <div style="font-family:'Space Grotesk',sans-serif;font-size:15px;font-weight:700;color:var(--text);line-height:1.2;"><?= htmlspecialchars($m['full_name']) ?></div>
                    <div style="font-size:12px;color:#a78bfa;margin-top:3px;"><?= htmlspecialchars($m['poste']) ?></div>
                </div>
            </div>
            <span class="tm-badge">Responsable</span>
        </div>
        <div class="tm-info">
            <div class="tm-row"><span class="ico">👤</span><span class="lbl">Login</span><span class="val mono"><?= htmlspecialchars($m['login']) ?></span></div>
            <div class="tm-row"><span class="ico">📱</span><span class="lbl">Tél</span><span class="val"><?= htmlspecialchars($m['telephone']) ?></span></div>
            <div class="tm-row"><span class="ico">📍</span><span class="lbl">Ville</span><span class="val"><?= htmlspecialchars($m['ville']) ?></span></div>
            <?php if($m['email'] !== '—'): ?>
            <div class="tm-row"><span class="ico">✉️</span><span class="lbl">Email</span><span class="val"><?= htmlspecialchars($m['email']) ?></span></div>
            <?php endif; ?>
            <?php if($m['date_naissance'] !== ''): ?>
            <div class="tm-row"><span class="ico">🎂</span><span class="lbl">Naissance</span><span class="val"><?= htmlspecialchars(date('d/m/Y', strtotime($m['date_naissance']))) ?></span></div>
            <?php endif; ?>
            <?php if($m['sexe'] !== ''): ?>
            <div class="tm-row"><span class="ico"><?= $m['sexe']==='homme' ? '♂️' : '♀️' ?></span><span class="lbl">Sexe</span><span class="val"><?= ucfirst(htmlspecialchars($m['sexe'])) ?></span></div>
            <?php endif; ?>
            <?php if($m['localisation'] !== '—'): ?>
            <div class="tm-row"><span class="ico">🗺️</span><span class="lbl">Localité</span><span class="val"><?= htmlspecialchars($m['localisation']) ?></span></div>
            <?php endif; ?>
        </div>
        <div class="tm-actions">
            <button class="btn-edit" onclick='openEdit(<?= json_encode($m) ?>)'>✏️ Modifier</button>
            <button class="btn-del"  onclick='openDelete(<?= $m['idResponsable'] ?>, <?= json_encode($m['full_name']) ?>)'>🗑</button>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if(empty($team)): ?>
<div style="text-align:center;padding:80px 20px;color:var(--muted);">
    <div style="font-size:48px;margin-bottom:16px;">👥</div>
    <div style="font-size:16px;margin-bottom:8px;">Aucun membre</div>
    <div style="font-size:13px;">Cliquez sur « Ajouter un membre » pour commencer.</div>
</div>
<?php endif; ?>

</div><!-- /tm-wrap -->

<!-- ════════════════════════════════ ADD MODAL ════════════════════════════ -->
<div class="modal-overlay" id="addModal">
<div class="modal">
    <button class="modal-close" onclick="closeModal('addModal')">✕</button>
    <div class="modal-title">Nouveau membre</div>
    <div class="modal-sub">Remplissez les informations du nouveau membre</div>
    <form method="POST" onsubmit="return validateAddForm(this)">
    <input type="hidden" name="action" value="add">
    <div class="modal-grid">
        <div class="fg full">
            <label>Nom complet *</label>
            <input type="text" name="full_name" placeholder="ex: BEN FELLAH IKRAM" required>
        </div>
        <div class="fg">
            <label>Identifiant (login) *</label>
            <input type="text" name="login" placeholder="ex: benfellah" required>
        </div>
        <div class="fg">
            <label>Mot de passe *</label>
            <div class="pw-wrap">
                <input type="password" name="motdepasse" id="addPw" placeholder="••••••••" required oninput="checkStrength(this,'addStrength');checkConfirm('addPw','addPwConfirm','addPwMatch')">
                <span class="pw-eye" onclick="togglePw('addPw',this)">👁</span>
            </div>
            <div class="pw-strength" id="addStrength"><div class="pw-bar"></div></div>
            <span class="hint" id="addHint"></span>
        </div>
        <div class="fg">
            <label>Confirmer le mot de passe *</label>
            <div class="pw-wrap">
                <input type="password" id="addPwConfirm" placeholder="••••••••" required oninput="checkConfirm('addPw','addPwConfirm','addPwMatch')">
                <span class="pw-eye" onclick="togglePw('addPwConfirm',this)">👁</span>
            </div>
            <span class="hint" id="addPwMatch"></span>
        </div>
        <div class="fg">
            <label>Téléphone</label>
            <input type="tel" name="telephone" placeholder="0650 000 000">
        </div>
        <div class="fg">
            <label>Email</label>
            <input type="email" name="email" placeholder="exemple@gmail.com">
        </div>
        <div class="fg">
            <label>Ville</label>
            <input type="text" name="ville" placeholder="Alger, Boumerdes…">
        </div>
        <div class="fg">
            <label>Poste</label>
            <input type="text" name="poste" placeholder="Responsable Clients">
        </div>
        <div class="fg">
            <label>Rôle</label>
            <select name="role">
                <option value="responsable_clients">Responsable</option>
                <?php if($isAdmin): ?>
                <option value="admin">Admin</option>
                <?php endif; ?>
            </select>
        </div>
        <div class="fg">
            <label>Date de naissance</label>
            <input type="date" name="date_naissance">
        </div>
        <div class="fg">
            <label>Sexe</label>
            <select name="sexe">
                <option value="">— Non précisé —</option>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
        </div>
        <div class="fg full">
            <label>Wilaya</label>
            <select name="wilaya" id="addWilaya">

                <option value="">— Sélectionner une wilaya —</option>
                <option value="01 - Adrar">01 - Adrar</option>
                <option value="02 - Chlef">02 - Chlef</option>
                <option value="03 - Laghouat">03 - Laghouat</option>
                <option value="04 - Oum El Bouaghi">04 - Oum El Bouaghi</option>
                <option value="05 - Batna">05 - Batna</option>
                <option value="06 - Béjaïa">06 - Béjaïa</option>
                <option value="07 - Biskra">07 - Biskra</option>
                <option value="08 - Béchar">08 - Béchar</option>
                <option value="09 - Blida">09 - Blida</option>
                <option value="10 - Bouira">10 - Bouira</option>
                <option value="11 - Tamanrasset">11 - Tamanrasset</option>
                <option value="12 - Tébessa">12 - Tébessa</option>
                <option value="13 - Tlemcen">13 - Tlemcen</option>
                <option value="14 - Tiaret">14 - Tiaret</option>
                <option value="15 - Tizi Ouzou">15 - Tizi Ouzou</option>
                <option value="16 - Alger">16 - Alger</option>
                <option value="17 - Djelfa">17 - Djelfa</option>
                <option value="18 - Jijel">18 - Jijel</option>
                <option value="19 - Sétif">19 - Sétif</option>
                <option value="20 - Saïda">20 - Saïda</option>
                <option value="21 - Skikda">21 - Skikda</option>
                <option value="22 - Sidi Bel Abbès">22 - Sidi Bel Abbès</option>
                <option value="23 - Annaba">23 - Annaba</option>
                <option value="24 - Guelma">24 - Guelma</option>
                <option value="25 - Constantine">25 - Constantine</option>
                <option value="26 - Médéa">26 - Médéa</option>
                <option value="27 - Mostaganem">27 - Mostaganem</option>
                <option value="28 - M'Sila">28 - M'Sila</option>
                <option value="29 - Mascara">29 - Mascara</option>
                <option value="30 - Ouargla">30 - Ouargla</option>
                <option value="31 - Oran">31 - Oran</option>
                <option value="32 - El Bayadh">32 - El Bayadh</option>
                <option value="33 - Illizi">33 - Illizi</option>
                <option value="34 - Bordj Bou Arréridj">34 - Bordj Bou Arréridj</option>
                <option value="35 - Boumerdès">35 - Boumerdès</option>
                <option value="36 - El Tarf">36 - El Tarf</option>
                <option value="37 - Tindouf">37 - Tindouf</option>
                <option value="38 - Tissemsilt">38 - Tissemsilt</option>
                <option value="39 - El Oued">39 - El Oued</option>
                <option value="40 - Khenchela">40 - Khenchela</option>
                <option value="41 - Souk Ahras">41 - Souk Ahras</option>
                <option value="42 - Tipaza">42 - Tipaza</option>
                <option value="43 - Mila">43 - Mila</option>
                <option value="44 - Aïn Defla">44 - Aïn Defla</option>
                <option value="45 - Naâma">45 - Naâma</option>
                <option value="46 - Aïn Témouchent">46 - Aïn Témouchent</option>
                <option value="47 - Ghardaïa">47 - Ghardaïa</option>
                <option value="48 - Relizane">48 - Relizane</option>
                <option value="49 - El M'Ghair">49 - El M'Ghair</option>
                <option value="50 - El Menia">50 - El Menia</option>
                <option value="51 - Ouled Djellal">51 - Ouled Djellal</option>
                <option value="52 - Bordj Baji Mokhtar">52 - Bordj Baji Mokhtar</option>
                <option value="53 - Béni Abbès">53 - Béni Abbès</option>
                <option value="54 - Timimoun">54 - Timimoun</option>
                <option value="55 - Touggourt">55 - Touggourt</option>
                <option value="56 - Djanet">56 - Djanet</option>
                <option value="57 - In Salah">57 - In Salah</option>
                <option value="58 - In Guezzam">58 - In Guezzam</option>
            </select>
        </div>
        <div class="fg full">
            <label>Adresse / Localisation</label>
            <input type="text" name="adresse_membre" placeholder="ex: Dar El Beïda, Kouba, Bab Ezzouar…">
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn-cancel" onclick="closeModal('addModal')">Annuler</button>
        <button type="submit" class="btn-submit">Ajouter le membre →</button>
    </div>
    </form>
</div>
</div>

<!-- ════════════════════════════════ EDIT MODAL ═══════════════════════════ -->
<div class="modal-overlay" id="editModal">
<div class="modal">
    <button class="modal-close" onclick="closeModal('editModal')">✕</button>
    <div class="modal-title">Modifier le membre</div>
    <div class="modal-sub" id="editSub">Modification des informations</div>
    <form method="POST" onsubmit="return validateEditForm(this)">
    <input type="hidden" name="action" value="edit">
    <input type="hidden" name="id" id="editId">
    <div class="modal-grid">
        <div class="fg full">
            <label>Nom complet *</label>
            <input type="text" name="full_name" id="editFullName" required>
        </div>
        <div class="fg">
            <label>Téléphone</label>
            <input type="tel" name="telephone" id="editTel">
        </div>
        <div class="fg">
            <label>Email</label>
            <input type="email" name="email" id="editEmail">
        </div>
        <div class="fg">
            <label>Ville</label>
            <input type="text" name="ville" id="editVille">
        </div>
        <div class="fg">
            <label>Poste</label>
            <input type="text" name="poste" id="editPoste">
        </div>
        <div class="fg">
            <label>Rôle</label>
            <select name="role" id="editRole">
                <option value="responsable_clients">Responsable</option>
                <?php if($isAdmin): ?>
                <option value="admin">Admin</option>
                <?php endif; ?>
            </select>
        </div>
        <div class="fg">
            <label>Date de naissance</label>
            <input type="date" name="date_naissance" id="editDateNaissance">
        </div>
        <div class="fg">
            <label>Sexe</label>
            <select name="sexe" id="editSexe">
                <option value="">— Non précisé —</option>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
        </div>
        <div class="fg full">
            <label>Wilaya</label>
            <select name="wilaya" id="editWilaya">

                <option value="">— Sélectionner une wilaya —</option>
                <option value="01 - Adrar">01 - Adrar</option>
                <option value="02 - Chlef">02 - Chlef</option>
                <option value="03 - Laghouat">03 - Laghouat</option>
                <option value="04 - Oum El Bouaghi">04 - Oum El Bouaghi</option>
                <option value="05 - Batna">05 - Batna</option>
                <option value="06 - Béjaïa">06 - Béjaïa</option>
                <option value="07 - Biskra">07 - Biskra</option>
                <option value="08 - Béchar">08 - Béchar</option>
                <option value="09 - Blida">09 - Blida</option>
                <option value="10 - Bouira">10 - Bouira</option>
                <option value="11 - Tamanrasset">11 - Tamanrasset</option>
                <option value="12 - Tébessa">12 - Tébessa</option>
                <option value="13 - Tlemcen">13 - Tlemcen</option>
                <option value="14 - Tiaret">14 - Tiaret</option>
                <option value="15 - Tizi Ouzou">15 - Tizi Ouzou</option>
                <option value="16 - Alger">16 - Alger</option>
                <option value="17 - Djelfa">17 - Djelfa</option>
                <option value="18 - Jijel">18 - Jijel</option>
                <option value="19 - Sétif">19 - Sétif</option>
                <option value="20 - Saïda">20 - Saïda</option>
                <option value="21 - Skikda">21 - Skikda</option>
                <option value="22 - Sidi Bel Abbès">22 - Sidi Bel Abbès</option>
                <option value="23 - Annaba">23 - Annaba</option>
                <option value="24 - Guelma">24 - Guelma</option>
                <option value="25 - Constantine">25 - Constantine</option>
                <option value="26 - Médéa">26 - Médéa</option>
                <option value="27 - Mostaganem">27 - Mostaganem</option>
                <option value="28 - M'Sila">28 - M'Sila</option>
                <option value="29 - Mascara">29 - Mascara</option>
                <option value="30 - Ouargla">30 - Ouargla</option>
                <option value="31 - Oran">31 - Oran</option>
                <option value="32 - El Bayadh">32 - El Bayadh</option>
                <option value="33 - Illizi">33 - Illizi</option>
                <option value="34 - Bordj Bou Arréridj">34 - Bordj Bou Arréridj</option>
                <option value="35 - Boumerdès">35 - Boumerdès</option>
                <option value="36 - El Tarf">36 - El Tarf</option>
                <option value="37 - Tindouf">37 - Tindouf</option>
                <option value="38 - Tissemsilt">38 - Tissemsilt</option>
                <option value="39 - El Oued">39 - El Oued</option>
                <option value="40 - Khenchela">40 - Khenchela</option>
                <option value="41 - Souk Ahras">41 - Souk Ahras</option>
                <option value="42 - Tipaza">42 - Tipaza</option>
                <option value="43 - Mila">43 - Mila</option>
                <option value="44 - Aïn Defla">44 - Aïn Defla</option>
                <option value="45 - Naâma">45 - Naâma</option>
                <option value="46 - Aïn Témouchent">46 - Aïn Témouchent</option>
                <option value="47 - Ghardaïa">47 - Ghardaïa</option>
                <option value="48 - Relizane">48 - Relizane</option>
                <option value="49 - El M'Ghair">49 - El M'Ghair</option>
                <option value="50 - El Menia">50 - El Menia</option>
                <option value="51 - Ouled Djellal">51 - Ouled Djellal</option>
                <option value="52 - Bordj Baji Mokhtar">52 - Bordj Baji Mokhtar</option>
                <option value="53 - Béni Abbès">53 - Béni Abbès</option>
                <option value="54 - Timimoun">54 - Timimoun</option>
                <option value="55 - Touggourt">55 - Touggourt</option>
                <option value="56 - Djanet">56 - Djanet</option>
                <option value="57 - In Salah">57 - In Salah</option>
                <option value="58 - In Guezzam">58 - In Guezzam</option>
            </select>
        </div>
        <div class="fg full">
            <label>Adresse / Localisation</label>
            <input type="text" name="adresse_membre" id="editAdresse" placeholder="ex: Dar El Beïda, Kouba, Bab Ezzouar…">
        </div>
        <div class="fg full">
            <label style="display:flex;align-items:center;justify-content:space-between;">
                <span>Nouveau mot de passe <span style="color:var(--muted);font-size:9px;font-weight:400;text-transform:none;letter-spacing:0;">(laisser vide pour ne pas changer)</span></span>
                <button type="button" id="editPwClearBtn" onclick="clearEditPassword()" style="display:none;font-size:10px;color:#f43f5e;background:none;border:none;cursor:pointer;padding:0;font-family:'Outfit',sans-serif;font-weight:600;">✕ Annuler</button>
            </label>
            <div class="pw-wrap">
                <input type="password" name="new_password" id="editPw" placeholder="Laisser vide pour ne pas changer" oninput="checkStrength(this,'editStrength');checkConfirm('editPw','editPwConfirm','editPwMatch');toggleEditPwClear()">
                <span class="pw-eye" onclick="togglePw('editPw',this)">👁</span>
            </div>
            <div class="pw-strength" id="editStrength" style="display:none"><div class="pw-bar"></div></div>
        </div>
        <div class="fg full" id="editConfirmWrap" style="display:none;">
            <label>Confirmer le nouveau mot de passe</label>
            <div class="pw-wrap">
                <input type="password" id="editPwConfirm" placeholder="••••••••" oninput="checkConfirm('editPw','editPwConfirm','editPwMatch')">
                <span class="pw-eye" onclick="togglePw('editPwConfirm',this)">👁</span>
            </div>
            <span class="hint" id="editPwMatch"></span>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn-cancel" onclick="closeModal('editModal')">Annuler</button>
        <button type="submit" class="btn-submit">Enregistrer les modifications ✓</button>
    </div>
    </form>
</div>
</div>

<!-- ══════════════════════════════ DELETE MODAL ═══════════════════════════ -->
<div class="modal-overlay" id="delModal" style="display:none;align-items:center;justify-content:center;">
<div class="del-modal">
    <div class="del-icon">🗑️</div>
    <div class="del-title">Confirmer la suppression</div>
    <div class="del-sub" id="delSub">Êtes-vous sûr de vouloir supprimer ce membre ?<br>Cette action est irréversible.</div>
    <form method="POST">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="delId">
    <button type="submit" class="btn-confirm-del">Oui, supprimer définitivement</button>
    </form>
    <button class="btn-cancel" style="width:100%;padding:10px;border-radius:10px;" onclick="closeModal('delModal')">Annuler</button>
</div>
</div>

<script>
function clearEditPassword(){
    document.getElementById('editPw').value = '';
    document.getElementById('editPwConfirm').value = '';
    document.getElementById('editPwMatch').textContent = '';
    document.getElementById('editConfirmWrap').style.display = 'none';
    document.getElementById('editStrength').style.display = 'none';
    document.getElementById('editStrength').querySelector('.pw-bar').style.width = '0%';
    document.getElementById('editPwClearBtn').style.display = 'none';
    document.getElementById('editPw').style.borderColor = '';
}

function toggleEditPwClear(){
    const pw = document.getElementById('editPw');
    const btn = document.getElementById('editPwClearBtn');
    if(btn) btn.style.display = pw.value.length ? 'inline' : 'none';
}

function checkConfirm(pwId, confirmId, matchId){
    const pw = document.getElementById(pwId);
    const cf = document.getElementById(confirmId);
    const mt = document.getElementById(matchId);
    if(!pw || !cf || !mt) return;
    // show confirm wrap for edit modal when password is typed
    if(pwId === 'editPw'){
        const wrap = document.getElementById('editConfirmWrap');
        if(wrap) wrap.style.display = pw.value.length ? 'block' : 'none';
    }
    if(!cf.value) { mt.textContent=''; cf.style.borderColor=''; return; }
    const match = pw.value === cf.value;
    mt.textContent = match ? '✅ Les mots de passe correspondent.' : '❌ Les mots de passe ne correspondent pas.';
    mt.style.color  = match ? '#22d3a0' : '#f43f5e';
    cf.style.borderColor = match ? 'rgba(34,211,160,.5)' : 'rgba(244,63,94,.5)';
}

function validateAddForm(form){
    const pw = document.getElementById('addPw').value;
    const cf = document.getElementById('addPwConfirm').value;
    if(pw !== cf){
        document.getElementById('addPwMatch').textContent = '❌ Les mots de passe ne correspondent pas.';
        document.getElementById('addPwMatch').style.color = '#f43f5e';
        return false;
    }
    return true;
}

function validateEditForm(form){
    const pw = document.getElementById('editPw').value;
    const cf = document.getElementById('editPwConfirm').value;
    if(pw && pw !== cf){
        document.getElementById('editPwMatch').textContent = '❌ Les mots de passe ne correspondent pas.';
        document.getElementById('editPwMatch').style.color = '#f43f5e';
        return false;
    }
    return true;
}

function togglePw(inputId, eyeEl){
    const inp = document.getElementById(inputId);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    eyeEl.textContent = inp.type === 'password' ? '👁' : '🙈';
}

function checkStrength(inp, barId){
    const v = inp.value;
    const bar = document.getElementById(barId);
    if(!bar) return;
    bar.style.display = v.length ? 'block' : 'none';
    const b = bar.querySelector('.pw-bar');
    let score = 0;
    if(v.length >= 8) score++;
    if(/[A-Z]/.test(v)) score++;
    if(/[0-9]/.test(v)) score++;
    if(/[^A-Za-z0-9]/.test(v)) score++;
    const pct = [0,25,50,75,100][score];
    const clr = ['','#f43f5e','#fb923c','#facc15','#22d3a0'][score];
    b.style.width = pct + '%';
    b.style.background = clr;
    const hint = inp.closest('.fg')?.querySelector('.hint:not([class*="⚠"])') || inp.parentElement.nextElementSibling?.nextElementSibling;
    const labels = ['','Très faible','Faible','Moyen','Fort'];
    if(hint && !hint.textContent.includes('⚠')) hint.textContent = v.length ? labels[score] : '';
}

function openAdd(){
    const o = document.getElementById('addModal');
    o.style.display = 'block'; o.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeModal(id){
    const o = document.getElementById(id);
    o.style.display = 'none'; o.classList.remove('open');
    document.body.style.overflow = '';
}

function openEdit(m){
    document.getElementById('editId').value       = m.idResponsable;
    document.getElementById('editFullName').value = m.full_name;
    document.getElementById('editTel').value      = m.telephone === '—' ? '' : m.telephone;
    document.getElementById('editEmail').value    = m.email     === '—' ? '' : m.email;
    document.getElementById('editVille').value    = m.ville     === '—' ? '' : m.ville;
    document.getElementById('editPoste').value    = m.poste;
    document.getElementById('editRole').value          = m.role;
    document.getElementById('editDateNaissance').value  = m.date_naissance || '';
    document.getElementById('editSexe').value           = m.sexe || '';
    // localisation stored as "adresse, wilaya" — split for editing
    const loc = (m.localisation && m.localisation !== '—') ? m.localisation : '';
    const wilayas = Array.from(document.getElementById('editWilaya').options).map(o => o.value);
    let editWil = '', editAdr = loc;
    if (loc) {
        const matchedWil = wilayas.find(w => w !== '' && loc.endsWith(w));
        if (matchedWil) {
            editWil = matchedWil;
            editAdr = loc.slice(0, loc.length - matchedWil.length).replace(/,\s*$/, '').trim();
        }
    }
    document.getElementById('editWilaya').value = editWil;
    document.getElementById('editAdresse').value = editAdr;
    document.getElementById('editSub').textContent = 'Modification : ' + m.full_name;
    // reset confirm password field
    document.getElementById('editPw').value = '';
    document.getElementById('editPwConfirm').value = '';
    document.getElementById('editPwMatch').textContent = '';
    document.getElementById('editConfirmWrap').style.display = 'none';
    document.getElementById('editStrength').style.display = 'none';
    document.getElementById('editPwClearBtn').style.display = 'none';
    const o = document.getElementById('editModal');
    o.style.display = 'block'; o.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function openDelete(id, name){
    document.getElementById('delId').value = id;
    document.getElementById('delSub').innerHTML =
        'Êtes-vous sûr de vouloir supprimer <strong style="color:white;">' +
        name + '</strong> ?<br><span style="color:#f43f5e;font-size:12px;">Cette action est irréversible.</span>';
    const o = document.getElementById('delModal');
    o.style.display = 'flex'; o.classList.add('open');
    document.body.style.overflow = 'hidden';
}

// Close on backdrop click
document.querySelectorAll('.modal-overlay').forEach(o => {
    o.addEventListener('click', e => {
        if(e.target === o){ o.style.display='none'; o.classList.remove('open'); document.body.style.overflow=''; }
    });
});
</script>

<script>


<?php include_once "../components/footer.php"; ?>