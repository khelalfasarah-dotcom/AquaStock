<?php
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin'){ header("Location: ../auth/login.php"); exit(); }
require_once "../config/db.php";
require_once "../controllers/ProduitController.php";
$msg = '';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])){
    if($_POST['action']==='add'){
        $nom          = trim($_POST['nomProduit']);
        $vol          = trim($_POST['volume']);
        $prixUnit     = (float)$_POST['prixUnitaire'];
        $btParFardeau = (int)$_POST['btParFardeau'];
        $prixFardeau  = round($prixUnit * $btParFardeau, 2);
        $qtyFardeaux  = (int)$_POST['quantiteStock'];
        $qtyBouteilles = $qtyFardeaux * $btParFardeau;

        if(!$nom || !$vol || $prixUnit <= 0 || $btParFardeau <= 0){
            $msg = 'error:Veuillez remplir tous les champs obligatoires.';
        } else {
            $chk = $conn->prepare("SELECT COUNT(*) as c FROM produit WHERE nomProduit=? AND volume=?");
            $chk->bind_param("ss", $nom, $vol);
            $chk->execute();
            $exists = (int)$chk->get_result()->fetch_assoc()['c'];
            $chk->close();
            if($exists > 0){
                $msg = 'error:Ce produit (' . htmlspecialchars($nom) . ' ' . htmlspecialchars($vol) . ') existe déjà.';
            } else {
                $stmt = $conn->prepare("INSERT INTO produit (nomProduit, volume, prixUnitaire, prixFardeau, btParFardeau, quantiteStock) VALUES (?,?,?,?,?,?)");
                $stmt->bind_param("ssddii", $nom, $vol, $prixUnit, $prixFardeau, $btParFardeau, $qtyBouteilles);
                $stmt->execute();
                $msg='success:Produit ajouté !';
            }
        }

    } elseif($_POST['action']==='delete'){
        $pid = (int)$_POST['id'];
        $conn->query("DELETE FROM ligne_produit WHERE idProduit=$pid");
        $ctrl->destroy($pid);
        $msg='success:Produit supprimé.';

    } elseif($_POST['action']==='update_stock'){
        $pid           = (int)$_POST['id'];
        $newFardeaux   = (int)$_POST['new_qty'];
        $btParFardeau  = (int)$_POST['btParFardeau'];
        $newBouteilles = $newFardeaux * $btParFardeau;
        $stmt2 = $conn->prepare("UPDATE produit SET quantiteStock=? WHERE idProduit=?");
        $stmt2->bind_param("ii", $newBouteilles, $pid);
        $stmt2->execute();
        $msg='success:Stock mis à jour !';

    } elseif($_POST['action']==='update_price'){
        $pid      = (int)$_POST['id'];
        $prixUnit = (float)$_POST['prixUnitaire'];
        $bts      = (int)$_POST['btParFardeau'];
        $prixFard = round($prixUnit * $bts, 2);
        $stmt3    = $conn->prepare("UPDATE produit SET prixUnitaire=?, prixFardeau=? WHERE idProduit=?");
        $stmt3->bind_param("ddi", $prixUnit, $prixFard, $pid);
        $stmt3->execute();
        $msg='success:Prix mis à jour !';
    }
}

/* ✅ ONLY FIX HERE: PRODUCT ORDER */
$produits = $conn->query("
    SELECT * FROM produit
    ORDER BY nomProduit, volume
");
$produitsRows = [];
if($produits) while($r = $produits->fetch_assoc()) $produitsRows[] = $r;

// Pre-fetch distinct names and volumes for datalist
$existingNames   = [];
$existingVolumes = [];
$rn = $conn->query("SELECT DISTINCT nomProduit FROM produit ORDER BY nomProduit");
if($rn) while($r = $rn->fetch_assoc()) $existingNames[] = $r['nomProduit'];
$rv = $conn->query("SELECT DISTINCT volume FROM produit ORDER BY volume");
if($rv) while($r = $rv->fetch_assoc()) $existingVolumes[] = $r['volume'];

$pageTitle = "Produits";
include_once "../components/header.php";
?>
<?php if($msg): list($type,$text) = explode(':', $msg, 2); ?>
<div class="alert alert-<?= $type==='success'?'success':'error' ?>">
    <?= $type==='success'?'✅':'❌' ?> <?= htmlspecialchars($text) ?>
</div>
<?php endif; ?>

<div class="card" style="margin-bottom:24px;">
    <div class="section-title">➕ Ajouter un produit</div>
    <form method="POST">
        <input type="hidden" name="action" value="add">
        <?php
        // existingNames and existingVolumes already fetched above
        ?>
        <datalist id="brandList">
            <?php foreach($existingNames as $n): ?>
            <option value="<?= htmlspecialchars($n) ?>">
            <?php endforeach; ?>
        </datalist>
        <datalist id="volumeList">
            <?php foreach($existingVolumes as $v): ?>
            <option value="<?= htmlspecialchars($v) ?>">
            <?php endforeach; ?>
        </datalist>
        <div class="form-row">
            <div class="form-group">
                <label>Marque *</label>
                <input type="text" name="nomProduit" list="brandList" placeholder="ex: NAQAA" required autocomplete="off">
            </div>
            <div class="form-group" style="max-width:110px;">
                <label>Volume *</label>
                <input type="text" name="volume" list="volumeList" placeholder="ex: 1.5L" required autocomplete="off">
            </div>
            <div class="form-group" style="max-width:150px;">
                <label>Prix / bouteille (DA) *</label>
                <input type="number" name="prixUnitaire" step="0.5" min="0" placeholder="30" required>
            </div>
            <div class="form-group" style="max-width:140px;">
                <label>Bts / fardeau *</label>
                <input type="number" name="btParFardeau" min="1" placeholder="6" required>
            </div>
            <div class="form-group" style="max-width:160px;">
                <label>Stock initial (fardeaux)</label>
                <input type="number" name="quantiteStock" min="0" value="0">
            </div>
            <div class="form-group" style="flex:0;min-width:auto;">
                <label>&nbsp;</label>
                <button class="btn btn-primary" type="submit">Ajouter</button>
            </div>
        </div>
    </form>
</div>

<div class="card">
    <div class="section-title">🍶 Inventaire des produits</div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Volume</th>
                <th>Prix / bts (DA)</th>
                <th>Bts / fardeau</th>
                <th>Prix fardeau (DA)</th>
                <th>Stock (fardeaux)</th>
                <th>Modifier stock</th>
                <th>Modifier prix</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(empty($produitsRows)): ?>
        <tr><td colspan="10" class="empty-state">Aucun produit.</td></tr>
        <?php else: foreach($produitsRows as $r):
            $fardeaux = floor($r['quantiteStock'] / $r['btParFardeau']);
        ?>
        <tr>
            <td><span class="badge badge-blue">#<?= $r['idProduit'] ?></span></td>
            <td><?= htmlspecialchars($r['nomProduit']) ?></td>
            <td><span class="badge badge-blue"><?= htmlspecialchars($r['volume']) ?></span></td>
            <td><?= number_format($r['prixUnitaire'], 2) ?> DA</td>
            <td><?= $r['btParFardeau'] ?> bts</td>
            <td><?= number_format($r['prixFardeau'], 2) ?> DA</td>
            <td class="<?= $fardeaux < 5 ? 'low-stock' : '' ?>">
                <?= $fardeaux ?> fardeaux <?= $fardeaux < 5 ? '⚠️' : '' ?>
            </td>
            <td>
                <form method="POST" style="display:flex;gap:6px;align-items:center;">
                    <input type="hidden" name="action" value="update_stock">
                    <input type="hidden" name="id" value="<?= $r['idProduit'] ?>">
                    <input type="hidden" name="btParFardeau" value="<?= $r['btParFardeau'] ?>">
                    <input type="number" name="new_qty" value="<?= $fardeaux ?>" min="0" style="width:80px;padding:6px 8px;border-radius:6px;border:1px solid var(--border);background:rgba(0,0,0,0.3);color:white;font-size:13px;" title="Nombre de fardeaux">
                    <button class="btn btn-success btn-sm" type="submit">💾</button>
                </form>
            </td>
            <td>
                <form method="POST" style="display:flex;gap:6px;align-items:center;">
                    <input type="hidden" name="action" value="update_price">
                    <input type="hidden" name="id" value="<?= $r['idProduit'] ?>">
                    <input type="hidden" name="btParFardeau" value="<?= $r['btParFardeau'] ?>">
                    <input type="number" name="prixUnitaire" value="<?= $r['prixUnitaire'] ?>" min="0" step="0.5" style="width:80px;padding:6px 8px;border-radius:6px;border:1px solid var(--border);background:rgba(0,0,0,0.3);color:white;font-size:13px;" title="Prix par bouteille">
                    <button class="btn btn-success btn-sm" type="submit">💾</button>
                </form>
            </td>
            <td>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer ce produit et toutes ses lignes de commande ?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $r['idProduit'] ?>">
                    <button class="btn btn-danger btn-sm" type="submit">🗑 Supprimer</button>
                </form>
            </td>
        </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
    </div>
</div>


<?php include_once "../components/footer.php"; ?>