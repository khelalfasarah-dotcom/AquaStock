<?php
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin'){ header("Location: ../auth/login.php"); exit(); }
require_once "../config/db.php";
require_once "../controllers/CommandeController.php";

$ctrl = new CommandeController($conn);
$msg  = '';

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])){
    if($_POST['action']==='update_status'){
        $newStatus = $_POST['status'];
        $cmdId = (int)$_POST['id'];

        // Get current status before changing
        $curRes = $conn->query("SELECT etatCommande FROM commande WHERE idCommande=$cmdId");
        $curStatus = $curRes->fetch_assoc()['etatCommande'] ?? '';

        // Update commande status
        $ctrl->updateStatus($cmdId, $newStatus);

        // Commande and Facture are FULLY INDEPENDENT — confirming/annulling commande does NOT touch facture

        // ── Notification client ────────────────────────────────────────────
        // Fetch client id for this commande
        $clientRes = $conn->query("SELECT idClient FROM commande WHERE idCommande=$cmdId");
        $clientRow = $clientRes ? $clientRes->fetch_assoc() : null;
        $notifClientId = $clientRow ? (int)$clientRow['idClient'] : 0;

        if($notifClientId > 0){
            if($newStatus === 'validee'){
                $notifMsg = $conn->escape_string("✅ Votre commande #$cmdId a été validée. Elle sera bientôt livrée et nous vous contacterons par téléphone.");
                $notifType = 'validee';
            } elseif($newStatus === 'annulee'){
                $notifMsg = $conn->escape_string("❌ Votre commande #$cmdId a été annulée. Contactez-nous pour plus d'informations.");
                $notifType = 'annulee';
            } else {
                $notifMsg = '';
            }
            if($notifMsg !== ''){
                $conn->query("INSERT INTO notifications (idClient, idCommande, message, type) VALUES ($notifClientId, $cmdId, '$notifMsg', '$notifType')");
            }
        }
        // ── End notification ───────────────────────────────────────────────

        if($newStatus === 'validee'){
            // Update commande payment mode only
            if(!empty($_POST['modePaiement'])){
                $mp = $conn->escape_string($_POST['modePaiement']);
                $conn->query("UPDATE commande SET modePaiement='$mp' WHERE idCommande=$cmdId");
                // Facture NOT touched here
            }
            // Stock already deducted at checkout - no deduction needed on validation







        } elseif($newStatus === 'annulee'){
            // Restore stock (deducted at checkout, so restore for any active status)
            if($curStatus === 'en_cours' || $curStatus === 'validee'){
                $lines = $conn->query("SELECT lp.idProduit, lp.quantite, pr.btParFardeau FROM ligne_produit lp JOIN produit pr ON pr.idProduit=lp.idProduit WHERE lp.idCommande=$cmdId");
                while($l = $lines->fetch_assoc()){
                    $bottles = $l['quantite'] * $l['btParFardeau'];
                    $conn->query("UPDATE produit SET quantiteStock = quantiteStock + $bottles WHERE idProduit={$l['idProduit']}");
                }
            }
        }

        $msg='success:Statut de la commande mis à jour.';
    } elseif($_POST['action']==='delete'){
        $id = (int)$_POST['id'];
        $conn->query("DELETE FROM facture WHERE idCommande=$id");
        $conn->query("DELETE FROM ligne_produit WHERE idCommande=$id");
        $conn->query("DELETE FROM commande WHERE idCommande=$id");
        $msg='success:Commande supprimée.';
    }
}

// Client filter
$clientFilter = isset($_GET['client_id']) ? (int)$_GET['client_id'] : 0;

// Fetch orders with full info
$clientWhere = $clientFilter ? "AND c.idClient = $clientFilter" : "";
$sql = "SELECT c.*, cl.nom as client_name, cl.telephone, cl.adresse,
               f.idFacture, f.montantTotal, f.tva, f.timbre, f.montantTC,
               c.modePaiement as facture_mode
        FROM commande c
        LEFT JOIN client cl ON c.idClient = cl.idClient
        LEFT JOIN facture f ON f.idCommande = c.idCommande
        WHERE 1=1 $clientWhere
        ORDER BY c.idCommande DESC";
$commandes = $conn->query($sql);
if(!$commandes){ die("SQL Error (commandes): " . $conn->error); }
$commandes = $conn->query($sql);

$pageTitle = "Commandes";
include_once "../components/header.php";
?>
<?php if($msg): list($type,$text) = explode(':', $msg, 2); ?>
<div class="alert alert-<?= $type==='success'?'success':'error' ?>">
    <?= $type==='success'?'✅':'❌' ?> <?= htmlspecialchars($text) ?>
</div>
<?php endif; ?>

<style>
.cmd-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;margin-bottom:18px;overflow:hidden;transition:.2s;}
.cmd-card:hover{border-color:rgba(0,180,216,0.35);}
.cmd-head{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;cursor:pointer;gap:12px;flex-wrap:wrap;}
.cmd-head-left{display:flex;align-items:center;gap:16px;flex-wrap:wrap;}
.cmd-id{font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:15px;}
.cmd-id span{color:var(--accent);}
.cmd-body{padding:22px;border-top:1px solid var(--border);display:none;}
.cmd-body.open{display:block;}
.cmd-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;}
@media(max-width:700px){.cmd-grid{grid-template-columns:1fr;}}
.info-box{background:rgba(0,180,216,0.04);border:1px solid var(--border);border-radius:10px;padding:16px;}
.info-box .label{font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:10px;font-weight:700;}
.info-row{display:flex;justify-content:space-between;font-size:13px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.04);}
.info-row:last-child{border:none;}
.info-row .k{color:var(--muted);}
.info-row .v{font-weight:600;}
.lines-table{width:100%;border-collapse:collapse;margin-bottom:16px;}
.lines-table th{font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:8px 12px;text-align:left;background:rgba(0,180,216,0.05);}
.lines-table td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,0.04);font-size:13px;}
.lines-table tr:last-child td{border:none;}
.actions-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px;align-items:center;}
.validate-form{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.validate-form select{background:rgba(0,0,0,0.4);border:1px solid var(--border);border-radius:8px;padding:7px 12px;color:white;font-size:13px;font-family:'Outfit',sans-serif;outline:none;}
.toggle-icon{font-size:12px;color:var(--accent);white-space:nowrap;}
</style>


<?php
// Per-client summary
$clientSummary = $conn->query("
    SELECT cl.idClient, cl.nom, cl.telephone, cl.adresse,
           COUNT(c.idCommande) AS nb_commandes,
           SUM(CASE WHEN c.etatCommande='validee'  THEN 1 ELSE 0 END) AS nb_validees,
           SUM(CASE WHEN c.etatCommande='en_cours' THEN 1 ELSE 0 END) AS nb_en_cours,
           SUM(CASE WHEN c.etatCommande='annulee'  THEN 1 ELSE 0 END) AS nb_annulees,
           SUM(f.montantTC) AS total_ttc
    FROM client cl
    JOIN commande c ON c.idClient = cl.idClient
    LEFT JOIN facture f ON f.idCommande = c.idCommande
    GROUP BY cl.idClient, cl.nom, cl.telephone, cl.adresse
    ORDER BY nb_commandes DESC
");
?>

<div class="card" style="margin-bottom:24px;">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <span>👥 Commandes par Client</span>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <input type="text" id="searchClientCmd" placeholder="🔍 Chercher par nom…"
                oninput="filterClientCmd()"
                style="background:rgba(0,0,0,0.35);border:1px solid rgba(0,180,216,0.25);border-radius:9px;padding:8px 14px;color:#e2e8f0;font-size:13px;font-family:'Outfit',sans-serif;outline:none;width:240px;"
                onfocus="this.style.borderColor='rgba(0,180,216,0.7)'"
                onblur="this.style.borderColor='rgba(0,180,216,0.25)'">
            <?php if($clientFilter): ?>
            <a href="commandes.php" class="btn btn-ghost btn-sm" style="text-decoration:none;">✕ Voir toutes</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Client</th>
                <th>Téléphone</th>
                <th style="text-align:center">Total</th>
                <th style="text-align:center">✅ Validées</th>
                <th style="text-align:center">⏳ En cours</th>
                <th style="text-align:center">❌ Annulées</th>
                <th style="text-align:right">Montant TTC</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if(!$clientSummary || $clientSummary->num_rows === 0): ?>
        <tr><td colspan="8" class="empty-state">Aucune commande.</td></tr>
        <?php else: while($cs = $clientSummary->fetch_assoc()): ?>
        <tr data-client-search="<?= strtolower(htmlspecialchars($cs['nom'])) ?> <?= htmlspecialchars($cs['telephone'] ?? '') ?>" style="<?= $clientFilter === (int)$cs['idClient'] ? 'background:rgba(0,180,216,0.06);' : '' ?>">
            <td style="font-weight:600"><?= htmlspecialchars($cs['nom']) ?></td>
            <td style="color:var(--muted)"><?= htmlspecialchars($cs['telephone'] ?? '—') ?></td>
            <td style="text-align:center"><span class="badge badge-blue"><?= $cs['nb_commandes'] ?></span></td>
            <td style="text-align:center"><span class="badge badge-green"><?= $cs['nb_validees'] ?></span></td>
            <td style="text-align:center"><span class="badge badge-yellow"><?= $cs['nb_en_cours'] ?></span></td>
            <td style="text-align:center"><span class="badge badge-red"><?= $cs['nb_annulees'] ?></span></td>
            <td style="text-align:right;font-weight:700;color:var(--accent)"><?= $cs['total_ttc'] ? number_format($cs['total_ttc'],2).' DZD' : '—' ?></td>
            <td>
                <a href="?client_id=<?= $cs['idClient'] ?>" class="btn btn-ghost btn-sm" style="text-decoration:none;white-space:nowrap;">
                    👁 Voir commandes
                </a>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
</div>

<div class="card">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        📦 <?= $clientFilter ? 'Commandes de : <span style="color:var(--accent)">'.htmlspecialchars($conn->query("SELECT nom FROM client WHERE idClient=$clientFilter")->fetch_assoc()['nom'] ?? '').'</span>' : 'Liste des Commandes' ?>
        <div style="display:flex;align-items:center;gap:8px;">
            <input type="text" id="searchCmd" placeholder="🔍 ID commande, client, statut…"
                oninput="filterCmd()"
                style="background:rgba(0,0,0,0.35);border:1px solid rgba(0,180,216,0.25);border-radius:9px;padding:8px 14px;color:#e2e8f0;font-size:13px;font-family:'Outfit',sans-serif;outline:none;width:240px;"
                onfocus="this.style.borderColor='rgba(0,180,216,0.7)'"
                onblur="this.style.borderColor='rgba(0,180,216,0.25)'">
            <span id="cmdCount" style="font-size:12px;color:var(--muted);white-space:nowrap;"></span>
        </div>
    </div>

    <?php if($commandes->num_rows === 0): ?>
    <div class="empty-state">Aucune commande pour le moment.</div>
    <?php else: while($r = $commandes->fetch_assoc()):
        $map=['en_cours'=>['yellow','⏳ En cours'],'validee'=>['green','✅ Validée'],'annulee'=>['red','❌ Annulée']];
        [$cls,$lbl] = $map[$r['etatCommande']] ?? ['blue',$r['etatCommande']];

        $modeLabels=['espece'=>'💵 Espèces','carte'=>'💳 Carte','ccp'=>'📮 CCP','cheque'=>'📝 Chèque','virement'=>'🏦 Virement','cash'=>'💵 Cash','card'=>'💳 Carte'];
        $payMode = $r['facture_mode'] ?? $r['modePaiement'] ?? '';
        $payLabel = $modeLabels[$payMode] ?? ($payMode ?: '—');

        // Fetch order lines
        $lRes = $conn->prepare("SELECT lp.quantite, lp.sousTotal, pr.nomProduit, pr.volume, pr.prixFardeau FROM ligne_produit lp JOIN produit pr ON pr.idProduit=lp.idProduit WHERE lp.idCommande=?");
        $lRes->bind_param("i", $r['idCommande']); $lRes->execute();
        $lines = $lRes->get_result();
        $lineRows = [];
        while($l = $lines->fetch_assoc()) $lineRows[] = $l;
    ?>
    <?php $lblPlain = ['en_cours'=>'en cours','validee'=>'validee validée','annulee'=>'annulee annulée'][$r['etatCommande']] ?? $r['etatCommande']; ?>
    <div class="cmd-card" data-cmd-search="<?= $r['idCommande'] ?> <?= strtolower(htmlspecialchars($r['client_name'] ?? '')) ?> <?= $lblPlain ?>">
        <div class="cmd-head" onclick="toggleCmd(<?= $r['idCommande'] ?>)">
            <div class="cmd-head-left">
                <span class="cmd-id">Commande <span>#<?= $r['idCommande'] ?></span></span>
                <span class="badge badge-<?= $cls ?>"><?= $lbl ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                <span style="font-size:13px;color:var(--muted);">📅 <?= $r['dateCommande'] ?></span>
                <span style="font-size:13px;color:var(--muted);">👤 <?= htmlspecialchars($r['client_name'] ?? '—') ?></span>
                <?php if($r['montantTC']): ?>
                <span style="font-weight:700;color:var(--accent);"><?= number_format($r['montantTC'],2) ?> DZD</span>
                <?php endif; ?>
                <span class="toggle-icon" id="ico-<?= $r['idCommande'] ?>">▼ Détails</span>
            </div>
        </div>

        <div class="cmd-body" id="cmd-<?= $r['idCommande'] ?>">
            <div class="cmd-grid">
                <div class="info-box">
                    <div class="label">👤 Client</div>
                    <div class="info-row"><span class="k">Nom</span><span class="v"><?= htmlspecialchars($r['client_name'] ?? '—') ?></span></div>
                    <div class="info-row"><span class="k">Téléphone</span><span class="v"><?= htmlspecialchars($r['telephone'] ?? '—') ?></span></div>
                    <div class="info-row"><span class="k">Adresse</span><span class="v"><?= htmlspecialchars($r['adresse'] ?? '—') ?></span></div>
                </div>
                <div class="info-box">
                    <div class="label">💳 Paiement & Facture</div>
                    <div class="info-row"><span class="k">Mode</span><span class="v"><?= $payLabel ?></span></div>
                    <?php if($r['idFacture']): ?>
                    <div class="info-row"><span class="k">HT</span><span class="v"><?= number_format($r['montantTotal'],2) ?> DZD</span></div>
                    <div class="info-row"><span class="k">TVA</span><span class="v"><?= number_format($r['tva'],2) ?> DZD</span></div>
                    <div class="info-row"><span class="k">TTC</span><span class="v" style="color:var(--accent)"><?= number_format($r['montantTC'],2) ?> DZD</span></div>
                    <?php else: ?>
                    <div class="info-row"><span class="k">Facture</span><span class="v" style="color:var(--yellow)">Non générée</span></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if(!empty($lineRows)): ?>
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:10px;font-weight:700;">📦 Produits</div>
            <table class="lines-table">
                <thead><tr><th>Produit</th><th>Volume</th><th>Qté (fard.)</th><th>Prix/fardeau</th><th>Sous-total</th></tr></thead>
                <tbody>
                <?php foreach($lineRows as $l): ?>
                <tr>
                    <td><?= htmlspecialchars($l['nomProduit']) ?></td>
                    <td><?= htmlspecialchars($l['volume']) ?></td>
                    <td><?= $l['quantite'] ?> fard.</td>
                    <td><?= number_format($l['prixFardeau'],2) ?> DZD</td>
                    <td style="font-weight:700;"><?= number_format($l['sousTotal'],2) ?> DZD</td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>

            <div class="actions-row">
                <?php
                $isEspece = in_array($payMode, ['espece','especes','cash','ccp']);

                if($isEspece && $r['etatCommande'] === 'en_cours'): ?>
                <form method="POST" class="validate-form" onsubmit="return confirm('Confirmer cette commande <?= in_array($payMode,['ccp']) ? 'CCP' : 'espèces' ?> ?')">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="id" value="<?= $r['idCommande'] ?>">
                    <input type="hidden" name="status" value="validee">
                    <input type="hidden" name="modePaiement" value="<?= htmlspecialchars($payMode) ?>">
                    <?php if($payMode): ?>
                    <span style="font-size:13px;color:var(--muted);">Mode : <strong style="color:var(--text)"><?= $payLabel ?></strong></span>
                    <?php endif; ?>
                    <button class="btn btn-success btn-sm" type="submit">✅ Valider</button>
                </form>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Annuler cette commande ?')">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="id" value="<?= $r['idCommande'] ?>">
                    <input type="hidden" name="status" value="annulee">
                    <button class="btn btn-warning btn-sm" type="submit">⛔ Annuler</button>
                </form>

                <?php elseif($isEspece && $r['etatCommande'] === 'validee'): ?>
                <span style="font-size:12px;color:#22d3a0;font-weight:600;">✅ Confirmée</span>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Annuler cette commande validée ? Le stock sera restauré.')">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="id" value="<?= $r['idCommande'] ?>">
                    <input type="hidden" name="status" value="annulee">
                    <button class="btn btn-warning btn-sm" type="submit">⛔ Annuler</button>
                </form>

                <?php elseif($r['etatCommande'] === 'annulee'): ?>
                <span style="font-size:12px;color:#f43f5e;font-weight:600;">❌ Annulée</span>

                <?php elseif(!$isEspece && $r['etatCommande'] === 'en_cours'): ?>
                <span style="font-size:12px;color:#fbbf24;font-weight:600;">⏳ En attente de paiement</span>

                <?php elseif(!$isEspece && $r['etatCommande'] === 'validee'): ?>
                <span style="font-size:12px;color:#22d3a0;font-weight:600;">✅ Auto-confirmée</span>
                <?php endif; ?>

                <a href="factures.php?view_client_invoices=<?= $r['idClient'] ?>" class="btn btn-ghost btn-sm" style="text-decoration:none;">🧾 Factures client</a>

                <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer cette commande et sa facture ?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $r['idCommande'] ?>">
                    <button class="btn btn-danger btn-sm" type="submit">🗑 Supprimer</button>
                </form>
            </div>
        </div>
    </div>
    <?php endwhile; endif; ?>
</div>

<script>
function filterClientCmd(){
    const q = document.getElementById('searchClientCmd').value.toLowerCase().trim();
    document.querySelectorAll('tr[data-client-search]').forEach(r => {
        r.style.display = !q || r.dataset.clientSearch.includes(q) ? '' : 'none';
    });
}
function filterCmd(){
    const q = document.getElementById('searchCmd').value.toLowerCase().trim();
    const cards = document.querySelectorAll('.cmd-card[data-cmd-search]');
    let visible = 0;
    cards.forEach(c => {
        const match = !q || c.dataset.cmdSearch.includes(q);
        c.style.display = match ? '' : 'none';
        if(match) visible++;
    });
    document.getElementById('cmdCount').textContent = q ? `${visible} / ${cards.length} résultats` : `${cards.length} commande(s)`;
}
window.addEventListener('DOMContentLoaded', filterCmd);
function toggleCmd(id){
    const body=document.getElementById('cmd-'+id);
    const ico=document.getElementById('ico-'+id);
    const open=body.classList.toggle('open');
    ico.textContent=open?'▲ Masquer':'▼ Détails';
}
</script>


<?php include_once "../components/footer.php"; ?>