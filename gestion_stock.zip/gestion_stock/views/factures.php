<?php
require_once __DIR__ . '/../config/session.php';
if(!isset($_SESSION['user']) || !in_array($_SESSION['role'], ['admin','responsable_clients'])){ header("Location: ../auth/login.php"); exit(); }
require_once "../config/db.php";
require_once "../controllers/FactureController.php";

$ctrl = new FactureController($conn);
$msg  = '';

$conn->query("ALTER TABLE facture ADD COLUMN IF NOT EXISTS etatFacture ENUM('en_attente','confirmee','annulee') NOT NULL DEFAULT 'en_attente'");

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])){

    if($_POST['action']==='create'){
        $idCmd        = (int)$_POST['idCommande'];
        $modePaiement = trim($_POST['modePaiement'] ?? 'especes');
        $exists = $conn->query("SELECT idFacture FROM facture WHERE idCommande=$idCmd")->num_rows;
        if($exists){ $msg='error:Une facture existe déjà pour cette commande.'; }
        else {
            $res = $conn->query("SELECT SUM(sousTotal) as total FROM ligne_produit WHERE idCommande=$idCmd");
            $ht  = (float)($res->fetch_assoc()['total'] ?? 0);
            if($ht == 0) $ht = isset($_POST['montantHT']) ? (float)$_POST['montantHT'] : 0;
            $tva    = round($ht * 0.19, 2);
            $timbre = 25.00;
            $ttc    = round($ht + $tva + $timbre, 2);
            $date   = date('Y-m-d');
            $stmt = $conn->prepare("INSERT INTO facture (dateFacture,montantTotal,tva,timbre,montantTC,idCommande,modePaiement,etatFacture) VALUES (?,?,?,?,?,?,?,'en_attente')");
            $stmt->bind_param("sddddis",$date,$ht,$tva,$timbre,$ttc,$idCmd,$modePaiement);
            $stmt->execute();
            $msg='success:Facture créée. Confirmez la commande séparément depuis la page Commandes.';
        }
    }

    elseif($_POST['action']==='delete'){
        $id = (int)$_POST['id'];
        $conn->query("DELETE FROM facture WHERE idFacture=$id");
        $msg = $conn->affected_rows > 0 ? 'success:Facture supprimée.' : 'error:Suppression échouée.';
    }

    elseif($_POST['action']==='confirm_facture'){
        $idFacture = (int)$_POST['idFacture'];
        $conn->query("UPDATE facture SET etatFacture='confirmee' WHERE idFacture=$idFacture");
        $msg = 'success:Facture confirmée.';
    }

    elseif($_POST['action']==='annuler_facture'){
        $idFacture = (int)$_POST['idFacture'];
        $conn->query("UPDATE facture SET etatFacture='annulee' WHERE idFacture=$idFacture");
        $msg = 'success:Facture annulée.';
    }
}

$factures  = $ctrl->index();
$pageTitle = "Invoices";

// Totals per client — based purely on etatFacture
$totalsPerClient = $conn->query("
    SELECT cl.idClient, cl.nom,
           COUNT(f.idFacture) AS nb_factures,
           SUM(f.montantTotal) AS total_ht,
           SUM(f.tva)          AS total_tva,
           SUM(f.montantTC)    AS total_ttc,
           SUM(CASE WHEN f.etatFacture='confirmee'  THEN f.montantTC ELSE 0 END) AS total_paye,
           SUM(CASE WHEN f.etatFacture='annulee'    THEN f.montantTC ELSE 0 END) AS total_annule,
           SUM(CASE WHEN f.etatFacture='en_attente' THEN f.montantTC ELSE 0 END) AS total_en_attente
    FROM client cl
    JOIN commande c ON c.idClient   = cl.idClient
    JOIN facture  f ON f.idCommande = c.idCommande
    GROUP BY cl.idClient, cl.nom
    ORDER BY total_ttc DESC
");

// Grand totals — based purely on etatFacture
$grandTotal    = $conn->query("SELECT SUM(montantTC) as v FROM facture")->fetch_assoc()['v'] ?? 0;
$grandPaye     = $conn->query("SELECT SUM(montantTC) as v FROM facture WHERE etatFacture='confirmee'")->fetch_assoc()['v'] ?? 0;
$grandAnnule   = $conn->query("SELECT SUM(montantTC) as v FROM facture WHERE etatFacture='annulee'")->fetch_assoc()['v'] ?? 0;
$grandAttente  = $conn->query("SELECT SUM(montantTC) as v FROM facture WHERE etatFacture='en_attente'")->fetch_assoc()['v'] ?? 0;

$viewClientId = isset($_GET['view_client_invoices']) ? (int)$_GET['view_client_invoices'] : 0;
$clientInvoices = null;
$clientName = '';
if($viewClientId) {
    $cNRes = $conn->query("SELECT nom FROM client WHERE idClient=$viewClientId");
    $clientName = $cNRes ? ($cNRes->fetch_assoc()['nom'] ?? '') : '';
    $clientInvoices = $conn->query("SELECT f.*, c.etatCommande, c.modePaiement, cl.nom as client_name
        FROM facture f
        LEFT JOIN commande c ON f.idCommande = c.idCommande
        LEFT JOIN client cl  ON c.idClient   = cl.idClient
        WHERE c.idClient=$viewClientId ORDER BY f.idFacture DESC");
}

include_once "../components/header.php";
?>

<?php if($msg): list($type,$text) = explode(':', $msg, 2); ?>
<div class="alert alert-<?= $type==='success'?'success':'error' ?>">
    <?= $type==='success'?'✅':'❌' ?> <?= htmlspecialchars($text) ?>
</div>
<?php endif; ?>

<?php if($viewClientId && $clientInvoices): ?>
<div class="card" style="margin-bottom:24px;border-color:rgba(0,180,216,0.35);">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;">
        <span>🧾 Factures de : <?= htmlspecialchars($clientName) ?></span>
        <a href="factures.php" class="btn btn-ghost btn-sm" style="text-decoration:none;">✕ Fermer</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>#</th><th>Date</th><th>HT</th><th>TVA</th><th>TTC</th><th>Paiement</th><th>Statut Facture</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if($clientInvoices->num_rows === 0): ?>
        <tr><td colspan="8" class="empty-state">Aucune facture pour ce client.</td></tr>
        <?php else: while($ci = $clientInvoices->fetch_assoc()):
            $map2=['confirmee'=>['green','✅ Confirmée'],'annulee'=>['red','❌ Annulée'],'en_attente'=>['yellow','⏳ En attente']];
            [$cls2,$lbl2] = $map2[$ci['etatFacture']] ?? ['yellow','⏳ En attente'];
        ?>
        <tr>
            <td><span class="badge badge-blue">#<?= $ci['idFacture'] ?></span></td>
            <td><?= $ci['dateFacture'] ?></td>
            <td><?= number_format($ci['montantTotal'],2) ?> DZD</td>
            <td><?= number_format($ci['tva'],2) ?> DZD</td>
            <td style="font-weight:700;color:var(--accent)"><?= number_format($ci['montantTC'],2) ?> DZD</td>
            <td><?php
                $modeLabels2 = ['espece'=>'💵 Espèces','especes'=>'💵 Espèces','cash'=>'💵 Espèces','carte'=>'💳 Carte / Edahabia','card'=>'💳 Carte / Edahabia','ccp'=>'📮 CCP / Baridimob'];
                $cm = trim(strtolower($ci['modePaiement'] ?? ''));
                echo $modeLabels2[$cm] ?? ($cm ? ucfirst($cm) : '<span style="color:var(--muted)">—</span>');
            ?></td>
            <td><span class="badge badge-<?= $cls2 ?>"><?= $lbl2 ?></span></td>
            <td>
                <a href="print_facture.php?id=<?= $ci['idFacture'] ?>" target="_blank" class="btn btn-ghost btn-sm" style="text-decoration:none;">▼ plus de détails</a>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
</div>
<?php endif; ?>

<div class="card" style="margin-bottom:24px;">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <span>📊 Total des Factures par Client</span>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
            <span style="font-size:13px;color:var(--muted);display:flex;gap:16px;flex-wrap:wrap;align-items:center;">
                <span>Total : <strong style="color:var(--accent)"><?= number_format($grandTotal,2) ?> DZD</strong></span>
                <span>✅ Payé : <strong style="color:#22d3a0"><?= number_format($grandPaye,2) ?> DZD</strong></span>
                <span>❌ Annulé : <strong style="color:var(--red)"><?= number_format($grandAnnule,2) ?> DZD</strong></span>
                <span>⏳ En attente : <strong style="color:#f59e0b"><?= number_format($grandAttente,2) ?> DZD</strong></span>
            </span>
            <input type="text" id="searchClientFac" placeholder="🔍 Chercher un client…"
                oninput="filterClientFac()"
                style="background:rgba(0,0,0,0.35);border:1px solid rgba(0,180,216,0.25);border-radius:9px;padding:8px 14px;color:#e2e8f0;font-size:13px;font-family:'Outfit',sans-serif;outline:none;width:240px;"
                onfocus="this.style.borderColor='rgba(0,180,216,0.7)'"
                onblur="this.style.borderColor='rgba(0,180,216,0.25)'">
        </div>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th>Client</th>
                <th style="text-align:center">Nb Factures</th>
                <th style="text-align:right">Total HT</th>
                <th style="text-align:right">Total TVA</th>
                <th style="text-align:right">Total TTC</th>
                <th style="text-align:right">✅ Payé</th>
                <th style="text-align:right">❌ Annulé</th>
                <th style="text-align:right">⏳ En attente</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php if(!$totalsPerClient || $totalsPerClient->num_rows === 0): ?>
        <tr><td colspan="9" class="empty-state">Aucune facture.</td></tr>
        <?php else: while($t = $totalsPerClient->fetch_assoc()): ?>
        <tr data-client-search="<?= strtolower(htmlspecialchars($t['nom'])) ?>">
            <td style="font-weight:600"><?= htmlspecialchars($t['nom']) ?></td>
            <td style="text-align:center"><span class="badge badge-blue"><?= $t['nb_factures'] ?></span></td>
            <td style="text-align:right"><?= number_format($t['total_ht'],2) ?> DZD</td>
            <td style="text-align:right"><?= number_format($t['total_tva'],2) ?> DZD</td>
            <td style="text-align:right;font-weight:700;color:var(--accent)"><?= number_format($t['total_ttc'],2) ?> DZD</td>
            <td style="text-align:right;color:#22d3a0;font-weight:600"><?= number_format($t['total_paye'],2) ?> DZD</td>
            <td style="text-align:right;color:var(--red);font-weight:600"><?= number_format($t['total_annule'],2) ?> DZD</td>
            <td style="text-align:right;color:#f59e0b;font-weight:600"><?= number_format($t['total_en_attente'],2) ?> DZD</td>
            <td>
                <a href="?view_client_invoices=<?= $t['idClient'] ?>" class="btn btn-ghost btn-sm" style="text-decoration:none;white-space:nowrap;">👁 Voir factures</a>
            </td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
    </div>
</div>

<style>
.fac-card{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;margin-bottom:18px;overflow:hidden;transition:.2s;}
.fac-card:hover{border-color:rgba(0,180,216,0.35);}
.fac-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;cursor:pointer;gap:12px;flex-wrap:wrap;}
.fac-head-left{display:flex;align-items:center;gap:14px;flex-wrap:wrap;}
.fac-id{font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:15px;}
.fac-id span{color:var(--accent);}
.fac-body{padding:20px;border-top:1px solid var(--border);display:none;}
.fac-body.open{display:block;}
.fac-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;}
@media(max-width:700px){.fac-grid{grid-template-columns:1fr;}}
.fac-info{background:rgba(0,180,216,0.04);border:1px solid var(--border);border-radius:10px;padding:14px;}
.fac-info .label{font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:8px;font-weight:700;}
.fac-row{display:flex;justify-content:space-between;font-size:13px;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.04);}
.fac-row:last-child{border:none;}
.fac-row .k{color:var(--muted);}
.fac-row .v{font-weight:600;}
.fac-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;align-items:center;}
.toggle-fac{font-size:12px;color:var(--accent);white-space:nowrap;}
</style>

<div class="card">
    <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
        <span>🧾 Liste des Factures</span>
        <div style="display:flex;align-items:center;gap:8px;">
            <input type="text" id="searchFac" placeholder="🔍 ID facture, client, statut…"
                oninput="filterFac()"
                style="background:rgba(0,0,0,0.35);border:1px solid rgba(0,180,216,0.25);border-radius:9px;padding:8px 14px;color:#e2e8f0;font-size:13px;font-family:'Outfit',sans-serif;outline:none;width:260px;"
                onfocus="this.style.borderColor='rgba(0,180,216,0.7)'"
                onblur="this.style.borderColor='rgba(0,180,216,0.25)'">
            <span id="facCount" style="font-size:12px;color:var(--muted);white-space:nowrap;"></span>
        </div>
    </div>

    <?php if($factures->num_rows===0): ?>
    <div class="empty-state">Aucune facture pour le moment.</div>
    <?php else: while($r = $factures->fetch_assoc()):
        $modeLabels=[
            'espece'=>'💵 Espèces','especes'=>'💵 Espèces','cash'=>'💵 Espèces',
            'cheque'=>'📝 Chèque','virement'=>'🏦 Virement',
            'ccp'=>'📥 CCP / Baridimob','carte'=>'💳 Carte bancaire','card'=>'💳 Carte bancaire',
        ];
        $rawMode   = trim(strtolower($r['modePaiement'] ?? ''));
        $modeLabel = $modeLabels[$rawMode] ?? ($rawMode ? ucfirst($rawMode) : '—');
        $etatF     = $r['etatFacture'] ?? 'en_attente';
        $facMap    = ['confirmee'=>['green','✅ Confirmée'],'annulee'=>['red','❌ Annulée'],'en_attente'=>['yellow','⏳ En attente']];
        [$fcls,$flbl] = $facMap[$etatF] ?? ['yellow','⏳ En attente'];
    ?>
    <?php $facLblPlain = ['confirmee'=>'confirmee confirmée','annulee'=>'annulee annulée','en_attente'=>'en attente'][$etatF] ?? $etatF; ?>
    <div class="fac-card" data-fac-search="<?= $r['idFacture'] ?> <?= strtolower(htmlspecialchars($r['client_name'] ?? '')) ?> <?= $facLblPlain ?>">
        <div class="fac-head" onclick="toggleFac(<?= $r['idFacture'] ?>)">
            <div class="fac-head-left">
                <span class="fac-id">Facture <span>#<?= $r['idFacture'] ?></span></span>
                <span class="badge badge-<?= $fcls ?>"><?= $flbl ?></span>
            </div>
            <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
                <span style="font-size:13px;color:var(--muted);">📅 <?= $r['dateFacture'] ?></span>
                <span style="font-size:13px;color:var(--muted);">👤 <?= htmlspecialchars($r['client_name'] ?? '—') ?></span>
                <span style="font-weight:700;color:var(--accent);"><?= number_format($r['montantTC'],2) ?> DZD</span>
                <span class="toggle-fac" id="ico-f-<?= $r['idFacture'] ?>">▼ Détails</span>
            </div>
        </div>
        <div class="fac-body" id="fac-<?= $r['idFacture'] ?>">
            <div class="fac-grid">
                <div class="fac-info">
                    <div class="label">👤 Client</div>
                    <div class="fac-row"><span class="k">Client</span><span class="v"><?= htmlspecialchars($r['client_name'] ?? '—') ?></span></div>
                    <div class="fac-row"><span class="k">Mode paiement</span><span class="v"><?= $modeLabel ?></span></div>
                    <div class="fac-row"><span class="k">Date</span><span class="v"><?= $r['dateFacture'] ?></span></div>
                </div>
                <div class="fac-info">
                    <div class="label">💰 Montants</div>
                    <div class="fac-row"><span class="k">HT</span><span class="v"><?= number_format($r['montantTotal'],2) ?> DZD</span></div>
                    <div class="fac-row"><span class="k">TVA (19%)</span><span class="v"><?= number_format($r['tva'],2) ?> DZD</span></div>
                    <div class="fac-row"><span class="k">Timbre</span><span class="v"><?= number_format($r['timbre'],2) ?> DZD</span></div>
                    <div class="fac-row"><span class="k">TTC</span><span class="v" style="color:var(--accent)"><?= number_format($r['montantTC'],2) ?> DZD</span></div>
                </div>
            </div>
            <div class="fac-actions">
                <a href="print_facture.php?id=<?= $r['idFacture'] ?>" target="_blank" class="btn btn-ghost btn-sm" style="text-decoration:none;">▼ plus de détails</a>
                <?php if($etatF === 'en_attente'): ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Confirmer cette facture ?')">
                    <input type="hidden" name="action" value="confirm_facture">
                    <input type="hidden" name="idFacture" value="<?= $r['idFacture'] ?>">
                    <button class="btn btn-success btn-sm" type="submit">✅ Confirmer</button>
                </form>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Annuler cette facture ?')">
                    <input type="hidden" name="action" value="annuler_facture">
                    <input type="hidden" name="idFacture" value="<?= $r['idFacture'] ?>">
                    <button class="btn btn-warning btn-sm" type="submit">⛔ Annuler</button>
                </form>
                <?php elseif($etatF === 'confirmee'): ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Annuler cette facture confirmée ?')">
                    <input type="hidden" name="action" value="annuler_facture">
                    <input type="hidden" name="idFacture" value="<?= $r['idFacture'] ?>">
                    <button class="btn btn-warning btn-sm" type="submit">⛔ Annuler</button>
                </form>
                <?php else: ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Réactiver cette facture ?')">
                    <input type="hidden" name="action" value="confirm_facture">
                    <input type="hidden" name="idFacture" value="<?= $r['idFacture'] ?>">
                    <button class="btn btn-success btn-sm" type="submit">↩ Réactiver</button>
                </form>
                <?php endif; ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Supprimer cette facture ?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $r['idFacture'] ?>">
                    <button class="btn btn-danger btn-sm" type="submit">🗑 Supprimer</button>
                </form>
            </div>
        </div>
    </div>
    <?php endwhile; endif; ?>
</div>

<script>
function filterClientFac(){
    const q = document.getElementById('searchClientFac').value.toLowerCase().trim();
    document.querySelectorAll('tr[data-client-search]').forEach(r => {
        r.style.display = !q || r.dataset.clientSearch.includes(q) ? '' : 'none';
    });
}
function filterFac(){
    const q = document.getElementById('searchFac').value.toLowerCase().trim();
    const cards = document.querySelectorAll('.fac-card[data-fac-search]');
    let visible = 0;
    cards.forEach(c => {
        const match = !q || c.dataset.facSearch.includes(q);
        c.style.display = match ? '' : 'none';
        if(match) visible++;
    });
    document.getElementById('facCount').textContent = q ? `${visible} / ${cards.length} résultats` : `${cards.length} facture(s)`;
}
window.addEventListener('DOMContentLoaded', filterFac);
function toggleFac(id){
    const body=document.getElementById('fac-'+id);
    const ico=document.getElementById('ico-f-'+id);
    const open=body.classList.toggle('open');
    ico.textContent=open?'\u25b2 Masquer':'\u25bc Détails';
}
</script>


<?php include_once "../components/footer.php"; ?>