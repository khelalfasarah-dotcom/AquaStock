<?php
require_once __DIR__ . "/../models/produit.php";

class ProduitController {
    private $conn;
    public function __construct($conn){ $this->conn = $conn; }
    public function index(){ return Produit::all($this->conn); }
    public function store($nom, $volume, $prix, $quantite){ return Produit::create($this->conn, $nom, $volume, $prix, $quantite); }
    public function destroy($id){ return Produit::delete($this->conn, $id); }
}
?>