<?php
class FactureController {
    private $conn;
    public function __construct($db){ $this->conn = $db; }

    public function index(){
        $q = "SELECT f.*, c.etatCommande, c.modePaiement, cl.nom as client_name
              FROM facture f
              LEFT JOIN commande c  ON f.idCommande = c.idCommande
              LEFT JOIN client cl   ON c.idClient   = cl.idClient
              ORDER BY f.idFacture DESC";
        return $this->conn->query($q);
    }

    public function store($idCommande, $dateFacture, $montantTotal, $tva, $timbre, $montantTC){
        $stmt = $this->conn->prepare("INSERT INTO facture (dateFacture, montantTotal, tva, timbre, montantTC, idCommande) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sddddi", $dateFacture, $montantTotal, $tva, $timbre, $montantTC, $idCommande);
        return $stmt->execute();
    }

    public function destroy($id){
        $stmt = $this->conn->prepare("DELETE FROM facture WHERE idFacture=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
