<?php
require_once __DIR__ . "/../models/client.php";

class ClientController {
    private $conn;
    public function __construct($conn){ $this->conn = $conn; }
    public function index(){ return Client::all($this->conn); }
    public function store($nom, $adresse, $telephone, $dateNaissance = null, $sexe = null, $email = null, $willaya = null){ return Client::create($this->conn, $nom, $adresse, $telephone, $dateNaissance, $sexe, $email, $willaya); }
    public function destroy($id){ return Client::delete($this->conn, $id); }
}
?>