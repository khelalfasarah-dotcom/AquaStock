<?php
session_start();

// Check if the client is logged in
if (!isset($_SESSION['client_name'])) {
    header("Location: login.php");
    exit();
}

// Retrieve the cart from session
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Calculate the total price
$totalAmount = 0;
foreach ($cart as $item) {
    $totalAmount += $item['quantity'] * $item['price'];
}

// Check if the user is proceeding to checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // In a real-world scenario, you would integrate with a payment gateway API
    // For now, we'll just simulate a payment and redirect to checkout.php
    header("Location: checkout.php"); // After payment processing, redirect to checkout
    exit();
}

// Include the payment page (the page will be rendered for the user if it's a GET request)
include '../client/payment.php'; 
?>