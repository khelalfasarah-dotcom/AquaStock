<?php
class CommandeController {
    private $conn;
    public function __construct($conn){ $this->conn = $conn; }

    public function index(){
        $sql = "SELECT c.*, cl.nom as client_name 
                FROM commande c 
                LEFT JOIN client cl ON c.idClient = cl.idClient 
                ORDER BY c.idCommande DESC";
        return $this->conn->query($sql);
    }

    public function store($idClient, $dateCommande, $etatCommande='en_cours'){
        $idResponsable = 1;
        $stmt = $this->conn->prepare("INSERT INTO commande (dateCommande, etatCommande, idClient, idResponsable) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssii", $dateCommande, $etatCommande, $idClient, $idResponsable);
        return $stmt->execute();
    }

    public function updateStatus($idCommande, $status){
        // Normalize ENUM values
        $map = ['validee'=>'validee','annulee'=>'annulee','en_cours'=>'en_cours',
                'Validée'=>'validee','Annulée'=>'annulee'];
        $dbStatus = $map[$status] ?? 'en_cours';
        $stmt = $this->conn->prepare("UPDATE commande SET etatCommande = ? WHERE idCommande = ?");
        $stmt->bind_param("si", $dbStatus, $idCommande);
        return $stmt->execute();
    }
}
?>
